import numpy as np
from bfs2d import *
def run(AR,al_deg,a2=0.1,n=32,E=1.0,nu=0.3,U=1.0,top_uy=True):
    a1=AR*a2; g=gmat(a1,a2,np.radians(al_deg)); C,mu=Cmat(E,nu)
    D=np.kron(g,C); m=Mesh(n,n)
    K,F=assemble(m,C,D)
    fixed=set(); fv={}
    def fix(dof,val): fixed.add(dof); fv[dof]=val
    for i in range(n+1):
        nb=m.node(i,0); nt=m.node(i,n)
        # bottom: u=0,u_x=0,v=0,v_x=0 (u_y, v_y, mixed free except xy fixed 0?)
        for d in [0,1,4,5]: fix(8*nb+d,0.0)
        # top: u=U,u_x=0, v=0,v_x=0, and u_y=0 (higher-order Dirichlet)
        fix(8*nt+0,U); fix(8*nt+1,0.0); fix(8*nt+4,0.0); fix(8*nt+5,0.0)
        if top_uy: fix(8*nt+2,0.0)
    ties=[]
    for j in range(n+1):
        l=m.node(0,j); r=m.node(n,j)
        for d in range(8): ties.append((8*r+d,8*l+d))
    d=solve(K,F,fixed,fv,ties)
    # fields at top boundary, bottom, and profile at nodes
    ey=n-1; ex=0
    f=fields(m,d,-1,+1,ex,ey)  # top-left node of top-left element -> y=H
    mu_=mu; g22=g[1,1]
    tau_top=g22*mu_*(f['u_yy']+f['v_xy'])
    peak=abs(tau_top)/(mu_*U/1.0*a2)
    # tau profile at nodes along y (x-indep): take element-left-node values
    ys=[];tau=[];gam=[]
    for ey in range(n):
        for eta in ([-1] if ey<n-1 else [-1,1]):
            ff=fields(m,d,-1,eta,0,ey); ys.append((ey+(eta+1)/2)/n)
            tau.append(g22*mu_*(ff['u_yy']+ff['v_xy'])/(mu_*U*a2)); gam.append(ff['u_y']+ff['v_x'])
    ys=np.array(ys);tau=np.abs(np.array(tau));gam=np.array(gam)
    # delta: scan from top downward; first crossing of 1% with linear interpolation
    ordr=np.argsort(-ys); yy=ys[ordr]; rr=(tau/tau.max())[ordr]
    delta=1.0
    for k in range(len(yy)-1):
        if rr[k]>0.01 and rr[k+1]<=0.01:
            yc=yy[k]+(rr[k]-0.01)/(rr[k]-rr[k+1])*(yy[k+1]-yy[k]); delta=1-yc; break
    # energies from nodal-sample? use Gauss integration over all elements
    Uc=Ug=0.0
    for ey in range(n):
        for xi,wx in zip(GP,GW):
            for eta,wy in zip(GP,GW):
                ff=fields(m,d,0.0,eta,0,ey)  # x-independent
                g_=ff['u_y']+ff['v_x']
                Uc+=0.5*mu_*g_**2*wy*0.5/n
                Ug+=0.5*g22*mu_*(ff['u_yy']+ff['v_xy'])**2*wy*0.5/n
    psig=100*Ug/(Uc+Ug)
    return dict(peak=peak,gam0=gam[0],gam1=gam[-1],delta=delta,psig=psig)
if __name__=="__main__":
    for AR,al in [(1,0),(10,90),(10,45),(5,90),(5,0)]:
        print(AR,al,{k:round(v,4) for k,v in run(AR,al).items()})
