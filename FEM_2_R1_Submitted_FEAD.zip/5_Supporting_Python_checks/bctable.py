import numpy as np
from ode1d import sol
a2=0.1
print("case l/H | present: peak/(mu g0 a2), g(0)/g0, delta/H, Psi_g | clamped-both: peak, g(mid)/g0, Psi_g")
for AR,al in [(1,0),(3,90),(5,45),(10,90)]:
    a1=AR*a2; g22=(a1**2*np.sin(np.radians(al))**2+a2**2*np.cos(np.radians(al))**2)/5; l=np.sqrt(g22)
    out=[]
    for bc in ["top_clamped_bottom_free","both_clamped"]:
        f=sol(l,bc=bc); ys=np.linspace(0,1,40001); F=np.array([f(y) for y in ys]); u1=F[:,1]; u2=F[:,2]; tau=g22*u2
        Uc=0.5*np.trapezoid(u1**2,ys); Ug=0.5*np.trapezoid(g22*u2**2,ys)
        peak=np.abs(tau).max()/a2; psi=100*Ug/(Uc+Ug)
        r=np.abs(tau)/np.abs(tau).max(); idx=np.where(r<=0.01)[0]; delta=1-ys[idx[-1]] if len(idx) else float('nan')
        out.append((peak,u1[0],u1[len(ys)//2],delta,psi))
    p,s=out
    print(f"AR={AR} al={al} l/H={l:.3f} | {p[0]:.3f} {p[1]:.3f} {p[3]:.3f} {p[4]:.1f} | {s[0]:.3f} {s[2]:.3f} {s[4]:.1f}")
