function sweep()
D=zeros(10,10); P=zeros(10,10);
for AR=1:10
 for ia=0:9
  [p,yv,tv]=run_case(AR,10*ia,16);
  [ys,si]=sort(yv,'descend'); t=abs(tv(si)); th=0.01*max(t);
  ib=find(t<th,1,'first');
  if isempty(ib), yt=0.5; elseif ib==1, yt=ys(1); else
   yt=ys(ib-1)+(ys(ib)-ys(ib-1))*(th-t(ib-1))/(t(ib)-t(ib-1)); end
  D(AR,ia+1)=1-yt; P(AR,ia+1)=p;
 end
 dlmwrite('sweepD.csv',D,'precision','%.6f'); dlmwrite('sweepP.csv',P,'precision','%.6f');
end
end
