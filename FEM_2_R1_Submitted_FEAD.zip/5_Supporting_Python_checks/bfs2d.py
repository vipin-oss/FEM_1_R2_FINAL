import numpy as np, scipy.sparse as sp, scipy.sparse.linalg as spla
# ---- 1D Hermite on [-1,1]
def herm(s):
    L=[(2-3*s+s**3)/4,(2+3*s-s**3)/4]
    D=[(1-s-s**2+s**3)/4,(-1-s+s**2+s**3)/4]
    dL=[(-3+3*s**2)/4,(3-3*s**2)/4]; dD=[(-1-2*s+3*s**2)/4,(-1+2*s+3*s**2)/4]
    ddL=[6*s/4,-6*s/4]; ddD=[(-2+6*s)/4,(2+6*s)/4]
    return (L,D),(dL,dD),(ddL,ddD)
NODES=[(0,0),(1,0),(1,1),(0,1)]  # (a,b) index: 0->s=-1,1->s=+1
def bfs_rows(xi,eta,hx,hy):
    """returns dict of arrays (16,) for N,Nx,Ny,Nxx,Nxy,Nyy ; dof order per node: [w,wx,wy,wxy]"""
    H0,H1,H2=herm(xi),herm(eta),None
    Hx=[herm(xi)[k] for k in range(3)]; Hy=[herm(eta)[k] for k in range(3)]
    out={k:np.zeros(16) for k in ['N','x','y','xx','xy','yy']}
    sx,sy=2/hx,2/hy
    for n,(a,b) in enumerate(NODES):
        # (value-type index j: 0=L,1=D)
        def f(dx,dy,jx,jy):
            return Hx[dx][jx][a]*Hy[dy][jy][b]
        scale=[1,hx/2,hy/2,hx*hy/4]
        for d,(jx,jy) in enumerate([(0,0),(1,0),(0,1),(1,1)]):
            i=4*n+d
            out['N'][i]=scale[d]*f(0,0,jx,jy)
            out['x'][i]=scale[d]*sx*f(1,0,jx,jy)
            out['y'][i]=scale[d]*sy*f(0,1,jx,jy)
            out['xx'][i]=scale[d]*sx*sx*f(2,0,jx,jy)
            out['xy'][i]=scale[d]*sx*sy*f(1,1,jx,jy)
            out['yy'][i]=scale[d]*sy*sy*f(0,2,jx,jy)
    return out
def BB(r):
    z=np.zeros(16)
    B=np.zeros((3,32)); Bg=np.zeros((6,32))
    # dof vector ordering: u-block(16) then v-block(16)
    B[0,:16]=r['x']; B[1,16:]=r['y']; B[2,:16]=r['y']; B[2,16:]=r['x']
    Bg[0,:16]=r['xx']; Bg[1,16:]=r['xy']; Bg[2,:16]=r['xy']; Bg[2,16:]=r['xx']
    Bg[3,:16]=r['xy']; Bg[4,16:]=r['yy']; Bg[5,:16]=r['yy']; Bg[5,16:]=r['xy']
    return B,Bg
def Cmat(E,nu):
    lam=E*nu/((1+nu)*(1-2*nu)); mu=E/(2*(1+nu))
    return np.array([[lam+2*mu,lam,0],[lam,lam+2*mu,0],[0,0,mu]]),mu
def gmat(a1,a2,al):
    c,s=np.cos(al),np.sin(al)
    return np.array([[a1**2*c*c+a2**2*s*s,(a1**2-a2**2)*s*c],[(a1**2-a2**2)*s*c,a1**2*s*s+a2**2*c*c]])/5
GP,GW=np.polynomial.legendre.leggauss(4)
class Mesh:
    def __init__(s,nx,ny,Lx=1.,Ly=1.):
        s.nx,s.ny,s.Lx,s.Ly=nx,ny,Lx,Ly; s.hx,s.hy=Lx/nx,Ly/ny
        s.nn=(nx+1)*(ny+1); s.ndof=8*s.nn
    def node(s,i,j): return j*(s.nx+1)+i
    def edofs(s,ex,ey):
        ns=[s.node(ex+a,ey+b) for (a,b) in NODES]
        u=[8*n+d for n in ns for d in range(4)]; v=[8*n+4+d for n in ns for d in range(4)]
        return np.array(u+v)
def assemble(m,C,D,bfun=None):
    rows=[];cols=[];vals=[]; F=np.zeros(m.ndof)
    ge=[];
    Ke=np.zeros((32,32)); pts=[(xi,eta,wx*wy) for xi,wx in zip(GP,GW) for eta,wy in zip(GP,GW)]
    pre=[]
    for xi,eta,w in pts:
        r=bfs_rows(xi,eta,m.hx,m.hy); B,Bg=BB(r); pre.append((w,r,B,Bg))
    J=m.hx*m.hy/4
    for ey in range(m.ny):
        for ex in range(m.nx):
            Ke[:]=0; fe=np.zeros(32); dofs=m.edofs(ex,ey)
            for (xi,eta,_),(w,r,B,Bg) in zip(pts,pre):
                Ke+=w*J*(B.T@C@B+Bg.T@D@Bg)
                if bfun is not None:
                    x=(ex+0.5+xi/2)*m.hx; y=(ey+0.5+eta/2)*m.hy
                    bu,bv=bfun(x,y); fe[:16]+=w*J*bu*r['N']; fe[16:]+=w*J*bv*r['N']
            ii,jj=np.meshgrid(dofs,dofs,indexing='ij'); rows.append(ii.ravel());cols.append(jj.ravel());vals.append(Ke.ravel().copy())
            F[dofs]+=fe
    K=sp.csr_matrix((np.concatenate(vals),(np.concatenate(rows),np.concatenate(cols))),shape=(m.ndof,m.ndof))
    return K,F
def solve(K,F,fixed,fixval,ties=None):
    """fixed dofs with values; ties: list of (slave,master) elimination"""
    n=K.shape[0]
    # map: full = T @ reduced
    master=np.arange(n)
    if ties:
        for s_,m_ in ties: master[s_]=m_
    free=np.array([i for i in range(n) if master[i]==i and i not in fixed])
    idx={d:k for k,d in enumerate(free)}
    T=sp.lil_matrix((n,len(free)))
    for i in range(n):
        mi=master[i]
        if mi in idx: T[i,idx[mi]]=1.0
    T=T.tocsr()
    d0=np.zeros(n)
    for d,v in fixval.items(): d0[d]=v
    for s_,m_ in (ties or []):
        if m_ in fixval: d0[s_]=fixval[m_]
    Kr=T.T@K@T; Fr=T.T@(F-K@d0)
    x=spla.spsolve(Kr.tocsc(),Fr)
    return T@x+d0
def fields(m,d,xi,eta,ex,ey):
    r=bfs_rows(xi,eta,m.hx,m.hy); dofs=m.edofs(ex,ey); de=d[dofs]
    out={}
    for k in ['N','x','y','xx','xy','yy']:
        out['u_'+k]=r[k]@de[:16]; out['v_'+k]=r[k]@de[16:]
    return out
