import numpy as np, json, time
from bfs2d import *
def block(AR,al,gmode,LH=1.0,n=64,a2=0.1,nu=0.3,U=1.0):
    nx=int(round(n*LH)); ny=n; m=Mesh(nx,ny,LH,1.0)
    a1=AR*a2; g=gmat(a1,a2,np.radians(al)); C,mu=Cmat(1.0,nu)
    if gmode=="diag": g=np.diag(np.diag(g))
    elif gmode=="iso_ln": g=np.eye(2)*g[1,1]
    D=np.kron(g,C); K,F=assemble(m,C,D)
    fixed=set(); fv={}
    for i in range(nx+1):
        nb=m.node(i,0); nt=m.node(i,ny)
        for d in [0,1,4,5]: fixed.add(8*nb+d); fv[8*nb+d]=0.0
        for d,v in [(0,U),(1,0.0),(4,0.0),(5,0.0),(2,0.0)]: fixed.add(8*nt+d); fv[8*nt+d]=v
    d=solve(K,F,fixed,fv,None)
    # energies
    Uc=Ug=0.0
    for ey in range(ny):
        for ex in range(nx):
            dofs=m.edofs(ex,ey); de=d[dofs]
            for xi,wx in zip(GP,GW):
                for eta,wy in zip(GP,GW):
                    r=bfs_rows(xi,eta,m.hx,m.hy); B,Bg=BB(r); w=wx*wy*m.hx*m.hy/4
                    e=B@de; ge=Bg@de
                    Uc+=0.5*w*e@C@e; Ug+=0.5*w*ge@D@ge
    # top-edge profile of t5 and u(y) at mid-x
    xs=[];t5=[];t3=[]
    for ex in range(nx):
        for xi in ([-1] if ex<nx-1 else [-1,1]):
            f=fields(m,d,xi,1.0,ex,ny-1)
            ge=np.array([f['u_xx'],f['v_xy'],f['u_xy']+f['v_xx'],f['u_xy'],f['v_yy'],f['u_yy']+f['v_xy']])
            t=D@ge; xs.append((ex+(xi+1)/2)*m.hx); t5.append(t[5]/(mu*U*a2)); t3.append(t[2]/(mu*U*a2))
    # mid-height profile of shear strain across x at y=H/2
    xm=[];gm=[]
    ey=ny//2
    for ex in range(nx):
        for xi in ([-1] if ex<nx-1 else [-1,1]):
            f=fields(m,d,xi,-1.0,ex,ey); xm.append((ex+(xi+1)/2)*m.hx); gm.append(f['u_y']+f['v_x'])
    return dict(Uc=Uc,Ug=Ug,xs=np.array(xs),t5=np.array(t5),t3=np.array(t3),xm=np.array(xm),gm=np.array(gm),m=m,d=d,g=g,mu=mu)
if __name__=="__main__":
    out={}
    for LH in [1.0,2.0]:
        for mode in ["full","diag","iso_ln"]:
            t=time.time(); r=block(5,45,mode,LH=LH); 
            Ut=r['Uc']+r['Ug']
            print(f"L/H={LH} {mode:7s} Uc={r['Uc']:.5f} Ug={r['Ug']:.5f} Utot={Ut:.5f} Psi_g={100*r['Ug']/Ut:.2f}% max|t5|={np.abs(r['t5']).max():.3f} t5(mid)={r['t5'][len(r['t5'])//2]:.3f}  ({time.time()-t:.0f}s)")
            out[f"{LH}_{mode}"]=dict(Uc=r['Uc'],Ug=r['Ug'],xs=r['xs'].tolist(),t5=r['t5'].tolist(),xm=r['xm'].tolist(),gm=r['gm'].tolist())
    json.dump(out,open("block.json","w"))
