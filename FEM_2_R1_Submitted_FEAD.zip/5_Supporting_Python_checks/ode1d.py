import numpy as np
def sol(l, H=1.0, U=1.0, bc="top_clamped_bottom_free"):
    # u'''' = u''/l^2 ; u''=A e^{y/l}+B e^{-y/l}
    # unknowns A,B,c,d : u = A l^2 e^{y/l}+B l^2 e^{-y/l}+c y+d
    def rows(y):
        return dict(u=[l*l*np.exp(y/l), l*l*np.exp(-y/l), y, 1],
                    u1=[l*np.exp(y/l), -l*np.exp(-y/l), 1, 0],
                    u2=[np.exp(y/l), np.exp(-y/l), 0, 0])
    r0, rH = rows(0.0), rows(H)
    if bc=="top_clamped_bottom_free":
        M=[r0['u'], rH['u'], rH['u1'], r0['u2']]; b=[0,U,0,0]
    elif bc=="both_clamped":
        M=[r0['u'], rH['u'], rH['u1'], r0['u1']]; b=[0,U,0,0]
    A,B,c,d=np.linalg.solve(np.array(M,float),np.array(b,float))
    f=lambda y:(l*l*A*np.exp(y/l)+l*l*B*np.exp(-y/l)+c*y+d,
                l*A*np.exp(y/l)-l*B*np.exp(-y/l)+c, A*np.exp(y/l)+B*np.exp(-y/l))
    return f
if __name__=="__main__":
    for bc in ["top_clamped_bottom_free","both_clamped"]:
        print(bc)
        for AR,al in [(1,0),(5,0),(5,90),(10,90),(10,45),(3,45)]:
            a2=1;a1=AR
            g22=(a1**2*np.sin(np.radians(al))**2+a2**2*np.cos(np.radians(al))**2)/5
            l=np.sqrt(g22); f=sol(l,bc=bc)
            ys=np.linspace(0,1,2001); u1=np.array([f(y)[1] for y in ys]); u2=np.array([f(y)[2] for y in ys])
            tau=g22*u2
            # delta: distance from y=H where |tau|/max<=0.01
            r=np.abs(tau)/np.abs(tau).max(); idx=np.where(r<=0.01)[0]
            print(f"AR={AR} al={al} l={l:.4f} gamma(0)={u1[0]:.4f} gamma(1)={u1[-1]:.4f} max|tau|={np.abs(tau).max():.4f}", 
                  "delta/H=%.4f"%(1-ys[idx[-1]] if len(idx) else float('nan')))
