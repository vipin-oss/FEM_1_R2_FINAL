function [peak, yv, tauv, d, mesh] = run_case(AR, alphaDeg, N)
geometry.xMin=0;geometry.xMax=1;geometry.yMin=0;geometry.yMax=1;geometry.L=1;geometry.H=1;
material.E=1.0;material.nu=0.30;material.model='isotropic_linear_elastic_reference';material.mu=material.E/(2*(1+material.nu));
U_top=0.05;gamma0=U_top/geometry.H;
meshParams.Nx=N;meshParams.Ny=N;meshParams.elementType='BFS';meshParams.nodesPerElement=4;meshParams.dofsPerNode=8;meshParams.dofsPerElement=32;
mesh=mesh_generator(geometry,meshParams);
a2=0.10;tau_ref=material.mu*gamma0*a2;gaussOrder=4;
Cmat=constitutive_C(material);C=Cmat.C;
a1=AR*a2;alpha=alphaDeg*pi/180;
g11=(a1^2*cos(alpha)^2+a2^2*sin(alpha)^2)/5;g22=(a1^2*sin(alpha)^2+a2^2*cos(alpha)^2)/5;g12=((a1^2-a2^2)*sin(alpha)*cos(alpha))/5;
Dmat=struct();Dmat.D=[g11*C,g12*C;g12*C,g22*C];Dmat.g2=[g11,g12;g12,g22];
constitutive=struct();constitutive.C=Cmat;constitutive.D=Dmat;
[K_global,F_global]=local_assemble_uniform_BFS(mesh,constitutive,gaussOrder);
boundary=local_build_simple_shear_boundary(mesh,U_top);
[K_bc,F_bc,bc]=apply_boundary_conditions(K_global,F_global,mesh,boundary);
[K_bc,F_bc,masterDofs,slaveDofs]=local_apply_periodic_lr(K_bc,F_bc,mesh,boundary,geometry);
solution=solver(K_bc,F_bc,bc,mesh);
solution.displacement(slaveDofs)=solution.displacement(masterDofs);
d=solution.displacement;
[yv,tauMid]=local_extract_midline_double_stress(mesh,d,geometry,constitutive);
tauv=tauMid/tau_ref; peak=max(abs(tauMid))/tau_ref;
end
function [K_global, F_global] = local_assemble_uniform_BFS(mesh, constitutive, gaussOrder)
    numDofs = mesh.numDofs;
    numElements = mesh.numElements;

    elemNodes = mesh.elements(1, :);
    elementCoords = mesh.nodes(elemNodes, :);
    gauss = gauss_rule(gaussOrder);
    shape2D = bfs_tensor_product(gauss.xi, gauss.eta);
    jac = jacobian_bfs(elementCoords, shape2D);
    phys = physical_derivatives(shape2D, jac);
    Bmat = B_matrix(phys);
    Bgmat = Bg_matrix(phys);
    Ke = element_stiffness(Bmat, Bgmat, constitutive.C, constitutive.D, jac, gauss);
    KeTotal = Ke.total;

    nnzPerElement = 32 * 32;
    I = zeros(numElements * nnzPerElement, 1);
    J = zeros(numElements * nnzPerElement, 1);
    V = zeros(numElements * nnzPerElement, 1);
    cursor = 0;
    for e = 1:numElements
        elemNodes = mesh.elements(e, :);
        edofs = reshape(mesh.dofMap(elemNodes, :).', 32, 1);
        [II, JJ] = ndgrid(edofs, edofs);
        idx = cursor + (1:nnzPerElement);
        I(idx) = II(:);
        J(idx) = JJ(:);
        V(idx) = KeTotal(:);
        cursor = cursor + nnzPerElement;
    end
    K_global = sparse(I, J, V, numDofs, numDofs);
    F_global = zeros(numDofs, 1);
end

function boundary = local_build_simple_shear_boundary(mesh, U_top)
    bottomDofs = mesh.bottomDofs(:);
    topDofs = mesh.topDofs(:);
    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes = numel(topDofs) / 8;

    bottomFixIndices = [];
    for nb = 1:numBottomNodes
        bottomFixIndices = [bottomFixIndices, 8*(nb-1) + [1, 2, 5, 6]]; %#ok<AGROW>
    end
    fixedBottomDofs = bottomDofs(bottomFixIndices);
    bottomVals = zeros(numel(fixedBottomDofs), 1);

    topFixIndices = [];
    for nt = 1:numTopNodes
        topFixIndices = [topFixIndices, 8*(nt-1) + [1, 2, 3, 4, 5, 6]]; %#ok<AGROW>
    end
    fixedTopDofs = topDofs(topFixIndices);
    topVals = zeros(numel(fixedTopDofs), 1);

    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;

    boundary = struct();
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values = [bottomVals(:); topVals(:)];
end

function [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry)
    xTol = 1.0e-7 * geometry.L;
    leftNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMax) <= xTol);
    [~, sortLeft] = sort(mesh.nodes(leftNodeIndices, 2));
    leftNodeIndices = leftNodeIndices(sortLeft);
    [~, sortRight] = sort(mesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);

    masterDofs = [];
    slaveDofs = [];
    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);
        for c = 1:8
            dofL = mesh.dofMap(nodeL, c);
            dofR = mesh.dofMap(nodeR, c);
            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL]; %#ok<AGROW>
                    slaveDofs = [slaveDofs; dofR]; %#ok<AGROW>
                end
            end
        end
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m) = F_bc(m) + F_bc(s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        K_bc(s, :) = 0.0;
        K_bc(:, s) = 0.0;
        K_bc(s, s) = 1.0;
        F_bc(s) = 0.0;
    end
end

function [yMid, tauMid] = local_extract_midline_double_stress(mesh, d, geometry, constitutive)
    xMid = 0.5 * (geometry.xMin + geometry.xMax);
    xTol = 1.0e-7 * geometry.L;
    midNodeIndices = find(abs(mesh.nodes(:, 1) - xMid) <= xTol);
    if isempty(midNodeIndices)
        [~, closest] = min(abs(mesh.nodes(:, 1) - xMid));
        xClosest = mesh.nodes(closest, 1);
        midNodeIndices = find(abs(mesh.nodes(:, 1) - xClosest) <= xTol);
    end
    [yMid, sortIdx] = sort(mesh.nodes(midNodeIndices, 2));
    midNodeIndices = midNodeIndices(sortIdx);
    tauMid = zeros(numel(midNodeIndices), 1);
    hx = mesh.hx;
    hy = mesh.hy;
    
    D66 = constitutive.D.D(6, 6);

    for p = 1:numel(midNodeIndices)
        xq = mesh.nodes(midNodeIndices(p), 1);
        yq = mesh.nodes(midNodeIndices(p), 2);
        ex = floor((xq - geometry.xMin) / hx) + 1;
        ey = floor((yq - geometry.yMin) / hy) + 1;
        ex = max(1, min(mesh.Nx, ex));
        ey = max(1, min(mesh.Ny, ey));
        elemID = (ey - 1) * mesh.Nx + ex;
        elemNodes = mesh.elements(elemID, :);
        elementCoords = mesh.nodes(elemNodes, :);
        elemCenter = mean(elementCoords, 1);
        xi = 2.0 * (xq - elemCenter(1)) / hx;
        eta = 2.0 * (yq - elemCenter(2)) / hy;
        shape2D = bfs_tensor_product(xi, eta);
        jac = jacobian_bfs(elementCoords, shape2D);
        phys = physical_derivatives(shape2D, jac);
        
        d2N_dy2 = phys.d2N_dy2(1, :);
        d2N_dxdy = phys.d2N_dxdy(1, :);
        
        grad_gamma_y = 0.0;
        for A = 1:4
            globalNode = elemNodes(A);
            for r = 1:4
                scalarCol = 4*(A-1) + r;
                uDof = mesh.dofMap(globalNode, r);
                vDof = mesh.dofMap(globalNode, 4 + r);
                grad_gamma_y = grad_gamma_y + d2N_dy2(scalarCol) * d(uDof) ...
                                            + d2N_dxdy(scalarCol) * d(vDof);
            end
        end
        tauMid(p) = D66 * grad_gamma_y;
    end
end
