import numpy as np, json, os
os.makedirs("figs", exist_ok=True)
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from paper_repro import run
from block import block
plt.rcParams.update({"font.family":"serif","font.serif":["Times New Roman","STIXGeneral"],"mathtext.fontset":"stix","font.size":9,"axes.grid":True,"axes.grid.which":"both","grid.linestyle":":","grid.alpha":0.3,"xtick.direction":"out","ytick.direction":"out","axes.labelsize":10})
H=1.0
def ana(l):
    c=np.cosh(H/l); s=np.sinh(H/l); D=c-(l/H)*s
    peak=(l/H)*s/D
    g0=(c-1)/D
    # energies: U_c=1/2 mu int gamma^2 ; U_g=1/2 l^2 mu int gamma'^2  (gamma0=1,H=1)
    y=np.linspace(0,H,4001); gam=(c-np.cosh(y/l))/D; gp=-np.sinh(y/l)/(l*D)
    Uc=0.5*np.trapezoid(gam**2,y); Ug=0.5*l*l*np.trapezoid(gp**2,y)
    return peak,g0,100*Ug/(Uc+Ug)
ls=np.logspace(-2,0.1,200); A=np.array([ana(l) for l in ls])
pts=[]
for AR in [1,2,3,5,7,10]:
    for al in [0,15,30,45,60,75,90]:
        a2=0.1;a1=AR*a2
        g22=(a1**2*np.sin(np.radians(al))**2+a2**2*np.cos(np.radians(al))**2)/5
        r=run(AR,al,n=16); pts.append((AR,al,np.sqrt(g22),r['peak']*a2,r['gam0'],r['psig']))
pts=np.array(pts); json.dump(pts.tolist(),open("collapse_pts.json","w"))
fig,ax=plt.subplots(1,3,figsize=(10.5,3.3)); fig.subplots_adjust(wspace=0.42)
cmap=plt.get_cmap("viridis")
for k,(lab,idx,yl) in enumerate([("(a)",3,r"$\max|\tau_{xyy}|/(\mu\gamma_0 H)$"),("(b)",4,r"$\gamma_{xy}(0)/\gamma_0$"),("(c)",5,r"$\Psi_g$ (%)")]):
    a=ax[k]; a.plot(ls,A[:,k],"k-",lw=1.4,label="1D closed-form solution")
    sc=a.scatter(pts[:,2],pts[:,idx],c=pts[:,0],cmap="viridis",s=16,edgecolor="k",linewidth=0.3,zorder=3,label=r"BFS, 42 $(\mathrm{AR},\alpha)$ pairs")
    a.set_xscale("log"); a.set_xlabel(r"$\ell_n/H$"); a.set_ylabel(yl); a.set_title(lab,loc="left",fontsize=9)
    a.axvspan(0.3,1.3,color="0.85",alpha=0.5,lw=0)
    if k in (0,2): a.set_yscale("log")
ax[0].legend(fontsize=7,loc="upper left"); cb=fig.colorbar(sc,ax=ax,fraction=0.02,pad=0.01); cb.set_label("AR")
fig.savefig("figs/Fig12_Collapse_lnH.pdf",bbox_inches="tight"); plt.close(fig)
# block fig
res={}
for mode in ["full","diag"]: res[mode]=block(5,45,mode,LH=1.0,n=64)
fig,ax=plt.subplots(1,2,figsize=(8.2,3.1))
for mode,st,lab in [("full","-",r"full $\mathbf{g}^2(\alpha)$"),("diag","--",r"$g_{12}^2=0$ (diagonal)")]:
    r=res[mode]; sel=(r['xs']>0.04)&(r['xs']<0.96)
    ax[0].plot(r['xs'][sel],r['t5'][sel],st,label=lab); ax[1].plot(r['xm'],r['gm'],st,label=lab)
ax[0].set_xlabel("$x/L$"); ax[0].set_ylabel(r"$\tau_{xyy}/(\mu\gamma_0 a_2)$ at $y=H$"); ax[0].set_title("(a)",loc="left",fontsize=9)
ax[1].set_xlabel("$x/L$"); ax[1].set_ylabel(r"$\gamma_{xy}/\gamma_0$ at $y=H/2$"); ax[1].set_title("(b)",loc="left",fontsize=9); ax[0].legend(fontsize=7)
fig.tight_layout(); fig.savefig("figs/Fig13_FiniteBlock.pdf",bbox_inches="tight")
for mode in res: r=res[mode]; print(mode,r['Uc'],r['Ug'],(r['Uc']+r['Ug']))
