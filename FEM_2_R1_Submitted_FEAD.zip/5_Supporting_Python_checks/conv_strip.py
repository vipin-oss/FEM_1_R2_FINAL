import numpy as np, json
from bfs2d import *
H=1.0
def exact(l,U=1.0):
    D=np.cosh(H/l)-(l/H)*np.sinh(H/l)
    # gamma(y)=U/H*(cosh(H/l)-cosh(y/l))/D ; u=int gamma
    u=lambda y: U/H*((np.cosh(H/l))*y-l*np.sinh(y/l))/D
    g=lambda y: U/H*(np.cosh(H/l)-np.cosh(y/l))/D
    g1=lambda y: -U/H*np.sinh(y/l)/(l*D)
    return u,g,g1
def solve_strip(AR,al,a2,n,nu=0.3):
    E=1.0; a1=AR*a2; g=gmat(a1,a2,np.radians(al)); C,mu=Cmat(E,nu); D=np.kron(g,C); m=Mesh(n,n)
    K,F=assemble(m,C,D); fixed=set(); fv={}
    for i in range(n+1):
        nb=m.node(i,0); nt=m.node(i,n)
        for d in [0,1,4,5]: fixed.add(8*nb+d); fv[8*nb+d]=0.0
        for d,v in [(0,1.0),(1,0.0),(4,0.0),(5,0.0),(2,0.0)]: fixed.add(8*nt+d); fv[8*nt+d]=v
    ties=[(8*m.node(n,j)+d,8*m.node(0,j)+d) for j in range(n+1) for d in range(8)]
    dvec=solve(K,F,fixed,fv,ties); return m,dvec,g[1,1]
def errors(m,d,l):
    u,g,g1=exact(l); n=m.ny
    GP6,GW6=np.polynomial.legendre.leggauss(6)
    e0=e1=e2=0.0; n0=n1=n2=0.0
    for ey in range(n):
        for ex in [0]:   # x-independent: one column sufficient (times Lx=1)
            for xi,wx in zip(GP6,GW6):
                for eta,wy in zip(GP6,GW6):
                    f=fields(m,d,xi,eta,ex,ey); y=(ey+0.5+eta/2)*m.hy; w=wx*wy*(m.hx/2)*(m.hy/2)*m.nx
                    e0+=w*((f['u_N']-u(y))**2+f['v_N']**2)
                    e1+=w*((f['u_x'])**2+(f['u_y']-g(y))**2+f['v_x']**2+f['v_y']**2)
                    e2+=w*((f['u_xx'])**2+2*f['u_xy']**2+(f['u_yy']-g1(y))**2+f['v_xx']**2+2*f['v_xy']**2+f['v_yy']**2)
                    n0+=w*u(y)**2; n1+=w*g(y)**2; n2+=w*g1(y)**2
    return np.sqrt(e0/n0),np.sqrt(e1/n1),np.sqrt(e2/n2)
if __name__=="__main__":
    res={}
    for name,(AR,al) in {"iso(AR=1)":(1,0),"AR=5,a=45":(5,45),"AR=10,a=90":(10,90)}.items():
        a2=0.1; a1=AR*a2; g22=(a1**2*np.sin(np.radians(al))**2+a2**2*np.cos(np.radians(al))**2)/5; l=np.sqrt(g22)
        rows=[]
        for n in [4,8,16,32,64]:
            m,d,_=solve_strip(AR,al,a2,n); e=errors(m,d,l); rows.append((n,)+e)
        print(name,"l_n=%.4f"%l)
        for k,r in enumerate(rows):
            rate=["-"]*3 if k==0 else [np.log2(rows[k-1][j+1]/r[j+1]) for j in range(3)]
            print("  n=%3d  L2=%.3e H1=%.3e H2=%.3e  rates:"%r, ["%.2f"%x if x!="-" else "-" for x in rate])
        res[name]=dict(l=l,rows=rows)
    json.dump(res,open("conv_strip.json","w"),default=float)
