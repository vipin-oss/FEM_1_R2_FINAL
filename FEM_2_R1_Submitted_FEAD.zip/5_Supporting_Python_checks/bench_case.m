function out = bench_case(ell, N)
geometry.Hb=0.5;geometry.Lb=3*geometry.Hb;geometry.xMin=0;geometry.xMax=geometry.Lb;geometry.yMin=0;geometry.yMax=geometry.Hb;
geometry.L=geometry.xMax;geometry.H=geometry.yMax;
material.E=400;material.nu=0.49;material.lambda=material.E*material.nu/((1+material.nu)*(1-2*material.nu));material.mu=material.E/(2*(1+material.nu));material.model='isotropic_linear_elastic';
gradient.ell=ell;gradient.table.ell=[0.1;0.2;0.3];gradient.table.c3=[0.59;2.35;5.29];gradient.table.c4=[0.59;2.35;5.29];
gradient.table.c5=[0.18;0.74;1.66];gradient.table.c6=[-0.23;-0.91;-2.04];gradient.table.c7=[0.18;0.74;1.66];
gradient.g2=(ell^2/5)*eye(2);gradient.type='Benchmark';
problem.name='b';problem.type='plane_strain';problem.analysis='static';problem.elementType='BFS';
Cmat=constitutive_C(material);Dmat=constitutive_D(Cmat,gradient);constitutive.C=Cmat;constitutive.D=Dmat;
U_top=0.05;
meshParams.Nx=N;meshParams.Ny=N;meshParams.elementType='BFS';meshParams.nodesPerElement=4;meshParams.dofsPerNode=8;meshParams.dofsPerElement=32;
mesh=mesh_generator(geometry,meshParams);ndof=mesh.numDofs;K=sparse(ndof,ndof);F=zeros(ndof,1);
[K,F]=assembly(K,F,mesh,geometry,meshParams,constitutive,material,gradient,problem);
bottomDofs=mesh.bottomDofs(:);bottomVals=zeros(numel(bottomDofs),1);topDofs=mesh.topDofs(:);topVals=zeros(numel(topDofs),1);
boundary=local_build_simple_shear_boundary(mesh,U_top);
[Kb,Fb,bc]=apply_boundary_conditions(K,F,mesh,boundary);
[Kb,Fb,masterDofs,slaveDofs]=local_apply_periodic_lr(Kb,Fb,mesh,boundary,geometry);
solution=solver(Kb,Fb,bc,mesh);solution.displacement(slaveDofs)=solution.displacement(masterDofs);d=solution.displacement;
xMid=geometry.L/2;mid=find(abs(mesh.nodes(:,1)-xMid)<=1e-7*geometry.L);[ys,si]=sort(mesh.nodes(mid(:),2));mid=mid(si);
u=d(mesh.dofMap(mid,1));ue=analytical_solution(ys,geometry,boundary,constitutive);
out=[max(abs(u-ue)),sqrt(mean((u-ue).^2)),sqrt(mean((u-ue).^2))/sqrt(mean(ue.^2)),ndof];
end

function boundary = local_build_simple_shear_boundary(mesh, U_top)
    bottomDofs = mesh.bottomDofs(:);
    topDofs = mesh.topDofs(:);
    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes = numel(topDofs) / 8;

    bottomFixIndices = [];
    for nb = 1:numBottomNodes
        bottomFixIndices = [bottomFixIndices, 8*(nb-1) + [1, 2, 5, 6]]; %#ok<AGROW>
    end
    fixedBottomDofs = bottomDofs(bottomFixIndices);
    bottomVals = zeros(numel(fixedBottomDofs), 1);

    topFixIndices = [];
    for nt = 1:numTopNodes
        topFixIndices = [topFixIndices, 8*(nt-1) + [1, 2, 3, 4, 5, 6]]; %#ok<AGROW>
    end
    fixedTopDofs = topDofs(topFixIndices);
    topVals = zeros(numel(fixedTopDofs), 1);

    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;

    boundary = struct();
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values = [bottomVals(:); topVals(:)];
end

function [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry)
    xTol = 1.0e-7 * geometry.L;
    leftNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMax) <= xTol);
    [~, sortLeft] = sort(mesh.nodes(leftNodeIndices, 2));
    leftNodeIndices = leftNodeIndices(sortLeft);
    [~, sortRight] = sort(mesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);

    masterDofs = [];
    slaveDofs = [];
    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);
        for c = 1:8
            dofL = mesh.dofMap(nodeL, c);
            dofR = mesh.dofMap(nodeR, c);
            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL]; %#ok<AGROW>
                    slaveDofs = [slaveDofs; dofR]; %#ok<AGROW>
                end
            end
        end
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m) = F_bc(m) + F_bc(s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        K_bc(s, :) = 0.0;
        K_bc(:, s) = 0.0;
        K_bc(s, s) = 1.0;
        F_bc(s) = 0.0;
    end
end

