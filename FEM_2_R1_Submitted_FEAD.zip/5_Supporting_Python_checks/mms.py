import numpy as np, sympy as sp_, json, time
from bfs2d import *
x,y=sp_.symbols('x y')
pi=sp_.pi
uex=sp_.sin(2*pi*x)*sp_.sin(pi*y)+sp_.Rational(3,10)*y**2+sp_.Rational(1,5)*sp_.cos(4*pi*x)*y
vex=sp_.cos(2*pi*x)*y*(1-y)+sp_.Rational(1,5)*sp_.sin(pi*y)*sp_.sin(4*pi*x)
def build(E,nu,g):
    C,mu=Cmat(E,nu); Dm=np.kron(g,C)
    Cs=sp_.Matrix(C.tolist()); Ds=sp_.Matrix(Dm.tolist())
    ux,uy,vx,vy=[sp_.diff(f,a) for f in (uex,vex) for a in (x,y)][0],sp_.diff(uex,y),sp_.diff(vex,x),sp_.diff(vex,y)
    eps=sp_.Matrix([ux,vy,uy+vx])
    gv=sp_.Matrix([sp_.diff(uex,x,2),sp_.diff(vex,x,y),sp_.diff(uex,x,y)+sp_.diff(vex,x,2),sp_.diff(uex,x,y),sp_.diff(vex,y,2),sp_.diff(uex,y,2)+sp_.diff(vex,x,y)])
    s=Cs*eps; t=Ds*gv
    bu=-sp_.diff(s[0],x)-sp_.diff(s[2],y)+sp_.diff(t[0],x,2)+sp_.diff(t[2]+t[3],x,y)+sp_.diff(t[5],y,2)
    bv=-sp_.diff(s[1],y)-sp_.diff(s[2],x)+sp_.diff(t[1],x,y)+sp_.diff(t[2],x,2)+sp_.diff(t[4],y,2)+sp_.diff(t[5],x,y)
    f=lambda e: sp_.lambdify((x,y),e,'numpy')
    return C,Dm,f(bu),f(bv)
ex_funcs={k:sp_.lambdify((x,y),e,'numpy') for k,e in {
 'u':uex,'ux':sp_.diff(uex,x),'uy':sp_.diff(uex,y),'uxy':sp_.diff(uex,x,y),'uxx':sp_.diff(uex,x,2),'uyy':sp_.diff(uex,y,2),
 'v':vex,'vx':sp_.diff(vex,x),'vy':sp_.diff(vex,y),'vxy':sp_.diff(vex,x,y),'vxx':sp_.diff(vex,x,2),'vyy':sp_.diff(vex,y,2)}.items()}
def run(n,nu,g):
    C,Dm,bu,bv=build(1.0,nu,g); m=Mesh(n,n)
    K,F=assemble(m,C,Dm,lambda X,Y:(bu(X,Y)*np.ones_like(X),bv(X,Y)*np.ones_like(X)))
    fixed=set(); fv={}
    for i in range(n+1):
        for j in [0,n]:
            nd=m.node(i,j); X=i*m.hx; Y=j*m.hy
            vals=[ex_funcs[k](X,Y) for k in ['u','ux','uy','uxy','v','vx','vy','vxy']]
            for d,vv in enumerate(vals): fixed.add(8*nd+d); fv[8*nd+d]=float(vv)
    ties=[(8*m.node(n,j)+d,8*m.node(0,j)+d) for j in range(n+1) for d in range(8)]
    d=solve(K,F,fixed,fv,ties)
    GP6,GW6=np.polynomial.legendre.leggauss(6); e0=e1=e2=n0=n1=n2=0.0
    for ey in range(n):
        for ex_ in range(n):
            for xi,wx in zip(GP6,GW6):
                for eta,wy in zip(GP6,GW6):
                    f=fields(m,d,xi,eta,ex_,ey); X=(ex_+0.5+xi/2)*m.hx; Y=(ey+0.5+eta/2)*m.hy; w=wx*wy*m.hx*m.hy/4
                    E=lambda k: ex_funcs[k](X,Y)
                    e0+=w*((f['u_N']-E('u'))**2+(f['v_N']-E('v'))**2); n0+=w*(E('u')**2+E('v')**2)
                    e1+=w*((f['u_x']-E('ux'))**2+(f['u_y']-E('uy'))**2+(f['v_x']-E('vx'))**2+(f['v_y']-E('vy'))**2); n1+=w*(E('ux')**2+E('uy')**2+E('vx')**2+E('vy')**2)
                    e2+=w*((f['u_xx']-E('uxx'))**2+2*(f['u_xy']-E('uxy'))**2+(f['u_yy']-E('uyy'))**2+(f['v_xx']-E('vxx'))**2+2*(f['v_xy']-E('vxy'))**2+(f['v_yy']-E('vyy'))**2)
                    n2+=w*(E('uxx')**2+2*E('uxy')**2+E('uyy')**2+E('vxx')**2+2*E('vxy')**2+E('vyy')**2)
    return np.sqrt(e0/n0),np.sqrt(e1/n1),np.sqrt(e2/n2)
if __name__=="__main__":
    al=np.radians(30); a2=0.4; AR=3
    g=gmat(AR*a2,a2,al); print("g=",g)
    out={}
    for nu in [0.3,0.49,0.499]:
        rows=[]
        for n in [4,8,16,32]:
            t=time.time(); e=run(n,nu,g); rows.append((n,)+e)
        print("nu=",nu)
        for k,r in enumerate(rows):
            rate=["-"]*3 if k==0 else [np.log2(rows[k-1][j+1]/r[j+1]) for j in range(3)]
            print("  n=%3d  L2=%.3e H1=%.3e H2=%.3e  rates"%r,["%.2f"%q if q!="-" else "-" for q in rate])
        out[str(nu)]=rows
    json.dump(dict(g=g.tolist(),res=out),open("mms.json","w"),default=float)
