import numpy as np
from ode1d import sol
def run(AR,al,a2):
    a1=AR*a2
    g22=(a1**2*np.sin(np.radians(al))**2+a2**2*np.cos(np.radians(al))**2)/5
    l=np.sqrt(g22); f=sol(l)
    ys=np.linspace(0,1,20001); F=np.array([f(y) for y in ys])
    u1=F[:,1]; u2=F[:,2]; tau=g22*u2
    peak=np.abs(tau).max()/a2
    r=np.abs(tau)/np.abs(tau).max(); idx=np.where(r<=0.01)[0]
    delta=1-ys[idx[-1]]
    Uc=0.5*np.trapezoid(u1**2,ys); Ug=0.5*np.trapezoid(g22*u2**2,ys)
    return dict(l=l,g0=u1[0],peak=peak,delta=delta,Psi_g=100*Ug/(Uc+Ug))
for a2 in [1.0,0.1]:
    print("a2=",a2)
    for AR,al in [(1,0),(1,90),(10,90),(10,45),(5,90),(5,0),(3,45),(5,45),(10,0)]:
        r=run(AR,al,a2); print(AR,al,{k:round(v,4) for k,v in r.items()})
