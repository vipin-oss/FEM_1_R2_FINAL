# Disposition of the external audit (R1 package)

Applied (verified): bibliography corrections (Khakalo2017/2018, Niiranen2016 pages+DOI, Fischer2011 DOI; entries Pech2017, Yildizdag2020,
Shekarchizadeh2024 removed - no matching record found / DOI belongs to an unrelated paper); added Engel2002 (C0 interior-penalty/CDG) and Zervos2009 (2D C1);
re-targeted citations (Lam/McFarland sentence, C1 requirement, BFS sentence); R2.8 reply rewritten accordingly; Eq. (36) definition of delta;
"complete Mindlin Form-II" in Introduction; abstract grammar; empty "Appendix F. Ref" removed; "Appendix Appendix" fixed (paper + letter);
US spelling; author surname/stray ")" ; mesh per figure stated; Table 5 body tracked in blue; Appendix tables numbered D.1; Appendix E precision (plane strain, ell = a/sqrt5);
letter "Additional corrections" extended (delta/H numbers etc.).

Not applied (checked, claim wrong or out of scope): Table 1 row 2 (8.42e-9 / 1.68e-5 is what the code gives: Linf 8.424e-9);
main.m failure (authors' archived driver, unchanged by us; Table 1 is produced by benchmark_validation.m / validation.m with periodic ties);
renaming ell globally; restructuring Section 5; removing unused preamble macros; DOIs for the 8 R1 entries (not verified, left out rather than guessed).

Still to verify by the authors: every entry in reference.bib (DOIs/pages), esp. Engel2002, Zervos2009, KhakaloNiiranen2018, Khakalo2017, Niiranen2016.

## Round 2 (second external audit)
Applied: C0 CDG sentence moved after the mixed-methods remark (the "They avoid ..." ambiguity), "Three main strategies"; BFS sentence now cites Bogner1965 only
(Zervos2009 / Papanicolopulos2009 are not rectangular BFS elements) - letter updated; "locking" wording for C0 elements replaced by "non-conforming" (Engel2002);
"Rezaei et al." (first author of the 2024 pull-out paper); tracked file: separator between \replaced parts, leading spaces moved outside \added (no glued words),
R0 numbers [44,45] restored for deleted BFS refs; reference.bib: Engel2002 author Mazzei, Forest2011 year 2011, Capriz1989 year 1989, Papanicolopulos2009 title C^1;
letter: duplicate "other changes" lists consolidated, funding acknowledgment mentioned; Fig. 12 (collapse) panel spacing; make_figs.py (folder, filenames); block.py default n=64; .bbl files added.
Funding acknowledgment intentionally NOT marked in blue (author's instruction).
Left for the authors (need author information or MATLAB figure regeneration): Declaration of competing interest, CRediT statement, Data availability, Highlights,
Fig. 10/11 label/legend overlaps and Fig. 6 axis limits (MATLAB), review line numbers, frontmatter in elsarticle author/affiliation macros, DOIs of the 8 new entries (unverified), removing 4 uncited bib entries.

## Round 3
Applied: letter (R1.3) now says Abstract/Introduction/Conclusions (not Sec. 5.3) state the no-experiments scope; "three" removed bib entries; tracked "at the both boundaries" glitch.
Already fixed before this audit (audit read an older state): Engel2002 Mazzei, Forest2011 2011, Capriz1989 1989, Yang2020 2023.
Not applied (cosmetic): split citation brackets in tracked file, wrapping every citation edit in \replaced.

## Round 4
Applied: bib fixes GurtinAnand2005 (pages 1624-1649, DOI 10.1016/j.jmps.2004.12.008), Ciarlet (SIAM 2002 reprint year), Zienkiewicz (7th ed.); Sec. 5.1 "a boundary layer" now tracked in blue.
Not applied: marking the reference list itself in blue in the tracked file; trailing "delta/H" fragment of Eq. (36).

## Round 5
Response letter rewritten in the style of the authors' earlier letter: all cross-references are literal numbers (taken from paper_R1_clean.aux), no xr/\ref, so it compiles standalone without "??".

## Round 6 (final language pass)
- Tracked version: deletions no longer shown; only blue additions remain.
- Removed navigational "(Section X)" pointers from added text; simplified wording. Numbering of equations/tables/figures unchanged.
- Response letter rewritten in the short Reviewer/Comment format.
