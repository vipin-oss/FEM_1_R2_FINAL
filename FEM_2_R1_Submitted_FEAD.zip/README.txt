FEM2 - R1 package (FINEL-D-26-00692, Finite Elements in Analysis and Design)

1_Response_to_Reviewers : point-wise reply (PDF + tex)
2_Manuscript_R1         : paper_R1_tracked.pdf (changes in blue) and paper_R1_clean.pdf
3_LaTeX_source          : all tex, bbl, reference.bib, figures (Fig01-Fig11 EPS as submitted; Fig12, Fig13 PDF). Compile paper_R1_clean and paper_R1_tracked with pdflatex/bibtex/pdflatex x2; Response_to_Reviewers.tex compiles standalone (numbers are literal).
                          Compile: pdflatex/bibtex/pdflatex x2 on paper_R1_clean (and paper_R1_tracked);
                          then Response_to_Reviewers (needs paper_R1_clean.aux for cross-refs, included).
                          EPS need -shell-escape-free epstopdf (auto) or convert with ghostscript.
4_MATLAB_Program        : authors' MATLAB code (Program.zip contents), unchanged
5_Supporting_Python_checks : independent replica scripts + Octave drivers (run_case.m etc.) used for cross-checks and new Tables/Figs 12-13
CROSSCHECK_NOTES.md     : code-vs-paper check results

OPEN ITEMS FOR AUTHORS
1. reference.bib was corrected in R1 (see AUDIT_DISPOSITION.md); still verify every entry (DOIs, pages), especially Engel2002, Zervos2009, KhakaloNiiranen2018, Khakalo2017, Niiranen2016.
2. Fig12/Fig13 are matplotlib (Times-style); regenerate in MATLAB if an exact style match is required.
(delta/H numbers in text were corrected to the code/figure values - see CROSSCHECK_NOTES.md)
