function shape = bfs_shape_functions(xi)
%BFS_SHAPE_FUNCTIONS One-dimensional cubic Hermite basis for BFS element.
%
%   shape = bfs_shape_functions(xi)
%
%   Part 1 only:
%   ------------
%   This routine evaluates the one-dimensional cubic Hermite basis
%   functions used by the Bogner--Fox--Schmit (BFS) rectangular element.
%
%   It returns only the 1D quantities:
%
%       shape.H    : values of [H1 H2 H3 H4]
%       shape.dH   : first derivatives with respect to xi
%       shape.d2H  : second derivatives with respect to xi
%
%   This routine does NOT construct two-dimensional tensor-product BFS
%   functions, does NOT compute Jacobians, does NOT compute B matrices,
%   and does NOT compute stiffness matrices.
%
%   Input
%   -----
%   xi : vector of evaluation points in the parent interval [-1,1].
%        These points may be Gauss points or any arbitrary evaluation
%        points.
%
%   Output
%   ------
%   shape : structure with fields H, dH, d2H.
%
%   One-dimensional Hermite interpolation
%   -------------------------------------
%   Let p(xi) be a cubic polynomial on [-1,1]:
%
%       p(xi) = a0 + a1*xi + a2*xi^2 + a3*xi^3.
%
%   The cubic Hermite interpolation is written as
%
%       p(xi) = H1(xi)*p(-1) + H2(xi)*p_xi(-1)
%             + H3(xi)*p( 1) + H4(xi)*p_xi( 1).
%
%   Therefore, the basis functions satisfy the interpolation conditions:
%
%       H1(-1)=1, H1_xi(-1)=0, H1( 1)=0, H1_xi( 1)=0,
%       H2(-1)=0, H2_xi(-1)=1, H2( 1)=0, H2_xi( 1)=0,
%       H3(-1)=0, H3_xi(-1)=0, H3( 1)=1, H3_xi( 1)=0,
%       H4(-1)=0, H4_xi(-1)=0, H4( 1)=0, H4_xi( 1)=1.
%
%   Derivation from first principles
%   --------------------------------
%   Assume H(xi)=a0+a1*xi+a2*xi^2+a3*xi^3 and impose the four nodal
%   interpolation conditions for each basis function.
%
%   For H1:
%       a0 - a1 + a2 - a3 = 1,
%       a1 - 2*a2 + 3*a3 = 0,
%       a0 + a1 + a2 + a3 = 0,
%       a1 + 2*a2 + 3*a3 = 0.
%   Solving gives
%       a0=1/2, a1=-3/4, a2=0, a3=1/4.
%   Hence
%       H1 = (2 - 3*xi + xi^3)/4.
%
%   For H2:
%       a0 - a1 + a2 - a3 = 0,
%       a1 - 2*a2 + 3*a3 = 1,
%       a0 + a1 + a2 + a3 = 0,
%       a1 + 2*a2 + 3*a3 = 0.
%   Solving gives
%       a0=1/4, a1=-1/4, a2=-1/4, a3=1/4.
%   Hence
%       H2 = (1 - xi - xi^2 + xi^3)/4.
%
%   For H3:
%       a0 - a1 + a2 - a3 = 0,
%       a1 - 2*a2 + 3*a3 = 0,
%       a0 + a1 + a2 + a3 = 1,
%       a1 + 2*a2 + 3*a3 = 0.
%   Solving gives
%       a0=1/2, a1=3/4, a2=0, a3=-1/4.
%   Hence
%       H3 = (2 + 3*xi - xi^3)/4.
%
%   For H4:
%       a0 - a1 + a2 - a3 = 0,
%       a1 - 2*a2 + 3*a3 = 0,
%       a0 + a1 + a2 + a3 = 0,
%       a1 + 2*a2 + 3*a3 = 1.
%   Solving gives
%       a0=-1/4, a1=-1/4, a2=1/4, a3=1/4.
%   Hence
%       H4 = (-1 - xi + xi^2 + xi^3)/4.

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 1
    error('bfs_shape_functions:InvalidInputCount', ...
          'bfs_shape_functions requires exactly one input: xi.');
end

if ~isnumeric(xi) || ~isreal(xi) || isempty(xi)
    error('bfs_shape_functions:InvalidXi', ...
          'Input xi must be a nonempty real numeric vector.');
end

if ~isvector(xi)
    error('bfs_shape_functions:InvalidXiShape', ...
          'Input xi must be a vector of evaluation points.');
end

if any(~isfinite(xi(:)))
    error('bfs_shape_functions:NonFiniteXi', ...
          'All evaluation points in xi must be finite.');
end

% Use a column vector internally.  The output has one row per evaluation
% point and four columns corresponding to H1, H2, H3, and H4.
xi = xi(:);

% Parent-domain validation.  The Hermite basis is defined on [-1, 1].
% Values outside this interval are allowed for diagnostic/evaluation
% purposes, but a warning is issued because they lie outside the parent
% element.
parentTolerance = 1.0e-12;
if any(abs(xi) > 1.0 + parentTolerance)
    warning('bfs_shape_functions:PointOutsideParentDomain', ...
            ['One or more evaluation points satisfy |xi| > 1 + %.1e ', ...
             'and therefore lie outside the parent element [-1, 1].'], ...
             parentTolerance);
end

%==========================================================================
% 2. Explicit Hermite basis functions
%==========================================================================

H1 = (2.0 - 3.0*xi + xi.^3) / 4.0;
H2 = (1.0 - xi - xi.^2 + xi.^3) / 4.0;
H3 = (2.0 + 3.0*xi - xi.^3) / 4.0;
H4 = (-1.0 - xi + xi.^2 + xi.^3) / 4.0;

% First derivatives dH/dxi.
dH1 = (-3.0 + 3.0*xi.^2) / 4.0;
dH2 = (-1.0 - 2.0*xi + 3.0*xi.^2) / 4.0;
dH3 = (3.0 - 3.0*xi.^2) / 4.0;
dH4 = (-1.0 + 2.0*xi + 3.0*xi.^2) / 4.0;

% Second derivatives d2H/dxi2.
d2H1 = (3.0*xi) / 2.0;
d2H2 = (-1.0 + 3.0*xi) / 2.0;
d2H3 = -(3.0*xi) / 2.0;
d2H4 = (1.0 + 3.0*xi) / 2.0;

% Store in matrices.
shape.H = [H1, H2, H3, H4];
shape.dH = [dH1, dH2, dH3, dH4];
shape.d2H = [d2H1, d2H2, d2H3, d2H4];

% Store interpolation metadata for downstream debugging and post-processing.
shape.order = 3;
shape.family = 'Cubic Hermite';
shape.element = 'Bogner-Fox-Schmit';

% Verify output dimensions.
if size(shape.H, 2) ~= 4
    error('bfs_shape_functions:InvalidHDimension', ...
          'shape.H must have exactly 4 columns corresponding to H1, H2, H3, H4.');
end

if size(shape.dH, 2) ~= 4
    error('bfs_shape_functions:InvaliddHDimension', ...
          'shape.dH must have exactly 4 columns corresponding to dH1, dH2, dH3, dH4.');
end

if size(shape.d2H, 2) ~= 4
    error('bfs_shape_functions:Invalidd2HDimension', ...
          'shape.d2H must have exactly 4 columns corresponding to d2H1, d2H2, d2H3, d2H4.');
end

if size(shape.H, 1) ~= size(shape.dH, 1) || ...
   size(shape.H, 1) ~= size(shape.d2H, 1)
    error('bfs_shape_functions:InconsistentRowDimension', ...
          ['shape.H, shape.dH, and shape.d2H must have the same ', ...
           'number of rows, one row per evaluation point.']);
end

%==========================================================================
% 3. Internal verification checks
%==========================================================================

verificationTolerance = 1.0e-12;

% Check partition relation for value interpolation functions.
% H1 and H3 are the endpoint value functions, so H1 + H3 = 1.
partitionError = max(abs((H1 + H3) - 1.0));
if partitionError > verificationTolerance
    error('bfs_shape_functions:PartitionCheckFailed', ...
          ['Internal check failed: H1 + H3 differs from 1. ', ...
           'Maximum error = %.3e.'], partitionError);
end

% Check derivative identities associated with the partition relation.
% Since H1 + H3 = 1, their first derivative sum must be zero and their
% second derivative sum must also be zero.
partitionDerivativeError = max(abs(dH1 + dH3));
if partitionDerivativeError > verificationTolerance
    error('bfs_shape_functions:PartitionDerivativeCheckFailed', ...
          ['Internal check failed: dH1/dxi + dH3/dxi differs from 0. ', ...
           'Maximum error = %.3e.'], partitionDerivativeError);
end

partitionSecondDerivativeError = max(abs(d2H1 + d2H3));
if partitionSecondDerivativeError > verificationTolerance
    error('bfs_shape_functions:PartitionSecondDerivativeCheckFailed', ...
          ['Internal check failed: d2H1/dxi2 + d2H3/dxi2 differs from 0. ', ...
           'Maximum error = %.3e.'], partitionSecondDerivativeError);
end

% Check interpolation properties at xi = -1 and xi = 1.
xiEnd = [-1.0; 1.0];

H_end = [ ...
    (2.0 - 3.0*xiEnd + xiEnd.^3) / 4.0, ...
    (1.0 - xiEnd - xiEnd.^2 + xiEnd.^3) / 4.0, ...
    (2.0 + 3.0*xiEnd - xiEnd.^3) / 4.0, ...
    (-1.0 - xiEnd + xiEnd.^2 + xiEnd.^3) / 4.0];

dH_end = [ ...
    (-3.0 + 3.0*xiEnd.^2) / 4.0, ...
    (-1.0 - 2.0*xiEnd + 3.0*xiEnd.^2) / 4.0, ...
    (3.0 - 3.0*xiEnd.^2) / 4.0, ...
    (-1.0 + 2.0*xiEnd + 3.0*xiEnd.^2) / 4.0];

% Expected function values at endpoints:
% rows: xi = -1, xi = 1
% cols: H1, H2, H3, H4
H_expected = [ ...
    1.0, 0.0, 0.0, 0.0; ...
    0.0, 0.0, 1.0, 0.0];

% Expected first derivatives at endpoints:
% rows: xi = -1, xi = 1
% cols: H1, H2, H3, H4
dH_expected = [ ...
    0.0, 1.0, 0.0, 0.0; ...
    0.0, 0.0, 0.0, 1.0];

H_endpoint_error = max(abs(H_end(:) - H_expected(:)));
dH_endpoint_error = max(abs(dH_end(:) - dH_expected(:)));

if H_endpoint_error > verificationTolerance
    error('bfs_shape_functions:EndpointValueCheckFailed', ...
          ['Internal check failed: endpoint values are incorrect. ', ...
           'Maximum error = %.3e.'], H_endpoint_error);
end

if dH_endpoint_error > verificationTolerance
    error('bfs_shape_functions:EndpointDerivativeCheckFailed', ...
          ['Internal check failed: endpoint derivatives are incorrect. ', ...
           'Maximum error = %.3e.'], dH_endpoint_error);
end

end
