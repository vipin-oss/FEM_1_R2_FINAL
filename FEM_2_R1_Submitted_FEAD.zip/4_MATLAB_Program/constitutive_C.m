function Cmat = constitutive_C(material)
%CONSTITUTIVE_C Construct isotropic plane-strain constitutive matrix.
%
%   Cmat = constitutive_C(material)
%
%   Purpose
%   -------
%   Constructs the classical plane-strain constitutive matrix for an
%   isotropic linear elastic material using the engineering strain vector
%
%       epsilon = [epsilon_xx; epsilon_yy; gamma_xy],
%
%   where
%
%       epsilon_xx = du/dx,
%       epsilon_yy = dv/dy,
%       gamma_xy   = du/dy + dv/dx.
%
%   Inputs
%   ------
%   material : structure with fields
%       material.E  : Young's modulus
%       material.nu : Poisson's ratio
%
%   Outputs
%   -------
%   Cmat : structure with fields
%       Cmat.C        : [3 x 3] plane-strain isotropic constitutive matrix
%       Cmat.lambda   : first Lame parameter
%       Cmat.mu       : shear modulus
%       Cmat.type     : material model description
%       Cmat.dimension: matrix dimension, equal to 3
%
%   Derivation
%   ----------
%   For three-dimensional isotropic linear elasticity,
%
%       sigma_ij = lambda * epsilon_kk * delta_ij + 2*mu*epsilon_ij.
%
%   The Lame constants are
%
%       lambda = E*nu / ((1+nu)*(1-2*nu)),
%       mu     = E / (2*(1+nu)).
%
%   Under plane strain,
%
%       epsilon_zz = 0,
%       gamma_xz   = 0,
%       gamma_yz   = 0,
%
%   so
%
%       epsilon_kk = epsilon_xx + epsilon_yy.
%
%   The in-plane normal stresses become
%
%       sigma_xx = lambda*(epsilon_xx + epsilon_yy) + 2*mu*epsilon_xx
%                = (lambda + 2*mu)*epsilon_xx + lambda*epsilon_yy,
%
%       sigma_yy = lambda*(epsilon_xx + epsilon_yy) + 2*mu*epsilon_yy
%                = lambda*epsilon_xx + (lambda + 2*mu)*epsilon_yy.
%
%   For engineering shear strain gamma_xy = 2*epsilon_xy,
%
%       sigma_xy = 2*mu*epsilon_xy = mu*gamma_xy.
%
%   Therefore,
%
%       [sigma_xx]   [lambda+2mu   lambda        0] [epsilon_xx]
%       [sigma_yy] = [lambda       lambda+2mu    0] [epsilon_yy]
%       [sigma_xy]   [0            0             mu] [gamma_xy  ].
%
%   This is the classical plane-strain isotropic constitutive matrix used
%   with the engineering B matrix.

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 1
    error('constitutive_C:InvalidInputCount', ...
          'constitutive_C requires exactly one input: material.');
end

if ~isstruct(material)
    error('constitutive_C:InvalidMaterial', ...
          'Input material must be a structure.');
end

if ~isfield(material, 'E')
    error('constitutive_C:MissingYoungsModulus', ...
          'material.E is required.');
end

if ~isfield(material, 'nu')
    error('constitutive_C:MissingPoissonsRatio', ...
          'material.nu is required.');
end

E = material.E;
nu = material.nu;

if ~isnumeric(E) || ~isreal(E) || ~isscalar(E) || ~isfinite(E)
    error('constitutive_C:InvalidYoungsModulus', ...
          'material.E must be a finite real scalar.');
end

if ~isnumeric(nu) || ~isreal(nu) || ~isscalar(nu) || ~isfinite(nu)
    error('constitutive_C:InvalidPoissonsRatio', ...
          'material.nu must be a finite real scalar.');
end

if E <= 0.0
    error('constitutive_C:NonPositiveYoungsModulus', ...
          'material.E must be positive.');
end

% For positive-definite three-dimensional isotropic elasticity, the
% admissible range is -1 < nu < 1/2.
if nu <= -1.0 || nu >= 0.5
    error('constitutive_C:InvalidPoissonsRatioRange', ...
          'material.nu must satisfy -1 < nu < 0.5 for positive-definite isotropic elasticity.');
end

%==========================================================================
% 2. Lame constants
%==========================================================================

lambda = E * nu / ((1.0 + nu) * (1.0 - 2.0 * nu));
mu     = E / (2.0 * (1.0 + nu));

if ~isfinite(lambda) || ~isfinite(mu)
    error('constitutive_C:NonFiniteLameConstants', ...
          'Computed Lame constants are not finite. Check E and nu.');
end

if mu <= 0.0
    error('constitutive_C:NonPositiveShearModulus', ...
          'Computed shear modulus mu must be positive.');
end

%==========================================================================
% 3. Plane-strain isotropic constitutive matrix
%==========================================================================

C = [ ...
    lambda + 2.0*mu,  lambda,           0.0; ...
    lambda,           lambda + 2.0*mu,  0.0; ...
    0.0,              0.0,              mu];

%==========================================================================
% 4. Internal verification
%==========================================================================

if ~isequal(size(C), [3, 3])
    error('constitutive_C:InvalidCSize', ...
          'The constitutive matrix C must have size [3 x 3].');
end

if any(~isfinite(C(:)))
    error('constitutive_C:NonFiniteCEntries', ...
          'The constitutive matrix C contains non-finite entries.');
end

symmetryTolerance = 1.0e-12;
symmetryError = max(max(abs(C - C.')));
if symmetryError > symmetryTolerance
    error('constitutive_C:NonSymmetricC', ...
          'C must be symmetric. Symmetry error = %.3e.', symmetryError);
end

C_eig = eig(C);
if any(~isfinite(C_eig))
    error('constitutive_C:NonFiniteEigenvalues', ...
          'Eigenvalues of C are not finite.');
end

if any(C_eig <= 0.0)
    error('constitutive_C:NonPositiveEigenvalues', ...
          ['C must be positive definite. Minimum eigenvalue = %.16e.'], ...
          min(C_eig));
end

C_det = det(C);
if ~isfinite(C_det)
    error('constitutive_C:NonFiniteDeterminant', ...
          'det(C) is not finite.');
end

if C_det <= 0.0
    error('constitutive_C:NonPositiveDeterminant', ...
          'det(C) must be positive. det(C) = %.16e.', C_det);
end

% Compute condition number for diagnostic purposes.  A large value may
% indicate near-incompressibility or poor conditioning, but does not by
% itself invalidate the constitutive matrix.
C_conditionNumber = cond(C);
if C_conditionNumber > 1.0e8
    warning('constitutive_C:LargeConditionNumber', ...
            'Condition number of C is large: cond(C) = %.3e.', ...
            C_conditionNumber);
end

% Energy positivity verification using a random test strain vector.
% Since C is positive definite, any nonzero strain vector must produce
% positive strain energy density.
epsilon_test = randn(3, 1);
W_test = 0.5 * epsilon_test.' * C * epsilon_test;

if W_test <= 0.0
    error('constitutive_C:NonPositiveEnergyDensity', ...
          'Energy verification failed: W = %.16e must be positive.', W_test);
end

energyVerification = true;

%==========================================================================
% 5. Store output structure
%==========================================================================

Cmat = struct();

Cmat.C = C;
Cmat.lambda = lambda;
Cmat.mu = mu;
Cmat.E = E;
Cmat.nu = nu;
Cmat.type = 'Plane strain isotropic';
Cmat.dimension = 3;
Cmat.strainOrdering = {'epsilon_xx', 'epsilon_yy', 'gamma_xy'};
Cmat.stressOrdering = {'sigma_xx', 'sigma_yy', 'sigma_xy'};
Cmat.symmetryError = symmetryError;
Cmat.eigenvalues = C_eig;
Cmat.determinant = C_det;
Cmat.conditionNumber = C_conditionNumber;
Cmat.energyVerification = energyVerification;
Cmat.energyTestStrain = epsilon_test;
Cmat.energyTestValue = W_test;

end
