%% main.m
%=========================================================================%
%  BFS Plane-Strain Strain-Gradient Elasticity FEM Solver - Master Driver
%=========================================================================%
%  Purpose:
%    Complete research-grade master driver for the MATLAB implementation of
%    the two-dimensional plane-strain Mindlin Form-II strain-gradient
%    finite element solver using C1-continuous Bogner-Fox-Schmit (BFS)
%    rectangular elements.
%
%  Current Execution Stage:
%    AUTOMATED MESH CONVERGENCE & AUTHORITATIVE BENCHMARK VALIDATION
%
%  Finalized Pipeline Modules:
%    1. mesh_generator()            : Structured BFS Cartesian mesh
%    2. constitutive_C()            : Classical plane-strain elasticity
%    3. constitutive_D()            : Mindlin Form-II gradient elasticity
%    4. assembly()                  : Global stiffness and force assembly
%    5. apply_boundary_conditions() : Symmetric Dirichlet BC elimination
%    6. solver()                    : Direct sparse backslash solver
%    7. analytical_solution()       : Exact continuum benchmark profile
%=========================================================================%

%% 1. Clear environment and initialize execution
clear;
clc;
close all;

%% 2. Problem identification
problem.name        = 'Benchmark simple-shear strain-gradient elasticity';
problem.type        = 'plane_strain';
problem.analysis    = 'static';
problem.elementType = 'BFS';
problem.description = ['Code verification benchmark, mesh convergence, ', ...
                       'and authoritative literature validation study ', ...
                       'following the two-dimensional strain-gradient ', ...
                       'elasticity simple-shear problem.'];

fprintf('====================================================================================================\n');
fprintf(' BFS Plane-Strain Strain-Gradient Elasticity FEM Solver - Benchmark Validation Study\n');
fprintf('====================================================================================================\n');
fprintf(' Problem      : %s\n', problem.name);
fprintf(' Element type : %s\n', problem.elementType);
fprintf('====================================================================================================\n\n');

%% 3. Define benchmark geometry
% Benchmark strip dimensions: Height Hb = 0.5 mm, Length Lb = 1.5 mm
geometry.Hb   = 0.5;
geometry.Lb   = 3.0 * geometry.Hb;
geometry.xMin = 0.0;
geometry.xMax = geometry.Lb;
geometry.yMin = 0.0;
geometry.yMax = geometry.Hb;
geometry.L    = geometry.xMax - geometry.xMin;
geometry.H    = geometry.yMax - geometry.yMin;

fprintf('Geometry defined [Length L = %.6g mm, Height H = %.6g mm].\n', geometry.L, geometry.H);

%% 4. Define material parameters
% Nearly incompressible benchmark material: E = 400 MPa, nu = 0.49
material.E      = 400.0;
material.nu     = 0.49;
material.lambda = material.E * material.nu / ...
                 ((1.0 + material.nu)  *(1.0 - 2.0*  material.nu));
material.mu     = material.E / (2.0 * (1.0 + material.nu));
material.model  = 'isotropic_linear_elastic';

fprintf('Classical material defined [E = %.6g MPa, nu = %.6g].\n', material.E, material.nu);

%% 5. Define strain-gradient parameters
% Active characteristic length scale and literature benchmark constants
gradient.lengthList = [0.1, 0.2, 0.3];
gradient.ell        = gradient.lengthList(1);
gradient.table.ell  = [0.1; 0.2; 0.3];
gradient.table.c3   = [0.59; 2.35; 5.29];
gradient.table.c4   = [0.59; 2.35; 5.29];
gradient.table.c5   = [0.18; 0.74; 1.66];
gradient.table.c6   = [-0.23; -0.91; -2.04];
gradient.table.c7   = [0.18; 0.74; 1.66];
gradient.g2         = (gradient.ell^2 / 5.0) * eye(2);
gradient.type       = 'Benchmark';

fprintf('Gradient parameters defined [Active ell = %.6g mm, Mode: %s].\n\n', gradient.ell, gradient.type);

%% 6. Construct constitutive elasticity tensors (invariant across mesh refinement)
Cmat = constitutive_C(material);
Dmat = constitutive_D(Cmat, gradient);
constitutive.C = Cmat;
constitutive.D = Dmat;

%% 7. Automated Mesh Convergence & Validation Sweeps
meshList  = [4, 8, 16, 32];
numMeshes = numel(meshList);

numElemList   = zeros(numMeshes, 1);
numNodeList   = zeros(numMeshes, 1);
numDofList    = zeros(numMeshes, 1);
cpuTimeList   = zeros(numMeshes, 1);
resList       = zeros(numMeshes, 1);
condList      = zeros(numMeshes, 1);
maxUList      = zeros(numMeshes, 1);
maxVList      = zeros(numMeshes, 1);
maxAnaList    = zeros(numMeshes, 1);
LinfList      = zeros(numMeshes, 1);
L2List        = zeros(numMeshes, 1);
relL2List     = zeros(numMeshes, 1);
hList         = zeros(numMeshes, 1);

% Prescribed top horizontal simple-shear glide displacement
% Case 1 displacement prescription benchmark uses 0.05 mm
U_top = 0.05; 

fprintf('Executing automated convergence sweeps and point-by-point validation...\n');
for m = 1:numMeshes
    N = meshList(m);
    
    meshParams.Nx              = N;
    meshParams.Ny              = N;
    meshParams.elementType     = 'BFS';
    meshParams.nodesPerElement = 4;
    meshParams.dofsPerNode     = 8;
    meshParams.dofsPerElement  = 32;
    
    % Generate structured finite element mesh
    mesh = mesh_generator(geometry, meshParams);
    ndof = mesh.numDofs;
    
    % Allocate sparse global system arrays
    K_global = sparse(ndof, ndof);
    F_global = zeros(ndof, 1);
    
    % Measure CPU time for Assembly + BC Enforcement + Solve
    tStartTime = tic;
    
    [K_global, F_global, assemblyMeta] = assembly(K_global, F_global, mesh, ...
        geometry, meshParams, constitutive, material, gradient, problem);
    
    % Define Dirichlet boundary conditions
    % Flatten bottom and top DOFs
    bottomDofs = mesh.bottomDofs(:);
    topDofs    = mesh.topDofs(:);
    
    % Determine the number of nodes on each boundary
    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes    = numel(topDofs) / 8;
    
    % Bottom boundary (y = 0): Fix only u (1), ux (2), v (5), vx (6) for each node.
    % Leave uy (3), uxy (4), vy (7), vxy (8) FREE to satisfy natural boundary conditions weakly.
    bottomFixIndices = [];
    for i = 1:numBottomNodes
        offset = 8 * (i - 1);
        bottomFixIndices = [bottomFixIndices, offset + [1, 2, 5, 6]];
    end
    fixedBottomDofs = bottomDofs(bottomFixIndices);
    bottomVals      = zeros(numel(fixedBottomDofs), 1);
    
    % Top boundary (y = H): Fix only u (1), ux (2), uy (3), uxy (4), v (5), vx (6) for each node.
    % Leave vy (7), vxy (8) FREE to satisfy natural boundary conditions weakly.
    topFixIndices = [];
    for i = 1:numTopNodes
        offset = 8 * (i - 1);
        topFixIndices = [topFixIndices, offset + [1, 2, 3, 4, 5, 6]];
    end
    fixedTopDofs = topDofs(topFixIndices);
    topVals      = zeros(numel(fixedTopDofs), 1);
    
    % Set horizontal displacement u (first fixed DOF of each top node) to U_top
    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;
    
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values    = [bottomVals(:); topVals(:)];
    
    [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, mesh, boundary);
    
    % Enforce lateral periodic boundary conditions (d_right = d_left)
    % using Symmetric Master-Slave Elimination directly on K_bc and F_bc
    xTol = 1.0e-7 * geometry.L;
    leftNodeIndices  = find(abs(mesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMax) <= xTol);
    
    [~, sortLeft]    = sort(mesh.nodes(leftNodeIndices, 2));
    leftNodeIndices  = leftNodeIndices(sortLeft);
    
    [~, sortRight]   = sort(mesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);
    
    masterDofs = [];
    slaveDofs  = [];
    
    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);
        
        for c = 1:8
            dofL = mesh.dofMap(nodeL, c);
            dofR = mesh.dofMap(nodeR, c);
            
            % Enforce coupling only if neither DOF is fixed by Dirichlet BCs
            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL];
                    slaveDofs  = [slaveDofs; dofR];
                end
            end
        end
    end
    
    % Step 1: Add slave rows/cols of K_bc and F_bc to master rows/cols
    for i = 1:numel(slaveDofs)
        s = slaveDofs(i);
        m = masterDofs(i);
        
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m)    = F_bc(m)    + F_bc(s);
    end
    for i = 1:numel(slaveDofs)
        s = slaveDofs(i);
        m = masterDofs(i);
        
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end
    % Step 2: Zero out slave rows and columns, set diagonal to 1
    for i = 1:numel(slaveDofs)
        s = slaveDofs(i);
        
        K_bc(s, :) = 0;
        K_bc(:, s) = 0;
        K_bc(s, s) = 1;
        F_bc(s)    = 0;
    end
    
    solution = solver(K_bc, F_bc, bc, mesh);
    
    % Step 3: Reconstruct slave displacements from master displacements
    solution.displacement(slaveDofs) = solution.displacement(masterDofs);
    
    cpuTime = toc(tStartTime);
    
    % Extract maximum horizontal and vertical nodal displacements across entire mesh
    d_vec   = solution.displacement;
    u_nodes = d_vec(mesh.dofMap(:, 1));
    v_nodes = d_vec(mesh.dofMap(:, 5));
    
    % Extract mid-span benchmark comparison vertical line (x approx L/2)
    xMid = geometry.L / 2.0;
    xTol = 1.0e-7 * geometry.L;
    midNodeIndices = find(abs(mesh.nodes(:, 1) - xMid) <= xTol);
    
    [yMidSort, sortIdx] = sort(mesh.nodes(midNodeIndices, 2));
    midNodeIndices      = midNodeIndices(sortIdx);
    
    u_fem   = d_vec(mesh.dofMap(midNodeIndices, 1));
    u_exact = analytical_solution(yMidSort, geometry, boundary, constitutive);
    
    % Point-by-point error calculations
    Linf       = max(abs(u_fem - u_exact));
    L2         = sqrt(mean((u_fem - u_exact).^2));
    RelativeL2 = L2 / max(1.0e-15, sqrt(mean(u_exact.^2)));
    
    maxFEM = max(abs(u_fem));
    maxAna = max(abs(u_exact));
    
    numElemList(m) = mesh.numElements;
    numNodeList(m) = mesh.numNodes;
    numDofList(m)  = ndof;
    cpuTimeList(m) = cpuTime;
    resList(m)     = solution.residual;
    condList(m)    = solution.conditionNumber;
    maxUList(m)    = max(abs(u_nodes));
    maxVList(m)    = max(abs(v_nodes));
    maxAnaList(m)  = maxAna;
    LinfList(m)    = Linf;
    L2List(m)      = L2;
    relL2List(m)   = RelativeL2;
    hList(m)       = geometry.H / N;
    
    if m == numMeshes
        finest_u_fem = u_fem;
        finest_y_mid = yMidSort;
    end
    
    fprintf('  Completed Grid Nx=Ny=%2d | Elements: %4d | DOFs: %6d | CPU: %.4fs | Linf: %.2e\n', ...
        N, mesh.numElements, ndof, cpuTime, Linf);
end
fprintf('\n');

%% 8. Package Convergence Results Structure
convergenceResults = struct();
convergenceResults.gridSizes      = meshList(:);
convergenceResults.numElements    = numElemList;
convergenceResults.numNodes       = numNodeList;
convergenceResults.totalDOFs      = numDofList;
convergenceResults.cpuTime        = cpuTimeList;
convergenceResults.residual       = resList;
convergenceResults.condNumber     = condList;
convergenceResults.maxU           = maxUList;
convergenceResults.maxV           = maxVList;
convergenceResults.MaxAnalyticalU = maxAnaList;
convergenceResults.LinfError      = LinfList;
convergenceResults.L2Error        = L2List;
convergenceResults.RelativeL2Error= relL2List;

%% 9. Display Extended Results Table
fprintf('========================================================================================================================\n');
fprintf(' MESH CONVERGENCE & BENCHMARK VALIDATION SUMMARY TABLE\n');
fprintf('========================================================================================================================\n');
try
    convTable = table(meshList(:), numElemList, numNodeList, numDofList, ...
                      cpuTimeList, resList, condList, maxUList, maxVList, ...
                      maxAnaList, LinfList, L2List, relL2List, ...
        'VariableNames', {'GridSize', 'Elements', 'Nodes', 'TotalDOFs', ...
                          'CPUTime_s', 'Residual', 'CondNumber', 'MaxU_mm', 'MaxV_mm', ...
                          'MaxAnalyticalU', 'LinfError', 'L2Error', 'RelativeL2Error'});
    disp(convTable);
catch
    for m = 1:numMeshes
        fprintf(' Grid %2dx%2d | Elem: %4d | DOFs: %6d | CPU: %6.4fs | MaxU: %.6f | ExactU: %.6f | Linf: %.2e | L2: %.2e | RelL2: %.2e\n', ...
            meshList(m), meshList(m), numElemList(m), numDofList(m), cpuTimeList(m), ...
            maxUList(m), maxAnaList(m), LinfList(m), L2List(m), relL2List(m));
    end
end
fprintf('========================================================================================================================\n\n');

%% 10. Generate Master Convergence Curves
figure('Name', 'BFS Strain-Gradient FEM - Convergence Curves', 'NumberTitle', 'off');
subplot(1, 3, 1);
plot(numDofList, maxUList, '-bo', 'LineWidth', 1.5, 'MarkerSize', 6, 'MarkerFaceColor', 'b');
grid on; title('Max Horizontal Displacement u');
xlabel('Total System DOFs'); ylabel('Max u [mm]');

subplot(1, 3, 2);
plot(numDofList, cpuTimeList, '-rs', 'LineWidth', 1.5, 'MarkerSize', 6, 'MarkerFaceColor', 'r');
grid on; title('CPU Time vs DOFs');
xlabel('Total System DOFs'); ylabel('Execution Time [s]');

subplot(1, 3, 3);
semilogy(numDofList, resList, '-m^', 'LineWidth', 1.5, 'MarkerSize', 6, 'MarkerFaceColor', 'm');
grid on; title('Equilibrium Residual');
xlabel('Total System DOFs'); ylabel('Residual Norm ||R|| (log scale)');

%% 11. Generate Literature Benchmark Validation Figures
%-------------------------------------------------------
% Figure 1: FEM vs Analytical displacement profile
%-------------------------------------------------------
figProfile = figure('Name', 'Validation Figure 1: FEM vs Analytical Profile', 'NumberTitle', 'off');
yDense = linspace(0.0, geometry.H, 200).';
uExactDense = analytical_solution(yDense, geometry, boundary, constitutive);
plot(uExactDense, yDense, '-k', 'LineWidth', 2.0, 'DisplayName', 'analytical solution');
hold on;
plot(finest_u_fem, finest_y_mid, 'ro', 'LineWidth', 1.5, 'MarkerSize', 6, 'DisplayName', 'FEM solution');
grid on;
title('FEM vs Analytical Mid-Span Displacement Profile');
xlabel('Horizontal displacement u [mm]'); ylabel('Vertical coordinate y [mm]');
legend('Location', 'northwest');

%-------------------------------------------------------
% Compute observed convergence rates (Rc)
%-------------------------------------------------------
fprintf('====================================================================================================\n');
fprintf(' OBSERVED ERROR CONVERGENCE RATES (Rc)\n');
fprintf('====================================================================================================\n');
for k = 1:(numMeshes - 1)
    Rc_L2   = log(L2List(k)   / L2List(k + 1))   / log(hList(k) / hList(k + 1));
    Rc_Linf = log(LinfList(k) / LinfList(k + 1)) / log(hList(k) / hList(k + 1));
    fprintf('  Between Grid %2dx%2d and %2dx%2d (h1/h2 = %.1f) : Rc (L2) = %.4f | Rc (Linf) = %.4f\n', ...
        meshList(k), meshList(k), meshList(k+1), meshList(k+1), hList(k)/hList(k+1), Rc_L2, Rc_Linf);
end
fprintf('====================================================================================================\n\n');

%-------------------------------------------------------
% Figure 2: Log-log plot L2 Error versus Element size h
%-------------------------------------------------------
figL2 = figure('Name', 'Validation Figure 2: Log-Log L2 Error Trajectory', 'NumberTitle', 'off');
loglog(hList, L2List, '-bo', 'LineWidth', 2.0, 'MarkerSize', 8, 'MarkerFaceColor', 'b');
grid on;
title('L2 Error Convergence');
xlabel('Element size h [mm]'); ylabel('L2 Error ||e||_{L2}');

%-------------------------------------------------------
% Figure 3: Log-log plot L∞ Error versus Element size h
%-------------------------------------------------------
figLinf = figure('Name', 'Validation Figure 3: Log-Log Linf Error Trajectory', 'NumberTitle', 'off');
loglog(hList, LinfList, '-ks', 'LineWidth', 2.0, 'MarkerSize', 8, 'MarkerFaceColor', 'k');
grid on;
title('L\infty Error Convergence');
xlabel('Element size h [mm]'); ylabel('L\infty Error ||e||_{L\infty}');

%% 12. Print Final Benchmark Validation Summary Table
fprintf('========================================================================================================================\n');
fprintf(' BENCHMARK VALIDATION SUMMARY\n');
fprintf('========================================================================================================================\n');
fprintf(' Mesh Size | Max FEM u    | Exact Max u  |  Linf Error  |   L2 Error   | Relative L2  | Observed Rc (L2)\n');
fprintf('-----------+--------------+--------------+--------------+--------------+--------------+------------------\n');
for m = 1:numMeshes
    if m < numMeshes
        Rc_val = log(L2List(m) / L2List(m + 1)) / log(hList(m) / hList(m + 1));
        Rc_str = sprintf('%14.4f', Rc_val);
    else
        Rc_str = '           ---';
    end
    fprintf('   %2dx%2d   | %.8f | %.8f | %.6e | %.6e | %.6e | %s\n', ...
        meshList(m), meshList(m), maxUList(m), maxAnaList(m), LinfList(m), L2List(m), relL2List(m), Rc_str);
end
fprintf('========================================================================================================================\n\n');

%% 13. Archive Complete Simulation Results
results = struct();
results.problem            = problem;
results.geometry           = geometry;
results.material           = material;
results.gradient           = gradient;
results.constitutive       = constitutive;
results.convergenceResults = convergenceResults;

fprintf('Master validation study completed successfully.\n');
fprintf('========================================================================================================================\n');
