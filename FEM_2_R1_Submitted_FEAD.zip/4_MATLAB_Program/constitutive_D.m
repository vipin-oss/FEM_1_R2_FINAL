function Dmat = constitutive_D(varargin)
%CONSTITUTIVE_D Construct higher-order Mindlin Form-II constitutive matrix.
%
%   Dmat = constitutive_D(gradient)
%   Dmat = constitutive_D(Cmat, gradient)
%
%   Purpose
%   -------
%   Constructs the 6 x 6 higher-order constitutive matrix D for the
%   plane-strain engineering strain-gradient vector
%
%       gradEps = [ epsilon_xx,x ;
%                   epsilon_yy,x ;
%                   gamma_xy,x   ;
%                   epsilon_xx,y ;
%                   epsilon_yy,y ;
%                   gamma_xy,y   ].
%
%   The matrix is constructed from the finalized Mindlin Form-II benchmark
%   constants c3, c4, c5, c6, and c7.
%
%   Operating Modes
%   ---------------
%   Supports two distinct mode dispatches via gradient.type:
%       gradient.type = 'Benchmark' : Bypasses global multiaxial positive
%                                     definiteness assertions and enforces
%                                     ONLY the 1D simple-shear stability
%                                     condition D66 = c5 + c6 + c7 > 0.
%       gradient.type = 'General'   : Enforces uncompromising full-tensor
%                                     positive definiteness assertions.
%
%   Inputs
%   ------
%   gradient : structure with fields
%       gradient.ell       : active characteristic length scale
%       gradient.type      : operating mode string ('Benchmark' or 'General')
%       gradient.table.ell : list of available characteristic lengths
%       gradient.table.c3  : c3 values corresponding to table.ell
%       gradient.table.c4  : c4 values corresponding to table.ell
%       gradient.table.c5  : c5 values corresponding to table.ell
%       gradient.table.c6  : c6 values corresponding to table.ell
%       gradient.table.c7  : c7 values corresponding to table.ell
%
%   Compatibility note
%   ------------------
%   The two-input form constitutive_D(Cmat, gradient) is accepted for
%   compatibility with the project driver. The first input is not used in
%   this module because the benchmark D matrix is defined directly by
%   c3--c7.
%
%   Outputs
%   -------
%   Dmat : structure containing Dmat.D [6 x 6] and diagnostic metadata.
%==========================================================================

%==========================================================================
% 1. Input handling and structure validation
%==========================================================================
if nargin == 1
    gradient = varargin{1};
elseif nargin == 2
    % First argument is accepted for compatibility with main.m but is not
    % needed for this benchmark higher-order constitutive matrix.
    gradient = varargin{2};
else
    error('constitutive_D:InvalidInputCount', ...
          'constitutive_D requires either gradient or (Cmat, gradient).');
end

if ~isstruct(gradient)
    error('constitutive_D:InvalidGradientInput', ...
          'gradient must be a structure.');
end

if ~isfield(gradient, 'ell')
    error('constitutive_D:MissingActiveLengthScale', ...
          'gradient.ell is required as the active characteristic length scale.');
end

if ~isfield(gradient, 'type')
    error('constitutive_D:MissingGradientType', ...
          'gradient.type is required (must be ''Benchmark'' or ''General'').');
end

gradType = gradient.type;
if strcmpi(gradType, 'Benchmark') || strcmpi(gradType, 'isotropic_benchmark')
    isBenchmark = true;
elseif strcmpi(gradType, 'General')
    isBenchmark = false;
else
    error('constitutive_D:InvalidGradientType', ...
          'gradient.type = ''%s'' is invalid. Must be ''Benchmark'' or ''General''.', gradType);
end

if ~isfield(gradient, 'table') || ~isstruct(gradient.table)
    error('constitutive_D:MissingGradientTable', ...
          'gradient.table is required and must be a structure.');
end

requiredTableFields = {'ell', 'c3', 'c4', 'c5', 'c6', 'c7'};
for k = 1:numel(requiredTableFields)
    fieldName = requiredTableFields{k};
    if ~isfield(gradient.table, fieldName)
        error('constitutive_D:MissingGradientTableField', ...
              'gradient.table.%s is required.', fieldName);
    end
end

ellActive = gradient.ell;
if ~isnumeric(ellActive) || ~isreal(ellActive) || ...
   ~isscalar(ellActive) || ~isfinite(ellActive)
    error('constitutive_D:InvalidActiveLengthScale', ...
          'gradient.ell must be a finite real scalar.');
end

if ellActive <= 0.0
    error('constitutive_D:NonPositiveActiveLengthScale', ...
          'gradient.ell must be positive.');
end

ellTable = gradient.table.ell(:);
c3Table  = gradient.table.c3(:);
c4Table  = gradient.table.c4(:);
c5Table  = gradient.table.c5(:);
c6Table  = gradient.table.c6(:);
c7Table  = gradient.table.c7(:);

numRows = numel(ellTable);
if any([numel(c3Table), numel(c4Table), numel(c5Table), ...
        numel(c6Table), numel(c7Table)] ~= numRows)
    error('constitutive_D:InconsistentGradientTableLengths', ...
          'All gradient.table fields must have the same number of entries.');
end

if any(~isfinite(ellTable)) || any(~isfinite(c3Table)) || ...
   any(~isfinite(c4Table))  || any(~isfinite(c5Table)) || ...
   any(~isfinite(c6Table))  || any(~isfinite(c7Table))
    error('constitutive_D:NonFiniteGradientTableValues', ...
          'All entries in gradient.table must be finite.');
end

%==========================================================================
% 2. Select active benchmark constants c3--c7
%==========================================================================
selectionTolerance = 1.0e-12;
match = find(abs(ellTable - ellActive) <= selectionTolerance * ...
             max(1.0, abs(ellActive)));

if isempty(match)
    error('constitutive_D:ActiveLengthScaleNotFound', ...
          ['Active length scale gradient.ell = %.16g was not found in ', ...
           'gradient.table.ell.'], ellActive);
end

if numel(match) > 1
    error('constitutive_D:DuplicateActiveLengthScale', ...
          ['Multiple entries in gradient.table.ell match the active ', ...
           'length scale gradient.ell = %.16g.'], ellActive);
end

idx = match(1);
c3  = c3Table(idx);
c4  = c4Table(idx);
c5  = c5Table(idx);
c6  = c6Table(idx);
c7  = c7Table(idx);

%==========================================================================
% 3. Construct entries of the finalized 6 x 6 D matrix
%==========================================================================
D11 = 4.0*c3 + c4 + 4.0*c5 + 2.0*c6 + 4.0*c7;
D12 = 2.0*c3 + c4;
D16 = c3 + 2.0*c5;
D22 = c4 + 2.0*c6;
D26 = c3 + 2.0*c7;
D33 = c5 + c6 + c7;
D34 = c3 + 2.0*c7;
D35 = c3 + 2.0*c5;
D44 = c4 + 2.0*c6;
D45 = 2.0*c3 + c4;
D55 = 4.0*c3 + c4 + 4.0*c5 + 2.0*c6 + 4.0*c7;
D66 = c5 + c6 + c7;

D = [ ...
    D11, D12, 0.0, 0.0, 0.0, D16; ...
    D12, D22, 0.0, 0.0, 0.0, D26; ...
    0.0, 0.0, D33, D34, D35, 0.0; ...
    0.0, 0.0, D34, D44, D45, 0.0; ...
    0.0, 0.0, D35, D45, D55, 0.0; ...
    D16, D26, 0.0, 0.0, 0.0, D66];

%==========================================================================
% 4. Verification and operating mode dispatch
%==========================================================================
if ~isequal(size(D), [6, 6])
    error('constitutive_D:InvalidDSize', ...
          'The higher-order constitutive matrix D must have size [6 x 6].');
end

if any(~isfinite(D(:)))
    error('constitutive_D:NonFiniteDEntries', ...
          'The higher-order constitutive matrix D contains non-finite entries.');
end

symmetryTolerance = 1.0e-12;
symmetryError = max(max(abs(D - D.')));
if symmetryError > symmetryTolerance
    error('constitutive_D:NonSymmetricD', ...
          'D must be symmetric. Symmetry error = %.3e.', symmetryError);
end

D_eig = eig(D);
if any(~isfinite(D_eig))
    error('constitutive_D:NonFiniteEigenvalues', ...
          'Eigenvalues of D are not finite.');
end

D_det = det(D);
if ~isfinite(D_det)
    error('constitutive_D:NonFiniteDeterminant', ...
          'det(D) is not finite.');
end

D_conditionNumber = cond(D);
if D_conditionNumber > 1.0e8
    warning('constitutive_D:LargeConditionNumber', ...
            'Condition number of D is large: cond(D) = %.3e.', ...
            D_conditionNumber);
end

if isBenchmark
    % Benchmark Mode: Enforce ONLY the simple-shear stability condition D66 > 0.
    % Global indefinite spectral properties are recorded without halting execution.
    if D66 <= 0.0
        error('constitutive_D:NonPositiveBenchmarkShearModulus', ...
              'Benchmark stability verification failed: D66 = c5 + c6 + c7 = %.16e must be strictly positive.', D66);
    end
    
    % Energy positivity restricted to benchmark simple-shear kinematics (gradEps_xy,y).
    g_test = [0.0; 0.0; 0.0; 0.0; 0.0; 1.0];
    W_test = 0.5 * g_test.' * D * g_test;
    energyVerification = (W_test > 0.0);
else
    % General Mode: Enforce global positive definiteness across all 6 gradient modes.
    if any(D_eig <= 0.0)
        error('constitutive_D:NonPositiveEigenvalues', ...
              ['D must be positive definite. Minimum eigenvalue = %.16e. ', ...
               'Check c3--c7 for the active length scale.'], min(D_eig));
    end
    
    if D_det <= 0.0
        error('constitutive_D:NonPositiveDeterminant', ...
              'det(D) must be positive. det(D) = %.16e.', D_det);
    end
    
    % Energy positivity verification using a random strain-gradient vector.
    g_test = randn(6, 1);
    W_test = 0.5 * g_test.' * D * g_test;
    if W_test <= 0.0
        error('constitutive_D:NonPositiveEnergyDensity', ...
              'Energy verification failed: W = %.16e must be positive.', W_test);
    end
    energyVerification = true;
end

%==========================================================================
% 5. Store output structure
%==========================================================================
Dmat = struct();
Dmat.D = D;
Dmat.c3 = c3;
Dmat.c4 = c4;
Dmat.c5 = c5;
Dmat.c6 = c6;
Dmat.c7 = c7;
Dmat.ell = ellActive;
Dmat.tableIndex = idx;
Dmat.operatingMode = gradType;

% Diagnostic spectral metadata.
Dmat.eigenvalues       = D_eig;
Dmat.minimumEigenvalue = min(D_eig);
Dmat.maximumEigenvalue = max(D_eig);
Dmat.determinant       = D_det;
Dmat.conditionNumber   = D_conditionNumber;
Dmat.symmetryError     = symmetryError;

Dmat.energyVerification = energyVerification;
Dmat.energyTestGradient = g_test;
Dmat.energyTestValue    = W_test;
Dmat.matrixSize         = size(D);
Dmat.numGradientComponents = 6;

Dmat.strainGradientOrdering = { ...
    'epsilon_xx_x', ...
    'epsilon_yy_x', ...
    'gamma_xy_x', ...
    'epsilon_xx_y', ...
    'epsilon_yy_y', ...
    'gamma_xy_y'};

Dmat.stressGradientOrdering = { ...
    'tau_epsilon_xx_x', ...
    'tau_epsilon_yy_x', ...
    'tau_gamma_xy_x', ...
    'tau_epsilon_xx_y', ...
    'tau_epsilon_yy_y', ...
    'tau_gamma_xy_y'};

Dmat.type      = 'Mindlin Form-II plane-strain benchmark';
Dmat.dimension = 6;
Dmat.description = 'Higher-order constitutive matrix for engineering plane-strain strain-gradient vector';

end
