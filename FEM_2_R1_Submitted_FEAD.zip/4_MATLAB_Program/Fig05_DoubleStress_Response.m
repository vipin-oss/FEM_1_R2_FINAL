%% Fig05_DoubleStress_Response.m
%=========================================================================%
%  Figure 5: Orientation-dependent higher-order double stress response
%  Proposed anisotropic ellipsoidal strain-gradient elasticity model
%=========================================================================%
%  This script uses the existing verified BFS finite element modules.
%  It does not modify any solver, constitutive, assembly, or validation file.
%
%  The higher-order double shear stress tau_{xyy} is evaluated directly 
%  from the exact C1 BFS shape-function second derivatives:
%
%      tau_{xyy} = D66 * gamma_{xy,y} = g22 * mu * (d2u/dy2 + d2v/dxdy).
%
%  The plotted quantity is normalized as:
%
%      tau_{xyy} / (mu * gamma0 * a2),   where gamma0 = U_top / H.
%
%  This normalization renders the higher-order stress dimensionless and 
%  comparable across all microstructural orientation angles.
%=========================================================================%

clear;
clc;
close all;

fprintf('========================================================================\n');
fprintf(' Generating Figure 5: Higher-order double stress response\n');
fprintf('========================================================================\n');

%% 1. Same configuration as Figures 2, 3, and 4
geometry.xMin = 0.0;
geometry.xMax = 1.0;
geometry.yMin = 0.0;
geometry.yMax = 1.0;
geometry.L = geometry.xMax - geometry.xMin;
geometry.H = geometry.yMax - geometry.yMin;

material.E = 1.0;
material.nu = 0.30;
material.model = 'isotropic_linear_elastic_reference';
material.mu = material.E / (2.0 * (1.0 + material.nu));

U_top = 0.05;
gamma0 = U_top / geometry.H;

N = 32;
meshParams.Nx = N;
meshParams.Ny = N;
meshParams.elementType = 'BFS';
meshParams.nodesPerElement = 4;
meshParams.dofsPerNode = 8;
meshParams.dofsPerElement = 32;

mesh = mesh_generator(geometry, meshParams);

AR = 5.0;
a2 = 0.10;
a1 = AR * a2;
alphaListDeg = [0, 15, 30, 45, 60, 90];
numCases = numel(alphaListDeg);

gaussOrder = 4;
tau_ref = material.mu * gamma0 * a2; % Higher-order stress normalization reference

%% 2. Classical constitutive matrix
Cmat = constitutive_C(material);
C = Cmat.C;

%% 3. Storage arrays
yMidStore = [];
tauMidStore = [];
summary = zeros(numCases, 7);

verificationFlags.usedFEMSolution = true;
verificationFlags.usedAnalyticalStressExpression = false;
verificationFlags.usedFiniteDifferenceApproximation = false;
verificationFlags.usedCurveFitting = false;
verificationFlags.usedInterpolationReplacement = false;
verificationFlags.usedBFSShapeDerivatives = true;

%% 4. Orientation loop
for ia = 1:numCases
    alphaDeg = alphaListDeg(ia);
    alpha = alphaDeg * pi / 180.0;
    fprintf('Solving alpha = %g deg ...\n', alphaDeg);
    caseTimer = tic;
    
    %------------------------------------------------------------------
    % 4.1 Rotated anisotropic characteristic-length tensor
    %------------------------------------------------------------------
    g11 = (a1^2*cos(alpha)^2 + a2^2*sin(alpha)^2) / 5.0;
    g22 = (a1^2*sin(alpha)^2 + a2^2*cos(alpha)^2) / 5.0;
    g12 = ((a1^2 - a2^2)*sin(alpha)*cos(alpha)) / 5.0;
    g21 = g12;
    
    Dmat = struct();
    Dmat.D = [g11*C, g12*C; ...
              g21*C, g22*C];
    Dmat.g2 = [g11, g12; g21, g22];
    Dmat.alphaDeg = alphaDeg;
    Dmat.AR = AR;
    Dmat.a1 = a1;
    Dmat.a2 = a2;
    Dmat.type = 'Anisotropic ellipsoidal engineering strain-gradient matrix';
    
    constitutive = struct();
    constitutive.C = Cmat;
    constitutive.D = Dmat;
    
    %------------------------------------------------------------------
    % 4.2 Assemble global stiffness matrix using existing FEM kernels
    %------------------------------------------------------------------
    [K_global, F_global] = local_assemble_uniform_BFS(mesh, constitutive, gaussOrder);
    
    %------------------------------------------------------------------
    % 4.3 Apply the same boundary conditions used in Figures 2, 3, and 4
    %------------------------------------------------------------------
    boundary = local_build_simple_shear_boundary(mesh, U_top);
    [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, mesh, boundary);
    [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry);
    
    %------------------------------------------------------------------
    % 4.4 Solve the complete finite element system
    %------------------------------------------------------------------
    solution = solver(K_bc, F_bc, bc, mesh);
    solution.displacement(slaveDofs) = solution.displacement(masterDofs);
    d = solution.displacement;
    
    %------------------------------------------------------------------
    % 4.5 Post-process higher-order double shear stress along the midline
    %     tau_xyy = D66 * gamma_xy,y is evaluated using exact BFS derivatives.
    %------------------------------------------------------------------
    [yMid, tauMid] = local_extract_midline_double_stress(mesh, d, geometry, constitutive);
    
    if ia == 1
        yMidStore = yMid(:);
        tauMidStore = zeros(numel(yMid), numCases);
    end
    tauMidStore(:, ia) = tauMid(:);
    
    [tauMax, idxMax] = max(tauMid);
    tauMin = min(tauMid);
    yMax = yMid(idxMax);
    cpuTime = toc(caseTimer);
    
    summary(ia, :) = [alphaDeg, tauMax, tauMin, yMax/geometry.H, ...
                      cpuTime, solution.residual, solution.conditionNumber];
    fprintf('  max(tau_xyy)       = %.6e\n', tauMax);
    fprintf('  min(tau_xyy)       = %.6e\n', tauMin);
    fprintf('  y/H at max stress  = %.6f\n', yMax/geometry.H);
    fprintf('  CPU time           = %.3f s\n', cpuTime);
    fprintf('  residual           = %.6e\n', solution.residual);
    fprintf('  condition number   = %.6e\n\n', solution.conditionNumber);
end

%% 5. Automatic verification report
fprintf('========================================================================\n');
fprintf(' Automatic Figure 5 verification\n');
fprintf('========================================================================\n');
fprintf(' Curves obtained from solved FEM displacement vectors        : %s\n', local_true_false(verificationFlags.usedFEMSolution));
fprintf(' Analytical stress expression used                          : %s\n', local_true_false(verificationFlags.usedAnalyticalStressExpression));
fprintf(' Finite-difference derivative approximation used            : %s\n', local_true_false(verificationFlags.usedFiniteDifferenceApproximation));
fprintf(' Curve fitting used                                         : %s\n', local_true_false(verificationFlags.usedCurveFitting));
fprintf(' Interpolation replacement of FEM solution used             : %s\n', local_true_false(verificationFlags.usedInterpolationReplacement));
fprintf(' Exact BFS shape-function derivatives used for tau_xyy     : %s\n', local_true_false(verificationFlags.usedBFSShapeDerivatives));
fprintf('========================================================================\n\n');

fprintf('Numerical summary for Figure 5:\n');
fprintf(' alpha   max_tau         min_tau         y/H_at_max     CPU(s)       residual        condest\n');
for ia = 1:numCases
    fprintf('%6.1f  % .6e  % .6e  % .6f  % .3f  % .6e  % .6e\n', ...
        summary(ia, 1), summary(ia, 2), summary(ia, 3), summary(ia, 4), ...
        summary(ia, 5), summary(ia, 6), summary(ia, 7));
end
fprintf('\n');

%% 6. Plot Figure 5
fig = figure('Name', 'Figure 5 Double Stress Response', 'NumberTitle', 'off');
hold on;

colors = [ ...
    0.0000, 0.0000, 0.0000; ...
    0.0000, 0.4470, 0.7410; ...
    0.0000, 0.6200, 0.4510; ...
    0.8500, 0.3250, 0.0980; ...
    0.8000, 0.4750, 0.6550; ...
    0.9290, 0.6940, 0.1250];
lineStyles = {'--', '-', '-', '-', '-', '-'};

legendHandles = gobjects(numCases, 1);
legendLabels = cell(numCases, 1);

for ia = 1:numCases
    alphaDeg = alphaListDeg(ia);
    legendHandles(ia) = plot(tauMidStore(:, ia)/tau_ref, yMidStore/geometry.H, ...
        'LineStyle', lineStyles{ia}, ...
        'Color', colors(ia, :), ...
        'LineWidth', 2.0, ...
        'Marker', 'none', ...
        'MarkerSize', 7);
    legendLabels{ia} = sprintf('$\\alpha=%d^\\circ$', alphaDeg);
end

xlabel('Normalized higher-order shear stress $\tau_{xyy}/(\mu\gamma_0 a_2)$', 'Interpreter', 'latex');
ylabel('Normalized vertical coordinate $y/H$', 'Interpreter', 'latex');
lgd = legend(legendHandles, legendLabels, 'Interpreter', 'latex', 'Location', 'northeast');

local_apply_figure5_formatting(fig, gca, lgd);

%% 7. Export PDF, EPS, and PNG
exportBaseName = 'Fig05_DoubleStress_Response';
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir)
    scriptDir = pwd;
end
local_export_pdf_eps_png(fig, exportBaseName, scriptDir);

fprintf('========================================================================\n');
fprintf(' Figure 5 generated successfully.\n');
fprintf(' Output files:\n');
fprintf('   Fig05_DoubleStress_Response.pdf\n');
fprintf('   Fig05_DoubleStress_Response.eps\n');
fprintf('   Fig05_DoubleStress_Response.png\n');
fprintf('========================================================================\n');

%=========================================================================%
% Local helper functions
%=========================================================================%

function [K_global, F_global] = local_assemble_uniform_BFS(mesh, constitutive, gaussOrder)
    numDofs = mesh.numDofs;
    numElements = mesh.numElements;

    elemNodes = mesh.elements(1, :);
    elementCoords = mesh.nodes(elemNodes, :);
    gauss = gauss_rule(gaussOrder);
    shape2D = bfs_tensor_product(gauss.xi, gauss.eta);
    jac = jacobian_bfs(elementCoords, shape2D);
    phys = physical_derivatives(shape2D, jac);
    Bmat = B_matrix(phys);
    Bgmat = Bg_matrix(phys);
    Ke = element_stiffness(Bmat, Bgmat, constitutive.C, constitutive.D, jac, gauss);
    KeTotal = Ke.total;

    nnzPerElement = 32 * 32;
    I = zeros(numElements * nnzPerElement, 1);
    J = zeros(numElements * nnzPerElement, 1);
    V = zeros(numElements * nnzPerElement, 1);
    cursor = 0;
    for e = 1:numElements
        elemNodes = mesh.elements(e, :);
        edofs = reshape(mesh.dofMap(elemNodes, :).', 32, 1);
        [II, JJ] = ndgrid(edofs, edofs);
        idx = cursor + (1:nnzPerElement);
        I(idx) = II(:);
        J(idx) = JJ(:);
        V(idx) = KeTotal(:);
        cursor = cursor + nnzPerElement;
    end
    K_global = sparse(I, J, V, numDofs, numDofs);
    F_global = zeros(numDofs, 1);
end

function boundary = local_build_simple_shear_boundary(mesh, U_top)
    bottomDofs = mesh.bottomDofs(:);
    topDofs = mesh.topDofs(:);
    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes = numel(topDofs) / 8;

    bottomFixIndices = [];
    for nb = 1:numBottomNodes
        bottomFixIndices = [bottomFixIndices, 8*(nb-1) + [1, 2, 5, 6]]; %#ok<AGROW>
    end
    fixedBottomDofs = bottomDofs(bottomFixIndices);
    bottomVals = zeros(numel(fixedBottomDofs), 1);

    topFixIndices = [];
    for nt = 1:numTopNodes
        topFixIndices = [topFixIndices, 8*(nt-1) + [1, 2, 3, 4, 5, 6]]; %#ok<AGROW>
    end
    fixedTopDofs = topDofs(topFixIndices);
    topVals = zeros(numel(fixedTopDofs), 1);

    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;

    boundary = struct();
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values = [bottomVals(:); topVals(:)];
end

function [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry)
    xTol = 1.0e-7 * geometry.L;
    leftNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMax) <= xTol);
    [~, sortLeft] = sort(mesh.nodes(leftNodeIndices, 2));
    leftNodeIndices = leftNodeIndices(sortLeft);
    [~, sortRight] = sort(mesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);

    masterDofs = [];
    slaveDofs = [];
    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);
        for c = 1:8
            dofL = mesh.dofMap(nodeL, c);
            dofR = mesh.dofMap(nodeR, c);
            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL]; %#ok<AGROW>
                    slaveDofs = [slaveDofs; dofR]; %#ok<AGROW>
                end
            end
        end
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m) = F_bc(m) + F_bc(s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        K_bc(s, :) = 0.0;
        K_bc(:, s) = 0.0;
        K_bc(s, s) = 1.0;
        F_bc(s) = 0.0;
    end
end

function [yMid, tauMid] = local_extract_midline_double_stress(mesh, d, geometry, constitutive)
%LOCAL_EXTRACT_MIDLINE_DOUBLE_STRESS Evaluate tau_xyy along x=L/2.
%
% The higher-order double shear stress tau_xyy is evaluated directly from 
% the exact C1 BFS second physical derivatives returned by physical_derivatives():
%     tau_xyy = D66 * (d2u/dy2 + d2v/dxdy).
%
% No finite differences, analytical stress expressions, curve fitting, or 
% replacement interpolation are used.
    xMid = 0.5 * (geometry.xMin + geometry.xMax);
    xTol = 1.0e-7 * geometry.L;
    midNodeIndices = find(abs(mesh.nodes(:, 1) - xMid) <= xTol);
    if isempty(midNodeIndices)
        [~, closest] = min(abs(mesh.nodes(:, 1) - xMid));
        xClosest = mesh.nodes(closest, 1);
        midNodeIndices = find(abs(mesh.nodes(:, 1) - xClosest) <= xTol);
    end
    [yMid, sortIdx] = sort(mesh.nodes(midNodeIndices, 2));
    midNodeIndices = midNodeIndices(sortIdx);
    tauMid = zeros(numel(midNodeIndices), 1);
    hx = mesh.hx;
    hy = mesh.hy;
    
    % D66 is the (6,6) component of Dmat.D (corresponding to gamma_xy,y)
    D66 = constitutive.D.D(6, 6);

    for p = 1:numel(midNodeIndices)
        xq = mesh.nodes(midNodeIndices(p), 1);
        yq = mesh.nodes(midNodeIndices(p), 2);
        ex = floor((xq - geometry.xMin) / hx) + 1;
        ey = floor((yq - geometry.yMin) / hy) + 1;
        ex = max(1, min(mesh.Nx, ex));
        ey = max(1, min(mesh.Ny, ey));
        elemID = (ey - 1) * mesh.Nx + ex;
        elemNodes = mesh.elements(elemID, :);
        elementCoords = mesh.nodes(elemNodes, :);
        elemCenter = mean(elementCoords, 1);
        xi = 2.0 * (xq - elemCenter(1)) / hx;
        eta = 2.0 * (yq - elemCenter(2)) / hy;
        shape2D = bfs_tensor_product(xi, eta);
        jac = jacobian_bfs(elementCoords, shape2D);
        phys = physical_derivatives(shape2D, jac);
        
        % Extract second physical derivatives
        d2N_dy2 = phys.d2N_dy2(1, :);
        d2N_dxdy = phys.d2N_dxdy(1, :);
        
        grad_gamma_y = 0.0;
        for A = 1:4
            globalNode = elemNodes(A);
            for r = 1:4
                scalarCol = 4*(A-1) + r;
                uDof = mesh.dofMap(globalNode, r);
                vDof = mesh.dofMap(globalNode, 4 + r);
                % gamma_xy,y = d2u/dy2 + d2v/dxdy
                grad_gamma_y = grad_gamma_y + d2N_dy2(scalarCol) * d(uDof) ...
                                            + d2N_dxdy(scalarCol) * d(vDof);
            end
        end
        tauMid(p) = D66 * grad_gamma_y;
    end
end

function local_apply_figure5_formatting(fig, ax, lgd)
    set(fig, 'Color', 'w', 'Units', 'centimeters');
  fig.Position = [1, 1, 16, 12];
    if ~isempty(ax) && isvalid(ax)
        ax.FontName   = 'Times New Roman';
        ax.FontSize   = 9;
        ax.FontWeight = 'normal';
        ax.Box        = 'on';
        ax.LineWidth  = 0.8;
        ax.TickDir    = 'out';
        ax.YLim       = [0.0, 1.0];
        grid(ax, 'on');
        grid(ax, 'minor');
        ax.GridLineStyle = '-';
        ax.MinorGridLineStyle = ':';
        ax.GridAlpha = 0.20;
        ax.MinorGridAlpha = 0.10;
        if ~isempty(ax.XLabel)
            ax.XLabel.Interpreter = 'latex';
            ax.XLabel.FontSize    = 10;
            ax.XLabel.FontWeight  = 'normal';
            ax.XLabel.FontName    = 'Times New Roman';
        end
        if ~isempty(ax.YLabel)
            ax.YLabel.Interpreter = 'latex';
            ax.YLabel.FontSize    = 10;
            ax.YLabel.FontWeight  = 'normal';
            ax.YLabel.FontName    = 'Times New Roman';
        end
        if ~isempty(ax.Title)
            ax.Title.String = '';
        end
    end
    if ~isempty(lgd) && isvalid(lgd)
        lgd.Interpreter = 'latex';
        lgd.FontName    = 'Times New Roman';
        lgd.FontSize    = 8;
        lgd.NumColumns  = 1;
        lgd.Box         = 'off';
    end
    drawnow;
end

function local_export_pdf_eps_png(fig, exportBaseName, preferredDir)
    pdfName = [exportBaseName, '.pdf'];
    epsName = [exportBaseName, '.eps'];
    pngName = [exportBaseName, '.png'];
    if nargin < 3 || isempty(preferredDir)
        preferredDir = pwd;
    end
    fprintf('Exporting %s (PDF + EPS + PNG via print)...\n', exportBaseName);
    try
        if ~exist(preferredDir, 'dir')
            mkdir(preferredDir);
        end
        pPdf = fullfile(preferredDir, pdfName);
        pEps = fullfile(preferredDir, epsName);
        pPng = fullfile(preferredDir, pngName);
        print(fig, pPdf, '-dpdf');
        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');
        fprintf('  -> Successfully saved:\n');
        fprintf('     1. Vector PDF : %s\n', pPdf);
        fprintf('     2. Vector EPS : %s\n', pEps);
        fprintf('     3. 600 DPI PNG: %s\n', pPng);
    catch
        saveDir = fullfile(tempdir, 'SCI_Figures');
        if ~exist(saveDir, 'dir')
            mkdir(saveDir);
        end
        pPdf = fullfile(saveDir, pdfName);
        pEps = fullfile(saveDir, epsName);
        pPng = fullfile(saveDir, pngName);
        print(fig, pPdf, '-dpdf');
        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');
        fprintf('  -> Preferred folder was not writable. Saved to writable directory:\n');
        fprintf('     1. Vector PDF : %s\n', pPdf);
        fprintf('     2. Vector EPS : %s\n', pEps);
        fprintf('     3. 600 DPI PNG: %s\n', pPng);
    end
end

function textValue = local_true_false(flagValue)
    if flagValue
        textValue = 'TRUE';
    else
        textValue = 'FALSE';
    end
end
