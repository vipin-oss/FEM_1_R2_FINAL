function Bmat = B_matrix(phys)
%B_MATRIX Construct classical plane-strain B matrix for BFS element.
%
%   Bmat = B_matrix(phys)
%
%   Purpose
%   -------
%   Constructs the classical strain-displacement matrix for the
%   plane-strain Bogner--Fox--Schmit (BFS) element at every Gauss or
%   evaluation point.
%
%   This routine uses ONLY the first physical derivatives of the scalar
%   BFS basis functions:
%
%       phys.dN_dx
%       phys.dN_dy
%
%   It computes ONLY the classical strain-displacement operator.  The
%   higher-order strain-gradient operator is constructed separately in
%   Bg_matrix.m.  This routine does NOT compute strain-gradient matrices,
%   constitutive matrices, or stiffness matrices.
%
%   Plane-strain strain vector
%   --------------------------
%   The engineering plane-strain vector used here is
%
%       epsilon = [epsilon_xx; epsilon_yy; gamma_xy]
%
%   where
%
%       epsilon_xx = du/dx,
%       epsilon_yy = dv/dy,
%       gamma_xy   = du/dy + dv/dx.
%
%   BFS element DOF ordering
%   ------------------------
%   The element has 4 nodes and 8 DOFs per node.  At node A, the local
%   nodal DOF ordering is
%
%       1: u
%       2: u,x
%       3: u,y
%       4: u,xy
%       5: v
%       6: v,x
%       7: v,y
%       8: v,xy
%
%   Therefore, the element vector has 32 DOFs:
%
%       d^e = [d_1; d_2; d_3; d_4],
%
%   where each d_A is 8 x 1.
%
%   Scalar BFS basis ordering
%   -------------------------
%   The scalar BFS tensor-product basis contains 16 scalar basis
%   functions.  For node A, the four scalar basis-function columns are
%
%       scalarCols(A) = 4*(A-1)+1 : 4*A.
%
%   These four scalar functions multiply the four scalar DOFs of a scalar
%   field, namely [w, w_x, w_y, w_xy] in the established project ordering.
%
%   Analytical B-matrix construction
%   --------------------------------
%   Let N_{A,r} be the r-th scalar basis function associated with node A,
%   where r = 1,...,4.  Let
%
%       dNdx = dN_{A,r}/dx,
%       dNdy = dN_{A,r}/dy.
%
%   The corresponding u DOF column is
%
%       col_u = 8*(A-1) + r,
%   and the corresponding v DOF column is
%
%       col_v = 8*(A-1) + 4 + r.
%
%   The strain contributions are
%
%       epsilon_xx receives dNdx in the u column,
%       epsilon_yy receives dNdy in the v column,
%       gamma_xy   receives dNdy in the u column and dNdx in the v column.
%
%   Therefore, for every Gauss point q,
%
%       B(1,col_u,q) = dNdx,
%       B(2,col_v,q) = dNdy,
%       B(3,col_u,q) = dNdy,
%       B(3,col_v,q) = dNdx.
%
%   Output
%   ------
%   Bmat : structure with fields
%       Bmat.B         : [3 x 32 x nGauss] classical B matrices
%       Bmat.numGauss  : number of Gauss/evaluation points
%       Bmat.numRows   : number of strain components, equal to 3
%       Bmat.numDofs   : number of element DOFs, equal to 32

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 1
    error('B_matrix:InvalidInputCount', ...
          'B_matrix requires exactly one input: phys.');
end

if ~isstruct(phys)
    error('B_matrix:InvalidInput', ...
          'Input phys must be a structure returned by physical_derivatives().');
end

requiredFields = {'dN_dx', 'dN_dy'};
for k = 1:numel(requiredFields)
    fieldName = requiredFields{k};
    if ~isfield(phys, fieldName)
        error('B_matrix:MissingField', ...
              'phys.%s is required.', fieldName);
    end
end

dN_dx = phys.dN_dx;
dN_dy = phys.dN_dy;

if ~isnumeric(dN_dx) || ~isreal(dN_dx) || ...
   ~isnumeric(dN_dy) || ~isreal(dN_dy)
    error('B_matrix:InvalidDerivativeData', ...
          'phys.dN_dx and phys.dN_dy must be real numeric arrays.');
end

if ~isequal(size(dN_dx), size(dN_dy))
    error('B_matrix:DerivativeSizeMismatch', ...
          'phys.dN_dx and phys.dN_dy must have identical dimensions.');
end

[nGauss, numScalarBasis] = size(dN_dx);

if numScalarBasis ~= 16
    error('B_matrix:InvalidNumberOfScalarBasisFunctions', ...
          'Expected 16 scalar BFS basis functions, but found %d.', ...
          numScalarBasis);
end

if nGauss < 1
    error('B_matrix:InvalidNumberOfGaussPoints', ...
          'At least one Gauss/evaluation point is required.');
end

if any(~isfinite(dN_dx(:))) || any(~isfinite(dN_dy(:)))
    error('B_matrix:NonFiniteDerivativeData', ...
          'All entries of phys.dN_dx and phys.dN_dy must be finite.');
end

%==========================================================================
% 2. Allocate B matrix array
%==========================================================================

numNodes = 4;
scalarDofsPerNode = 4;
dofsPerNode = 8;
numStrainComponents = 3;
numElementDofs = numNodes * dofsPerNode;

B = zeros(numStrainComponents, numElementDofs, nGauss);

%==========================================================================
% 3. Construct B matrix at every Gauss point
%==========================================================================

for q = 1:nGauss
    Bq = zeros(numStrainComponents, numElementDofs);

    for A = 1:numNodes
        scalarCols = (4*(A-1) + 1):(4*A);

        for r = 1:scalarDofsPerNode
            scalarCol = scalarCols(r);

            dNdx = dN_dx(q, scalarCol);
            dNdy = dN_dy(q, scalarCol);

            % Local element column numbers for the corresponding u and v
            % scalar BFS DOFs.
            col_u = dofsPerNode*(A-1) + r;
            col_v = dofsPerNode*(A-1) + 4 + r;

            % epsilon_xx = du/dx
            Bq(1, col_u) = dNdx;

            % epsilon_yy = dv/dy
            Bq(2, col_v) = dNdy;

            % gamma_xy = du/dy + dv/dx
            Bq(3, col_u) = dNdy;
            Bq(3, col_v) = dNdx;
        end
    end

    B(:, :, q) = Bq;
end

%==========================================================================
% 4. Internal verification
%==========================================================================

expectedSize = [3, 32, nGauss];
if ~isequal(size(B), expectedSize)
    error('B_matrix:InvalidBSize', ...
          'B must have dimensions [3 x 32 x nGauss].');
end

if any(~isfinite(B(:)))
    error('B_matrix:NonFiniteBEntries', ...
          'B contains non-finite entries.');
end

% Verify correct DOF placement by checking that each row only receives
% contributions in the expected columns.
uColumns = [];
vColumns = [];
for A = 1:numNodes
    uColumns = [uColumns, dofsPerNode*(A-1) + (1:4)]; %#ok<AGROW>
    vColumns = [vColumns, dofsPerNode*(A-1) + (5:8)]; %#ok<AGROW>
end

allColumns = 1:numElementDofs;
notUColumns = setdiff(allColumns, uColumns);
notVColumns = setdiff(allColumns, vColumns);

placementTolerance = 1.0e-14;

for q = 1:nGauss
    Bq = B(:, :, q);

    % epsilon_xx row must have entries only in u columns.
    if max(abs(Bq(1, notUColumns))) > placementTolerance
        warning('B_matrix:UnexpectedEpsxxNonzeroPattern', ...
                ['epsilon_xx row contains unexpected nonzero entries ', ...
                 'in non-u DOF columns at Gauss point %d.'], q);
    end

    % epsilon_yy row must have entries only in v columns.
    if max(abs(Bq(2, notVColumns))) > placementTolerance
        warning('B_matrix:UnexpectedEpsyyNonzeroPattern', ...
                ['epsilon_yy row contains unexpected nonzero entries ', ...
                 'in non-v DOF columns at Gauss point %d.'], q);
    end

    % gamma_xy row may have entries in both u and v columns, but all 32
    % columns are accounted for by the established u/v DOF partition.
    if numel(union(uColumns, vColumns)) ~= numElementDofs
        error('B_matrix:InvalidDofPartition', ...
              'u and v DOF columns do not cover all 32 element DOFs.');
    end
end

%==========================================================================
% 5. Store output structure
%==========================================================================

Bmat = struct();

Bmat.B = B;
Bmat.numGauss = nGauss;
Bmat.numRows = numStrainComponents;
Bmat.numDofs = numElementDofs;
Bmat.numScalarBasis = numScalarBasis;

% Row indices for the engineering plane-strain vector.
Bmat.epsxxRow = 1;
Bmat.epsyyRow = 2;
Bmat.gammaxyRow = 3;

% Expose the element-level u and v DOF column maps for debugging,
% constitutive assembly, and later verification.
Bmat.uColumns = uColumns;
Bmat.vColumns = vColumns;

Bmat.strainOrdering = {'epsilon_xx', 'epsilon_yy', 'gamma_xy'};
Bmat.dofOrderingPerNode = {'u', 'ux', 'uy', 'uxy', 'v', 'vx', 'vy', 'vxy'};
Bmat.type = 'Classical';
Bmat.kinematics = 'Plane strain';
Bmat.strainDefinition = 'Engineering strain';
Bmat.description = 'Classical plane-strain engineering B matrix for BFS element';

end
