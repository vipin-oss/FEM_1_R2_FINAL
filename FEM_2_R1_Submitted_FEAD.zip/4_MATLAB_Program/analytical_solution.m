function u_exact = analytical_solution(y, varargin)
%ANALYTICAL_SOLUTION Exact Case 1 benchmark profile from Shekarchizadeh et al. (2022).
%
%   u_exact = analytical_solution(y, results)
%   u_exact = analytical_solution(y, geometry, boundary, constitutive)
%   u_exact = analytical_solution(y, H, U_top, mu, D66)
%
%   Purpose
%   -------
%   Compute the authoritative closed-form analytical displacement profile
%   u_exact(y) for the two-dimensional simple-shear verification benchmark
%   strictly following Case 1 (displacement prescription) of Shekarchizadeh
%   et al. (2022), Section 3.1, p. 2223, Eq. (32).
%
%   Authoritative Published Derivation & Equations
%   ----------------------------------------------
%   Primary Reference: Shekarchizadeh, N., Abali, B.E., & Bersani, A.M. (2022).
%   "A benchmark strain gradient elasticity solution in two-dimensions for verifying
%   computational approaches by means of the finite element method."
%   Mathematics and Mechanics of Solids, Vol. 27(10), pp. 2218–2238.
%
%   1. Governing ODE (Section 3, p. 2222, Eq. 24):
%       c2 * u'' - (c5 + c6 + c7) * u'''' = 0,   where c2 = mu (shear modulus).
%       Length scale r = sqrt( (c5 + c6 + c7) / c2 ) = sqrt( D66 / mu ).
%
%   2. Case 1 Boundary Conditions (Section 3.1, p. 2222, Eq. 26):
%       ux(0) = 0,   ux(H) = \hat{u} (prescribed top displacement U_top),
%       m_xy(0) = 0  (zero double traction at bottom y=0 => u''(0) = 0),
%       u'(H) = 0    (zero displacement gradient at top y=H).
%
%   3. Authoritative Analytical Solution (Section 3.1, p. 2223, Eq. 32):
%       u(y) = \hat{u} * [ y * cosh(H/r) - r * sinh(y/r) ] / [ H * cosh(H/r) - r * sinh(H/r) ]
%
%   Numerically Stable Reformulation:
%       u(y) = \hat{u} * [ y - r * (sinh(y/r) / cosh(H/r)) ] / [ H - r * tanh(H/r) ]
%==========================================================================

%==========================================================================
% 1. Polymorphic input parsing and parameter extraction
%==========================================================================
if nargin < 2
    error('analytical_solution:InvalidInputCount', ...
          'analytical_solution requires at least 2 input arguments.');
end

if nargin == 2 && isstruct(varargin{1})
    results      = varargin{1};
    geometry     = results.geometry;
    boundary     = results.boundary;
    constitutive = results.constitutive;
    
    H     = geometry.H;
    U_top = max(boundary.values);
    mu    = constitutive.C.mu;
    D66   = constitutive.D.D(6, 6);
elseif nargin == 4 && isstruct(varargin{1}) && isstruct(varargin{2}) && isstruct(varargin{3})
    geometry     = varargin{1};
    boundary     = varargin{2};
    constitutive = varargin{3};
    
    H     = geometry.H;
    U_top = max(boundary.values);
    mu    = constitutive.C.mu;
    D66   = constitutive.D.D(6, 6);
elseif nargin == 5 && isnumeric(varargin{1}) && isnumeric(varargin{2}) && ...
       isnumeric(varargin{3}) && isnumeric(varargin{4})
    H     = varargin{1};
    U_top = varargin{2};
    mu    = varargin{3};
    D66   = varargin{4};
else
    error('analytical_solution:InvalidArgumentInterface', ...
          'Invalid input interface. See documentation for supported argument forms.');
end

if ~isnumeric(y) || ~isreal(y)
    error('analytical_solution:InvalidY', 'Evaluation vector y must be real numeric.');
end

if any(~isfinite(y(:))) || ~isfinite(H) || ~isfinite(U_top) || ~isfinite(mu) || ~isfinite(D66)
    error('analytical_solution:NonFiniteParameters', 'All physical input parameters must be finite.');
end

if H <= 0.0 || mu <= 0.0
    error('analytical_solution:NonPositiveDomainParameters', 'Height H and shear modulus mu must be strictly positive.');
end

%==========================================================================
% 2. Authoritative analytical displacement profile computation
%==========================================================================
y_col = y(:);

if D66 <= 0.0
    r = 0.0;
else
    r = sqrt(D66 / mu);
end

% Dispatch between classical Cauchy linear Couette shear and Mindlin gradient shear
if r <= 1.0e-14 * H
    u_exact = U_top * (y_col / H);
else
    % Numerically stable evaluation avoiding hyperbolic overflow at large H/r
    ratio = sinh(y_col / r) ./ cosh(H / r);
    num   = y_col - r * ratio;
    denom = H - r * tanh(H / r);
    
    if abs(denom) <= 1.0e-15 * H
        error('analytical_solution:SingularDenominator', ...
              'Analytical solution denominator is singular.');
    end
    
    u_exact = U_top * (num / denom);
end

if ~isequal(size(u_exact), size(y_col))
    error('analytical_solution:OutputSizeMismatch', 'Output dimensions must match evaluation vector y.');
end

end
