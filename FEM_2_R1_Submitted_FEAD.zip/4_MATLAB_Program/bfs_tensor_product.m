function shape2D = bfs_tensor_product(xi, eta)
%BFS_TENSOR_PRODUCT Construct 2D Bogner--Fox--Schmit tensor-product basis.
%
%   shape2D = bfs_tensor_product(xi, eta)
%
%   Purpose
%   -------
%   Constructs the complete two-dimensional scalar Bogner--Fox--Schmit
%   (BFS) interpolation basis from the verified one-dimensional cubic
%   Hermite basis returned by bfs_shape_functions().
%
%   This routine evaluates the 16 scalar BFS basis functions and their
%   parent-coordinate derivatives at arbitrary parent-domain evaluation
%   points (xi, eta).
%
%   Inputs
%   ------
%   xi  : vector of parent-coordinate evaluation points in xi-direction
%   eta : vector of parent-coordinate evaluation points in eta-direction
%
%   xi and eta must either have the same number of entries, or one of them
%   may be scalar. If one input is scalar and the other is a vector, the
%   scalar input is expanded to the vector length. Each row of the output
%   corresponds to the pair (xi(k), eta(k)).
%
%   For tensor-product Gauss integration, call this function using paired
%   quadrature coordinates, for example
%
%       [XI, ETA] = ndgrid(gp, gp);
%       shape2D = bfs_tensor_product(XI(:), ETA(:));
%
%   Outputs
%   -------
%   shape2D : structure with fields
%       shape2D.N              : [nPoints x 16] scalar BFS basis functions
%       shape2D.dN_dxi         : [nPoints x 16] first derivatives wrt xi
%       shape2D.dN_deta        : [nPoints x 16] first derivatives wrt eta
%       shape2D.d2N_dxi2       : [nPoints x 16] second derivatives wrt xi
%       shape2D.d2N_deta2      : [nPoints x 16] second derivatives wrt eta
%       shape2D.d2N_dxideta    : [nPoints x 16] mixed derivatives
%
%   Important
%   ---------
%   This routine works only in the parent coordinate system. It does NOT
%   compute a Jacobian, does NOT transform derivatives to physical
%   coordinates, does NOT construct B or Bg matrices, and does NOT compute
%   stiffness matrices.
%
%   Local BFS scalar DOF ordering
%   -----------------------------
%   Each BFS node has four scalar degrees of freedom for a scalar field w:
%
%       1: w
%       2: w,xi
%       3: w,eta
%       4: w,xi eta
%
%   The four BFS nodes are ordered as
%
%       node 1: (-1,-1)
%       node 2: ( 1,-1)
%       node 3: ( 1, 1)
%       node 4: (-1, 1)
%
%   Therefore, the 16 scalar basis-function columns are ordered as
%
%       columns  1-- 4 : node 1 DOFs [w, w_xi, w_eta, w_xieta]
%       columns  5-- 8 : node 2 DOFs [w, w_xi, w_eta, w_xieta]
%       columns  9--12 : node 3 DOFs [w, w_xi, w_eta, w_xieta]
%       columns 13--16 : node 4 DOFs [w, w_xi, w_eta, w_xieta]
%
%   Tensor-product construction
%   ---------------------------
%   Let the one-dimensional Hermite functions be
%
%       H1 : value basis at -1
%       H2 : derivative basis at -1
%       H3 : value basis at +1
%       H4 : derivative basis at +1
%
%   A two-dimensional BFS function is obtained as
%
%       N(xi,eta) = H_a(xi) H_b(eta).
%
%   For example, at node 1 = (-1,-1),
%       N_1 = H1(xi) H1(eta),
%       N_2 = H2(xi) H1(eta),
%       N_3 = H1(xi) H2(eta),
%       N_4 = H2(xi) H2(eta).

%==========================================================================
% 1. Input checking and shape handling
%==========================================================================

if nargin ~= 2
    error('bfs_tensor_product:InvalidInputCount', ...
          'bfs_tensor_product requires exactly two inputs: xi and eta.');
end

if ~isnumeric(xi) || ~isreal(xi) || isempty(xi)
    error('bfs_tensor_product:InvalidXi', ...
          'xi must be a nonempty real numeric scalar or vector.');
end

if ~isnumeric(eta) || ~isreal(eta) || isempty(eta)
    error('bfs_tensor_product:InvalidEta', ...
          'eta must be a nonempty real numeric scalar or vector.');
end

if any(~isfinite(xi(:)))
    error('bfs_tensor_product:NonFiniteXi', ...
          'All xi evaluation points must be finite.');
end

if any(~isfinite(eta(:)))
    error('bfs_tensor_product:NonFiniteEta', ...
          'All eta evaluation points must be finite.');
end

xi = xi(:);
eta = eta(:);

nXi = numel(xi);
nEta = numel(eta);

if nXi == 1 && nEta > 1
    xi = repmat(xi, nEta, 1);
elseif nEta == 1 && nXi > 1
    eta = repmat(eta, nXi, 1);
elseif nXi ~= nEta
    error('bfs_tensor_product:IncompatibleInputSizes', ...
          ['xi and eta must have the same number of entries, unless ', ...
           'one of them is scalar.']);
end

nPoints = numel(xi);

% Parent-domain validation.  The BFS parent element is [-1,1] x [-1,1].
% Evaluation outside this domain is allowed for diagnostic purposes, but a
% warning is issued because the point lies outside the parent BFS element.
parentTolerance = 1.0e-12;
if any(abs(xi) > 1.0 + parentTolerance) || ...
   any(abs(eta) > 1.0 + parentTolerance)
    warning('bfs_tensor_product:PointOutsideParentDomain', ...
            ['One or more evaluation points satisfy |xi| > 1 + %.1e ', ...
             'or |eta| > 1 + %.1e and therefore lie outside the ', ...
             'parent BFS element [-1,1] x [-1,1].'], ...
             parentTolerance, parentTolerance);
end

%==========================================================================
% 2. Obtain verified 1D Hermite basis from bfs_shape_functions()
%==========================================================================

shapeXi  = bfs_shape_functions(xi);
shapeEta = bfs_shape_functions(eta);

Hxi   = shapeXi.H;
dHxi  = shapeXi.dH;
d2Hxi = shapeXi.d2H;

Heta   = shapeEta.H;
dHeta  = shapeEta.dH;
d2Heta = shapeEta.d2H;

%==========================================================================
% 3. Define tensor-product index map for the 16 BFS scalar functions
%==========================================================================

% xiBasisIndex(c) gives which 1D Hermite function is used in the
% xi-direction for column c.
xiBasisIndex = [ ...
    1, 2, 1, 2, ...   % node 1: (-1,-1)
    3, 4, 3, 4, ...   % node 2: ( 1,-1)
    3, 4, 3, 4, ...   % node 3: ( 1, 1)
    1, 2, 1, 2];      % node 4: (-1, 1)

% etaBasisIndex(c) gives which 1D Hermite function is used in the
% eta-direction for column c.
etaBasisIndex = [ ...
    1, 1, 2, 2, ...   % node 1: (-1,-1)
    1, 1, 2, 2, ...   % node 2: ( 1,-1)
    3, 3, 4, 4, ...   % node 3: ( 1, 1)
    3, 3, 4, 4];      % node 4: (-1, 1)

numBasis = 16;

%==========================================================================
% 4. Allocate arrays
%==========================================================================

N           = zeros(nPoints, numBasis);
dN_dxi      = zeros(nPoints, numBasis);
dN_deta     = zeros(nPoints, numBasis);
d2N_dxi2    = zeros(nPoints, numBasis);
d2N_deta2   = zeros(nPoints, numBasis);
d2N_dxideta = zeros(nPoints, numBasis);

%==========================================================================
% 5. Construct tensor-product basis and derivatives
%==========================================================================

for c = 1:numBasis
    ix = xiBasisIndex(c);
    iy = etaBasisIndex(c);

    % Tensor-product basis.
    N(:, c) = Hxi(:, ix) .* Heta(:, iy);

    % First parent-coordinate derivatives.
    dN_dxi(:, c)  = dHxi(:, ix) .* Heta(:, iy);
    dN_deta(:, c) = Hxi(:, ix)  .* dHeta(:, iy);

    % Second parent-coordinate derivatives.
    d2N_dxi2(:, c)  = d2Hxi(:, ix) .* Heta(:, iy);
    d2N_deta2(:, c) = Hxi(:, ix)   .* d2Heta(:, iy);

    % Mixed parent-coordinate derivative.
    d2N_dxideta(:, c) = dHxi(:, ix) .* dHeta(:, iy);
end

%==========================================================================
% 6. Store output structure
%==========================================================================

shape2D = struct();

shape2D.N = N;
shape2D.dN_dxi = dN_dxi;
shape2D.dN_deta = dN_deta;
shape2D.d2N_dxi2 = d2N_dxi2;
shape2D.d2N_deta2 = d2N_deta2;
shape2D.d2N_dxideta = d2N_dxideta;

% Store parent coordinates for debugging and post-processing.
shape2D.xi = xi;
shape2D.eta = eta;

% Store tensor-product index maps for later verification of B and Bg
% matrix construction.
shape2D.xiBasisIndex = xiBasisIndex;
shape2D.etaBasisIndex = etaBasisIndex;

% Metadata useful for debugging and later element routines.
shape2D.numBasis = numBasis;
shape2D.numPoints = nPoints;
shape2D.order = 3;
shape2D.dimension = 2;
shape2D.type = 'Tensor-product BFS';
shape2D.family = 'Tensor-product cubic Hermite';
shape2D.element = 'Bogner-Fox-Schmit';
shape2D.localDofOrdering = { ...
    'node1_w', 'node1_wxi', 'node1_weta', 'node1_wxieta', ...
    'node2_w', 'node2_wxi', 'node2_weta', 'node2_wxieta', ...
    'node3_w', 'node3_wxi', 'node3_weta', 'node3_wxieta', ...
    'node4_w', 'node4_wxi', 'node4_weta', 'node4_wxieta'};

%==========================================================================
% 7. Internal verification checks
%==========================================================================

verificationTolerance = 1.0e-12;

% Verify that exactly 16 scalar basis functions are generated.
if size(shape2D.N, 2) ~= 16
    error('bfs_tensor_product:InvalidNumberOfBasisFunctions', ...
          'shape2D.N must contain exactly 16 scalar BFS basis functions.');
end

% Verify output dimensions.
expectedSize = [nPoints, numBasis];

if ~isequal(size(shape2D.N), expectedSize)
    error('bfs_tensor_product:InvalidNDimension', ...
          'shape2D.N has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

if ~isequal(size(shape2D.dN_dxi), expectedSize)
    error('bfs_tensor_product:InvaliddNdxiDimension', ...
          'shape2D.dN_dxi has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

if ~isequal(size(shape2D.dN_deta), expectedSize)
    error('bfs_tensor_product:InvaliddNdetaDimension', ...
          'shape2D.dN_deta has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

if ~isequal(size(shape2D.d2N_dxi2), expectedSize)
    error('bfs_tensor_product:Invalidd2Ndxi2Dimension', ...
          'shape2D.d2N_dxi2 has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

if ~isequal(size(shape2D.d2N_deta2), expectedSize)
    error('bfs_tensor_product:Invalidd2Ndeta2Dimension', ...
          'shape2D.d2N_deta2 has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

if ~isequal(size(shape2D.d2N_dxideta), expectedSize)
    error('bfs_tensor_product:Invalidd2NdxidetaDimension', ...
          'shape2D.d2N_dxideta has inconsistent dimensions. Expected [%d x %d].', ...
          expectedSize(1), expectedSize(2));
end

% Partition of unity is satisfied by the four value basis functions, not
% by all 16 Hermite basis functions.  The derivative-associated Hermite
% functions reproduce nodal derivatives and are not part of the constant
% field partition.  The value basis columns are 1, 5, 9, and 13.
valueColumns = [1, 5, 9, 13];

partitionValue = sum(N(:, valueColumns), 2);
partitionError = max(abs(partitionValue - 1.0));

if partitionError > verificationTolerance
    error('bfs_tensor_product:PartitionCheckFailed', ...
          ['Internal check failed: sum of value basis functions ', ...
           '[1,5,9,13] differs from 1. Maximum error = %.3e.'], ...
          partitionError);
end

partitionDerivativeXi = sum(dN_dxi(:, valueColumns), 2);
partitionDerivativeXiError = max(abs(partitionDerivativeXi));

if partitionDerivativeXiError > verificationTolerance
    error('bfs_tensor_product:PartitionDerivativeXiCheckFailed', ...
          ['Internal check failed: xi-derivative of the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          partitionDerivativeXiError);
end

partitionDerivativeEta = sum(dN_deta(:, valueColumns), 2);
partitionDerivativeEtaError = max(abs(partitionDerivativeEta));

if partitionDerivativeEtaError > verificationTolerance
    error('bfs_tensor_product:PartitionDerivativeEtaCheckFailed', ...
          ['Internal check failed: eta-derivative of the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          partitionDerivativeEtaError);
end

% Complete polynomial consistency checks for the second derivatives of the
% value-basis partition.  Since the value-basis partition is identically
% one, all second derivatives of that partition must be zero.
partitionSecondDerivativeXi = sum(d2N_dxi2(:, valueColumns), 2);
partitionSecondDerivativeXiError = max(abs(partitionSecondDerivativeXi));

if partitionSecondDerivativeXiError > verificationTolerance
    error('bfs_tensor_product:PartitionSecondDerivativeXiCheckFailed', ...
          ['Internal check failed: xi-second derivative of the ', ...
           'value-basis partition differs from 0. Maximum error = %.3e.'], ...
          partitionSecondDerivativeXiError);
end

partitionSecondDerivativeEta = sum(d2N_deta2(:, valueColumns), 2);
partitionSecondDerivativeEtaError = max(abs(partitionSecondDerivativeEta));

if partitionSecondDerivativeEtaError > verificationTolerance
    error('bfs_tensor_product:PartitionSecondDerivativeEtaCheckFailed', ...
          ['Internal check failed: eta-second derivative of the ', ...
           'value-basis partition differs from 0. Maximum error = %.3e.'], ...
          partitionSecondDerivativeEtaError);
end

partitionMixedDerivative = sum(d2N_dxideta(:, valueColumns), 2);
partitionMixedDerivativeError = max(abs(partitionMixedDerivative));

if partitionMixedDerivativeError > verificationTolerance
    error('bfs_tensor_product:PartitionMixedDerivativeCheckFailed', ...
          ['Internal check failed: mixed derivative of the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          partitionMixedDerivativeError);
end

end
