function jac = jacobian_bfs(elementCoords, shape2D)
%JACOBIAN_BFS Compute geometric Jacobian for a BFS rectangular element.
%
%   jac = jacobian_bfs(elementCoords, shape2D)
%
%   Purpose
%   -------
%   Computes the geometric mapping between the parent element
%   (xi, eta) and the physical element (x, y) at all evaluation points
%   stored in shape2D.
%
%   Inputs
%   ------
%   elementCoords : [4 x 2] array of physical nodal coordinates
%
%       elementCoords(A, :) = [x_A, y_A]
%
%       The node ordering must be the same as the BFS element ordering:
%
%           node 1: bottom-left   parent coordinate (-1,-1)
%           node 2: bottom-right  parent coordinate ( 1,-1)
%           node 3: top-right     parent coordinate ( 1, 1)
%           node 4: top-left      parent coordinate (-1, 1)
%
%   shape2D : structure returned by bfs_tensor_product()
%
%       Required fields:
%           shape2D.xi  : [nPoints x 1] parent xi coordinates
%           shape2D.eta : [nPoints x 1] parent eta coordinates
%
%   Outputs
%   -------
%   jac : structure with fields
%
%       jac.J        : [2 x 2 x nPoints] Jacobian matrices
%       jac.detJ     : [nPoints x 1] determinants of J
%       jac.invJ     : [2 x 2 x nPoints] inverse Jacobian matrices
%
%       jac.dxi_dx   : [nPoints x 1] dxi/dx
%       jac.deta_dx  : [nPoints x 1] deta/dx
%       jac.dxi_dy   : [nPoints x 1] dxi/dy
%       jac.deta_dy  : [nPoints x 1] deta/dy
%
%   Geometric mapping
%   -----------------
%   Although the BFS displacement field uses bicubic Hermite functions,
%   the geometry of a four-node rectangular element is described using the
%   four corner-node geometric mapping.  The standard four-node bilinear
%   parent-element shape functions are used for the geometry:
%
%       N1^g = 1/4 (1-xi)(1-eta),
%       N2^g = 1/4 (1+xi)(1-eta),
%       N3^g = 1/4 (1+xi)(1+eta),
%       N4^g = 1/4 (1-xi)(1+eta).
%
%   Hence
%
%       x(xi,eta) = sum_A N_A^g(xi,eta) x_A,
%       y(xi,eta) = sum_A N_A^g(xi,eta) y_A.
%
%   The Jacobian matrix is
%
%       J = [ dx/dxi   dx/deta ;
%             dy/dxi   dy/deta ].
%
%   This routine computes only first-derivative geometric quantities.  It
%   does NOT compute second-derivative transformations, B matrices, Bg
%   matrices, or stiffness matrices.

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 2
    error('jacobian_bfs:InvalidInputCount', ...
          'jacobian_bfs requires exactly two inputs: elementCoords and shape2D.');
end

if ~isnumeric(elementCoords) || ~isreal(elementCoords)
    error('jacobian_bfs:InvalidElementCoords', ...
          'elementCoords must be a real numeric array.');
end

if ~isequal(size(elementCoords), [4, 2])
    error('jacobian_bfs:InvalidElementCoordsSize', ...
          'elementCoords must have size [4 x 2].');
end

if any(~isfinite(elementCoords(:)))
    error('jacobian_bfs:NonFiniteElementCoords', ...
          'All entries of elementCoords must be finite.');
end

if ~isstruct(shape2D)
    error('jacobian_bfs:InvalidShape2D', ...
          'shape2D must be a structure returned by bfs_tensor_product().');
end

if ~isfield(shape2D, 'xi') || ~isfield(shape2D, 'eta')
    error('jacobian_bfs:MissingParentCoordinates', ...
          'shape2D must contain fields shape2D.xi and shape2D.eta.');
end

xi  = shape2D.xi;
eta = shape2D.eta;

if ~isnumeric(xi) || ~isnumeric(eta) || isempty(xi) || isempty(eta)
    error('jacobian_bfs:InvalidParentCoordinates', ...
          'shape2D.xi and shape2D.eta must be nonempty numeric arrays.');
end

xi  = xi(:);
eta = eta(:);

if numel(xi) ~= numel(eta)
    error('jacobian_bfs:InconsistentParentCoordinateSizes', ...
          'shape2D.xi and shape2D.eta must have the same number of entries.');
end

if any(~isfinite(xi)) || any(~isfinite(eta))
    error('jacobian_bfs:NonFiniteParentCoordinates', ...
          'All parent-coordinate evaluation points must be finite.');
end

nPoints = numel(xi);

%==========================================================================
% 2. Extract physical nodal coordinates
%==========================================================================

xNode = elementCoords(:, 1);
yNode = elementCoords(:, 2);

% Geometric consistency check at the four parent-element corner points.
% The bilinear geometric interpolation must reproduce the supplied nodal
% coordinates at the parent corners exactly up to round-off tolerance.
cornerXiEta = [ ...
    -1.0, -1.0; ...
     1.0, -1.0; ...
     1.0,  1.0; ...
    -1.0,  1.0];

geometryTolerance = 1.0e-12;
for a = 1:4
    xi_c  = cornerXiEta(a, 1);
    eta_c = cornerXiEta(a, 2);

    Ng_corner = 0.25 * [ ...
        (1.0 - xi_c) * (1.0 - eta_c); ...
        (1.0 + xi_c) * (1.0 - eta_c); ...
        (1.0 + xi_c) * (1.0 + eta_c); ...
        (1.0 - xi_c) * (1.0 + eta_c)];

    x_corner = Ng_corner.' * xNode;
    y_corner = Ng_corner.' * yNode;

    cornerError = max(abs([x_corner, y_corner] - elementCoords(a, :)));

    if cornerError > geometryTolerance
        error('jacobian_bfs:GeometricInterpolationCheckFailed', ...
              ['Bilinear geometric interpolation failed at parent ', ...
               'corner %d. Maximum coordinate error = %.3e.'], ...
              a, cornerError);
    end
end

% Rectangular element dimensions computed from the supplied nodal
% coordinates.  These are stored for later verification of derivative
% transformations in B and Bg matrix construction.
hx = norm(elementCoords(2, :) - elementCoords(1, :));
hy = norm(elementCoords(4, :) - elementCoords(1, :));

%==========================================================================
% 3. Allocate output arrays
%==========================================================================

J    = zeros(2, 2, nPoints);
invJ = zeros(2, 2, nPoints);
detJ = zeros(nPoints, 1);

dxi_dx  = zeros(nPoints, 1);
deta_dx = zeros(nPoints, 1);
dxi_dy  = zeros(nPoints, 1);
deta_dy = zeros(nPoints, 1);

% Store physical derivatives of the geometric mapping at each evaluation
% point.
dx_dxi_store  = zeros(nPoints, 1);
dx_deta_store = zeros(nPoints, 1);
dy_dxi_store  = zeros(nPoints, 1);
dy_deta_store = zeros(nPoints, 1);

% Store Jacobian condition numbers.
condJ = zeros(nPoints, 1);

% Small tolerance used to detect singular or nearly singular mappings.
singularityTolerance = 1.0e-14;

%==========================================================================
% 4. Compute Jacobian at every evaluation point
%==========================================================================

for q = 1:nPoints
    xi_q  = xi(q);
    eta_q = eta(q);

    %------------------------------------------------------------------
    % Derivatives of the four geometric bilinear shape functions.
    % Node order: [bottom-left, bottom-right, top-right, top-left].
    %------------------------------------------------------------------

    dNg_dxi = 0.25 * [ ...
        -(1.0 - eta_q); ...
         (1.0 - eta_q); ...
         (1.0 + eta_q); ...
        -(1.0 + eta_q)];

    dNg_deta = 0.25 * [ ...
        -(1.0 - xi_q); ...
        -(1.0 + xi_q); ...
         (1.0 + xi_q); ...
         (1.0 - xi_q)];

    %------------------------------------------------------------------
    % Geometric derivatives.
    %------------------------------------------------------------------

    dx_dxi  = dNg_dxi.'  * xNode;
    dx_deta = dNg_deta.' * xNode;
    dy_dxi  = dNg_dxi.'  * yNode;
    dy_deta = dNg_deta.' * yNode;

    J_q = [dx_dxi, dx_deta; ...
           dy_dxi, dy_deta];

    % Verify J is 2 x 2. This is also a defensive programming check.
    if ~isequal(size(J_q), [2, 2])
        error('jacobian_bfs:InvalidJacobianSize', ...
              'Jacobian matrix at point %d is not 2 x 2.', q);
    end

    detJ_q = J_q(1,1)*J_q(2,2) - J_q(1,2)*J_q(2,1);

    % Verify determinant is finite.
    if ~isfinite(detJ_q)
        error('jacobian_bfs:NonFiniteDeterminant', ...
              'Jacobian determinant is not finite at evaluation point %d.', q);
    end

    % Verify positive orientation and nonsingularity.
    if detJ_q <= 0.0
        error('jacobian_bfs:NonPositiveDeterminant', ...
              ['Jacobian determinant must be positive. ', ...
               'At evaluation point %d, detJ = %.16e.'], q, detJ_q);
    end

    if abs(detJ_q) <= singularityTolerance
        error('jacobian_bfs:SingularJacobian', ...
              ['Jacobian is singular or nearly singular at evaluation ', ...
               'point %d. detJ = %.16e.'], q, detJ_q);
    end

    %------------------------------------------------------------------
    % Analytical inverse of a 2 x 2 matrix.
    %
    % If
    %       J = [a b; c d],
    % then
    %       invJ = 1/detJ [d -b; -c a].
    %
    % Here invJ = d(xi,eta)/d(x,y):
    %       invJ = [ dxi/dx   dxi/dy ;
    %                deta/dx  deta/dy ].
    %------------------------------------------------------------------

    invJ_q = (1.0 / detJ_q) * [ ...
         J_q(2,2), -J_q(1,2); ...
        -J_q(2,1),  J_q(1,1)];

    % Verify inverse exists and is finite.
    if any(~isfinite(invJ_q(:)))
        error('jacobian_bfs:NonFiniteInverseJacobian', ...
              'Inverse Jacobian contains non-finite entries at point %d.', q);
    end

    % Optional consistency check: J * invJ should be approximately I.
    inverseCheckError = max(max(abs(J_q * invJ_q - eye(2))));
    if inverseCheckError > 1.0e-10
        error('jacobian_bfs:InverseJacobianCheckFailed', ...
              ['Inverse Jacobian verification failed at point %d. ', ...
               'Maximum error = %.3e.'], q, inverseCheckError);
    end

    % Compute Jacobian condition number.  A large condition number indicates
    % a distorted or ill-conditioned geometric mapping.  This is diagnostic
    % only, so execution is not stopped.
    condJ_q = cond(J_q);
    if condJ_q > 1.0e8
        warning('jacobian_bfs:LargeJacobianConditionNumber', ...
                ['Jacobian condition number is large at evaluation ', ...
                 'point %d: cond(J) = %.3e.'], q, condJ_q);
    end

    % Store quantities.
    J(:, :, q) = J_q;
    detJ(q) = detJ_q;
    invJ(:, :, q) = invJ_q;
    condJ(q) = condJ_q;

    dx_dxi_store(q)  = dx_dxi;
    dx_deta_store(q) = dx_deta;
    dy_dxi_store(q)  = dy_dxi;
    dy_deta_store(q) = dy_deta;

    dxi_dx(q)  = invJ_q(1,1);
    dxi_dy(q)  = invJ_q(1,2);
    deta_dx(q) = invJ_q(2,1);
    deta_dy(q) = invJ_q(2,2);
end

%==========================================================================
% 5. Store output structure
%==========================================================================

jac = struct();

jac.J = J;
jac.detJ = detJ;
jac.invJ = invJ;
jac.condJ = condJ;

jac.dxi_dx = dxi_dx;
jac.deta_dx = deta_dx;
jac.dxi_dy = dxi_dy;
jac.deta_dy = deta_dy;

% Physical derivatives of the geometric mapping.
jac.dx_dxi = dx_dxi_store;
jac.dx_deta = dx_deta_store;
jac.dy_dxi = dy_dxi_store;
jac.dy_deta = dy_deta_store;

% Rectangular element dimensions computed from the supplied nodal
% coordinates.
jac.hx = hx;
jac.hy = hy;

% Metadata useful for debugging and downstream modules.
jac.numPoints = nPoints;
jac.dimension = 2;
jac.geometryInterpolation = 'Bilinear';
jac.parentElement = '[-1,1] x [-1,1]';
jac.mapping = 'four-node bilinear geometric mapping for BFS rectangle';
jac.nodeOrdering = '1=bottom-left, 2=bottom-right, 3=top-right, 4=top-left';

end
