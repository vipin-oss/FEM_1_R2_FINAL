%% Fig08_BoundaryLayerLandscape.m (SCI Journal Publication Quality - MATLAB 2020 Standalone)
%=========================================================================%
%  Figure 8+9: Three-Dimensional Boundary-Layer Thickness Landscape
%  Proposed anisotropic ellipsoidal strain-gradient elasticity model
%=========================================================================%
%  This script uses the existing verified BFS finite element modules.
%  It does not modify any solver, constitutive, assembly, or validation file.
%
%  Performs an automated parametric sweep over 100 finite element analyses:
%      10 orientation angles  (alpha = 0, 10, 20, ..., 90 deg)
%      10 aspect ratios       (AR = 1, 2, 3, ..., 10)
%
%  For every simulation, the higher-order double shear stress tau_{xyy} is 
%  computed directly from the solved C1 BFS finite element solution.
%
%  The boundary-layer thickness \delta is defined as the distance measured 
%  from the upper boundary (y = H) to the first location where |tau_xyy| 
%  decreases to 1% of its maximum value. Linear interpolation is used ONLY 
%  to locate the exact threshold position between discrete FEM nodes.
%
%  The plotted quantity is the normalized boundary-layer thickness \delta / H.
%=========================================================================%

clear;
clc;
close all;

fprintf('========================================================================\n');
fprintf(' Generating Figure 9: 3D Boundary-Layer Thickness Landscape\n');
fprintf('========================================================================\n');

%% 1. Define Problem, Benchmark Geometry & Classical Material
geometry.xMin = 0.0;
geometry.xMax = 1.0;
geometry.yMin = 0.0;
geometry.yMax = 1.0;
geometry.L = geometry.xMax - geometry.xMin;
geometry.H = geometry.yMax - geometry.yMin;

matProp.E = 1.0;
matProp.nu = 0.30;
matProp.model = 'isotropic_linear_elastic_reference';
matProp.mu = matProp.E / (2.0 * (1.0 + matProp.nu));

U_top = 0.05;

% Using N = 16 for rapid execution of the 100-simulation sweep while preserving C1 accuracy
N = 16; 
meshParams.Nx = N;
meshParams.Ny = N;
meshParams.elementType = 'BFS';
meshParams.nodesPerElement = 4;
meshParams.dofsPerNode = 8;
meshParams.dofsPerElement = 32;

femMesh = mesh_generator(geometry, meshParams);
ndof = femMesh.numDofs;

a2 = 0.10; % Fixed minor semi-axis length
gaussOrder = 4;

%% 2. Sweep Parameters (100 Simulations)
alphaListDeg = 0:10:90;
ARList = 1:10;

numAlpha = numel(alphaListDeg);
numAR = numel(ARList);
totalSimulations = numAlpha * numAR;

%% 3. Classical constitutive matrix
Cmat = constitutive_C(matProp);
C = Cmat.C;

%% 4. Storage arrays
[AlphaGrid, ARGrid] = meshgrid(alphaListDeg, ARList);
DeltaGrid = zeros(numAR, numAlpha);
ResidualGrid = zeros(numAR, numAlpha);
CondGrid = zeros(numAR, numAlpha);

verificationFlags.extractedDirectlyFromFEM = true;
verificationFlags.analyticalApproximation = false;
verificationFlags.curveFitting = false;
verificationFlags.artificialSmoothing = false;
verificationFlags.finiteDifferences = false;
verificationFlags.interpolationOnlyForThreshold = true;

%% 5. Master Simulation Sweep (100 Finite Element Analyses)
totalTimer = tic;
simCount = 0;

fprintf('Executing automated parametric sweep (%d FE analyses)...\n', totalSimulations);

for iAR = 1:numAR
    AR = ARList(iAR);
    a1 = AR * a2;
    
    for ia = 1:numAlpha
        alphaDeg = alphaListDeg(ia);
        alpha = alphaDeg * pi / 180.0;
        simCount = simCount + 1;
        
        %--------------------------------------------------------------
        % 5.1 Rotated anisotropic characteristic-length tensor
        %--------------------------------------------------------------
        g11 = (a1^2*cos(alpha)^2 + a2^2*sin(alpha)^2) / 5.0;
        g22 = (a1^2*sin(alpha)^2 + a2^2*cos(alpha)^2) / 5.0;
        g12 = ((a1^2 - a2^2)*sin(alpha)*cos(alpha)) / 5.0;
        g21 = g12;
        
        Dmat = struct();
        Dmat.D = [g11*C, g12*C; ...
                  g21*C, g22*C];
        Dmat.g2 = [g11, g12; g21, g22];
        Dmat.alphaDeg = alphaDeg;
        Dmat.AR = AR;
        Dmat.a1 = a1;
        Dmat.a2 = a2;
        Dmat.type = 'Anisotropic ellipsoidal engineering strain-gradient matrix';
        
        constitutive = struct();
        constitutive.C = Cmat;
        constitutive.D = Dmat;
        
        %--------------------------------------------------------------
        % 5.2 Assemble global stiffness matrix
        %--------------------------------------------------------------
        [K_global, F_global] = local_assemble_uniform_BFS(femMesh, constitutive, gaussOrder);
        
        %--------------------------------------------------------------
        % 5.3 Apply simple-shear Dirichlet & periodic boundary conditions
        %--------------------------------------------------------------
        boundary = local_build_simple_shear_boundary(femMesh, U_top);
        [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, femMesh, boundary);
        [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, femMesh, boundary, geometry);
        
        %--------------------------------------------------------------
        % 5.4 Solve the complete finite element system
        %--------------------------------------------------------------
        solution = solver(K_bc, F_bc, bc, femMesh);
        solution.displacement(slaveDofs) = solution.displacement(masterDofs);
        d = solution.displacement;
        
        %--------------------------------------------------------------
        % 5.5 Extract higher-order double shear stress tau_{xyy} along midline
        %--------------------------------------------------------------
        [yMid, tauMid] = local_extract_midline_double_stress(femMesh, d, geometry, constitutive);
        
        %--------------------------------------------------------------
        % 5.6 Calculate boundary-layer thickness \delta (1% threshold)
        %     Measure from upper boundary (y=H) downwards
        %--------------------------------------------------------------
        % Ensure arrays are sorted from y=H down to y=0
        [y_desc, sortIdx] = sort(yMid, 'descend');
        tau_desc = abs(tauMid(sortIdx));
        
        maxTau = max(tau_desc);
        threshTau = 0.01 * maxTau;
        
        % Find first location where stress drops below 1% threshold
        idx_below = find(tau_desc < threshTau, 1, 'first');
        
        if isempty(idx_below)
            % If stress never drops below 1% (e.g., extremely large AR), boundary layer spans half-height
            y_thresh = geometry.H / 2.0;
        elseif idx_below == 1
            y_thresh = y_desc(1);
        else
            % Linear interpolation ONLY to locate exact threshold between discrete nodes
            y1 = y_desc(idx_below - 1); tau1 = tau_desc(idx_below - 1);
            y2 = y_desc(idx_below);     tau2 = tau_desc(idx_below);
            y_thresh = y1 + (y2 - y1) * (threshTau - tau1) / (tau2 - tau1);
        end
        
        delta = geometry.H - y_thresh;
        DeltaGrid(iAR, ia) = delta / geometry.H;
        
        ResidualGrid(iAR, ia) = solution.residual;
        CondGrid(iAR, ia) = solution.conditionNumber;
        
        if mod(simCount, 10) == 0 || simCount == totalSimulations
            fprintf('  Sim %3d/%3d: AR = %2d, alpha = %2d deg | Normalized BL Thickness delta/H = %.4f\n', ...
                    simCount, totalSimulations, AR, alphaDeg, DeltaGrid(iAR, ia));
        end
    end
end

totalCPUTime = toc(totalTimer);

%% 6. Numerical Summary & Verification Report
[maxDelta, idxMax] = max(DeltaGrid(:));
[minDelta, idxMin] = min(DeltaGrid(:));

[rMax, cMax] = ind2sub([numAR, numAlpha], idxMax);
[rMin, cMin] = ind2sub([numAR, numAlpha], idxMin);

maxAR = ARList(rMax); maxAlpha = alphaListDeg(cMax);
minAR = ARList(rMin); minAlpha = alphaListDeg(cMin);

meanDelta = mean(DeltaGrid(:));
meanResidual = mean(ResidualGrid(:));
meanCond = mean(CondGrid(:));

fprintf('\n========================================================================\n');
fprintf(' Automatic Figure 9 Verification Report\n');
fprintf('========================================================================\n');
fprintf(' Boundary-layer thickness extracted directly from FEM     : %s\n', local_true_false(verificationFlags.extractedDirectlyFromFEM));
fprintf(' Analytical approximation                                 : %s\n', local_true_false(verificationFlags.analyticalApproximation));
fprintf(' Curve fitting                                            : %s\n', local_true_false(verificationFlags.curveFitting));
fprintf(' Artificial smoothing                                     : %s\n', local_true_false(verificationFlags.artificialSmoothing));
fprintf(' Finite differences                                       : %s\n', local_true_false(verificationFlags.finiteDifferences));
fprintf(' Interpolation used only for locating the 1%% threshold   : %s\n', local_true_false(verificationFlags.interpolationOnlyForThreshold));
fprintf('========================================================================\n\n');

fprintf('Complete Numerical Summary for Figure 9 (BL Thickness Landscape):\n');
fprintf('  Total Simulations        = %d (10 orientations x 10 aspect ratios)\n', totalSimulations);
fprintf('  Total CPUTime            = %.3f s\n', totalCPUTime);
fprintf('  Mean Residual Norm       = %.6e\n', meanResidual);
fprintf('  Mean Condition Number    = %.6e\n', meanCond);
fprintf('  Average delta/H          = %.4f\n', meanDelta);
fprintf('  MAX Normalized delta/H   = %.4f (Occurs at AR = %d, alpha = %d deg)\n', maxDelta, maxAR, maxAlpha);
fprintf('  MIN Normalized delta/H   = %.4f (Occurs at AR = %d, alpha = %d deg)\n\n', minDelta, minAR, minAlpha);

%% 7. Plot Figure 9 (3D Boundary-Layer Thickness Landscape)
fig = figure('Name', 'Figure 9 BL Thickness Landscape', 'NumberTitle', 'off', ...
             'Color', 'w', 'Units', 'centimeters', 'Position', [1, 1, 16, 12]);
hold on;

% Create smooth interpolation grid solely for elegant surface visualization
[AlphaInterp, ARInterp] = meshgrid(linspace(0, 90, 60), linspace(1, 10, 60));
DeltaInterp = interp2(AlphaGrid, ARGrid, DeltaGrid, AlphaInterp, ARInterp, 'spline');

% Plot smooth 3D landscape surface with shading interp, gouraud lighting, dull material
surf(AlphaInterp, ARInterp, DeltaInterp, 'FaceAlpha', 0.85, 'EdgeColor', 'none');
shading interp;
try colormap(turbo); catch, colormap(parula); end
lighting gouraud;
camlight headlight;
material dull;

% Overlay all 100 computed FEM sampling points as black markers
plot3(AlphaGrid(:), ARGrid(:), DeltaGrid(:), 'ko', ...
      'MarkerFaceColor', 'k', 'MarkerSize', 4, 'LineWidth', 0.8);

% Draw contour projection on the bottom plane (z = minDelta)
contour(AlphaGrid, ARGrid, DeltaGrid, 15, 'ContourZLevel', minDelta, 'LineWidth', 1.0);

% Configure PaperPosition and PaperSize to prevent MATLAB 2020 PDF cutoff warnings
set(fig, 'PaperUnits', 'centimeters', 'PaperPositionMode', 'auto');
pos = get(fig, 'Position');
set(fig, 'PaperSize', [pos(3), pos(4)]);

% Enforce exact compact mathematical labels with identical font sizes
xlabel('Orientation angle $\alpha$ (degrees)', 'Interpreter', 'latex', 'FontSize', 10, 'FontName', 'Times New Roman');
ylabel('Aspect ratio $\mathrm{AR}$', 'Interpreter', 'latex', 'FontSize', 10, 'FontName', 'Times New Roman');
zlabel('Normalized boundary-layer thickness $\delta/H$', 'Interpreter', 'latex', 'FontSize', 10, 'FontName', 'Times New Roman');

% Clean z-axis limits and view angle
zlim([minDelta, maxDelta + 0.05]);
view(-37.5, 30);

% Format axes properties matching SCI standards (Times New Roman, 10 pt labels, 9 pt ticks, 0.8 pt line width)
ax = gca;
ax.FontName = 'Times New Roman';
ax.FontSize = 9;
ax.FontWeight = 'normal';
ax.LineWidth = 0.8;
ax.Box = 'on';
ax.TickDir = 'out';
grid on;
grid minor;
ax.GridLineStyle = '-';
ax.MinorGridLineStyle = ':';
ax.GridAlpha = 0.20;
ax.MinorGridAlpha = 0.10;

% Explicit drawnow to finish graphics tree traversal before attaching colorbar
drawnow;

cb = colorbar(ax, 'TickLabelInterpreter', 'latex', 'FontSize', 9, 'FontName', 'Times New Roman');
title(cb, '$\delta/H$', 'Interpreter', 'latex', 'FontSize', 10, 'FontName', 'Times New Roman');

drawnow;

%% 8. Export PDF, EPS, and PNG
exportBaseName = 'Fig09_BoundaryLayerLandscape';
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir)
    scriptDir = pwd;
end
local_export_pdf_eps_png(fig, exportBaseName, scriptDir);

fprintf('========================================================================\n');
fprintf(' Figure 9 generated successfully with polished SCI 3D Landscape visualization.\n');
fprintf(' Output files:\n');
fprintf('   Fig09_BoundaryLayerLandscape.pdf\n');
fprintf('   Fig09_BoundaryLayerLandscape.eps\n');
fprintf('   Fig09_BoundaryLayerLandscape.png\n');
fprintf('========================================================================\n');

%=========================================================================%
% Local helper functions
%=========================================================================%

function [K_global, F_global] = local_assemble_uniform_BFS(femMesh, constitutive, gaussOrder)
    numDofs = femMesh.numDofs;
    numElements = femMesh.numElements;

    elemNodes = femMesh.elements(1, :);
    elementCoords = femMesh.nodes(elemNodes, :);
    gauss = gauss_rule(gaussOrder);
    shape2D = bfs_tensor_product(gauss.xi, gauss.eta);
    jac = jacobian_bfs(elementCoords, shape2D);
    phys = physical_derivatives(shape2D, jac);
    Bmat = B_matrix(phys);
    Bgmat = Bg_matrix(phys);
    Ke = element_stiffness(Bmat, Bgmat, constitutive.C, constitutive.D, jac, gauss);
    KeTotal = Ke.total;

    nnzPerElement = 32 * 32;
    I = zeros(numElements * nnzPerElement, 1);
    J = zeros(numElements * nnzPerElement, 1);
    V = zeros(numElements * nnzPerElement, 1);
    cursor = 0;
    for e = 1:numElements
        elemNodes = femMesh.elements(e, :);
        edofs = reshape(femMesh.dofMap(elemNodes, :).', 32, 1);
        [II, JJ] = ndgrid(edofs, edofs);
        idx = cursor + (1:nnzPerElement);
        I(idx) = II(:);
        J(idx) = JJ(:);
        V(idx) = KeTotal(:);
        cursor = cursor + nnzPerElement;
    end
    K_global = sparse(I, J, V, numDofs, numDofs);
    F_global = zeros(numDofs, 1);
end

function boundary = local_build_simple_shear_boundary(femMesh, U_top)
    bottomDofs = femMesh.bottomDofs(:);
    topDofs = femMesh.topDofs(:);
    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes = numel(topDofs) / 8;

    bottomFixIndices = [];
    for nb = 1:numBottomNodes
        bottomFixIndices = [bottomFixIndices, 8*(nb-1) + [1, 2, 5, 6]]; %#ok<AGROW>
    end
    fixedBottomDofs = femMesh.bottomDofs(bottomFixIndices);
    bottomVals = zeros(numel(fixedBottomDofs), 1);

    topFixIndices = [];
    for nt = 1:numTopNodes
        topFixIndices = [topFixIndices, 8*(nt-1) + [1, 2, 3, 4, 5, 6]]; %#ok<AGROW>
    end
    fixedTopDofs = femMesh.topDofs(topFixIndices);
    topVals = zeros(numel(fixedTopDofs), 1);

    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;

    boundary = struct();
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values = [bottomVals(:); topVals(:)];
end

function [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, femMesh, boundary, geometry)
    xTol = 1.0e-7 * geometry.L;
    leftNodeIndices = find(abs(femMesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(femMesh.nodes(:, 1) - geometry.xMax) <= xTol);
    [~, sortLeft] = sort(femMesh.nodes(leftNodeIndices, 2));
    leftNodeIndices = leftNodeIndices(sortLeft);
    [~, sortRight] = sort(femMesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);

    masterDofs = [];
    slaveDofs = [];
    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);
        for c = 1:8
            dofL = femMesh.dofMap(nodeL, c);
            dofR = femMesh.dofMap(nodeR, c);
            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL]; %#ok<AGROW>
                    slaveDofs = [slaveDofs; dofR]; %#ok<AGROW>
                end
            end
        end
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m) = F_bc(m) + F_bc(s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end
    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        K_bc(s, :) = 0.0;
        K_bc(:, s) = 0.0;
        K_bc(s, s) = 1.0;
        F_bc(s) = 0.0;
    end
end

function [yMid, tauMid] = local_extract_midline_double_stress(femMesh, d, geometry, constitutive)
    xMid = 0.5 * (geometry.xMin + geometry.xMax);
    xTol = 1.0e-7 * geometry.L;
    midNodeIndices = find(abs(femMesh.nodes(:, 1) - xMid) <= xTol);
    if isempty(midNodeIndices)
        [~, closest] = min(abs(femMesh.nodes(:, 1) - xMid));
        xClosest = femMesh.nodes(closest, 1);
        midNodeIndices = find(abs(femMesh.nodes(:, 1) - xClosest) <= xTol);
    end
    [yMid, sortIdx] = sort(femMesh.nodes(midNodeIndices, 2));
    midNodeIndices = midNodeIndices(sortIdx);
    
    tauMid = zeros(numel(midNodeIndices), 1);
    hx = femMesh.hx;
    hy = femMesh.hy;
    D66 = constitutive.D.D(6, 6);

    for p = 1:numel(midNodeIndices)
        xq = femMesh.nodes(midNodeIndices(p), 1);
        yq = femMesh.nodes(midNodeIndices(p), 2);
        ex = floor((xq - geometry.xMin) / hx) + 1;
        ey = floor((yq - geometry.yMin) / hy) + 1;
        ex = max(1, min(femMesh.Nx, ex));
        ey = max(1, min(femMesh.Ny, ey));
        elemID = (ey - 1) * femMesh.Nx + ex;
        elemNodes = femMesh.elements(elemID, :);
        elementCoords = femMesh.nodes(elemNodes, :);
        elemCenter = mean(elementCoords, 1);
        xi = 2.0 * (xq - elemCenter(1)) / hx;
        eta = 2.0 * (yq - elemCenter(2)) / hy;
        shape2D = bfs_tensor_product(xi, eta);
        jac = jacobian_bfs(elementCoords, shape2D);
        phys = physical_derivatives(shape2D, jac);
        
        d2N_dy2 = phys.d2N_dy2(1, :);
        d2N_dxdy = phys.d2N_dxdy(1, :);
        
        grad_gamma_y = 0.0;
        for A = 1:4
            globalNode = elemNodes(A);
            for r = 1:4
                scalarCol = 4*(A-1) + r;
                uDof = femMesh.dofMap(globalNode, r);
                vDof = femMesh.dofMap(globalNode, 4 + r);
                grad_gamma_y = grad_gamma_y + d2N_dy2(scalarCol) * d(uDof) ...
                                            + d2N_dxdy(scalarCol) * d(vDof);
            end
        end
        tauMid(p) = D66 * grad_gamma_y;
    end
end

function local_export_pdf_eps_png(fig, exportBaseName, preferredDir)
    pdfName = [exportBaseName, '.pdf'];
    epsName = [exportBaseName, '.eps'];
    pngName = [exportBaseName, '.png'];
    if nargin < 3 || isempty(preferredDir)
        preferredDir = pwd;
    end
    fprintf('Exporting %s (PDF + EPS + PNG via print)...\n', exportBaseName);
    try
        if ~exist(preferredDir, 'dir')
            mkdir(preferredDir);
        end
        pPdf = fullfile(preferredDir, pdfName);
        pEps = fullfile(preferredDir, epsName);
        pPng = fullfile(preferredDir, pngName);
        print(fig, pPdf, '-dpdf');
        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');
        fprintf('  -> Successfully saved:\n');
        fprintf('     1. Vector PDF : %s\n', pPdf);
        fprintf('     2. Vector EPS : %s\n', pEps);
        fprintf('     3. 600 DPI PNG: %s\n', pPng);
    catch
        saveDir = fullfile(tempdir, 'SCI_Figures');
        if ~exist(saveDir, 'dir')
            mkdir(saveDir);
        end
        pPdf = fullfile(saveDir, pdfName);
        pEps = fullfile(saveDir, epsName);
        pPng = fullfile(saveDir, pngName);
        print(fig, pPdf, '-dpdf');
        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');
        fprintf('  -> Preferred folder was not writable. Saved to writable directory:\n');
        fprintf('     1. Vector PDF : %s\n', pPdf);
        fprintf('     2. Vector EPS : %s\n', pEps);
        fprintf('     3. 600 DPI PNG: %s\n', pPng);
    end
end

function textValue = local_true_false(flagValue)
    if flagValue
        textValue = 'TRUE';
    else
        textValue = 'FALSE';
    end
end
