function Bgmat = Bg_matrix(phys)
%BG_MATRIX Construct higher-order strain-gradient matrix for BFS element.
%
%   Bgmat = Bg_matrix(phys)
%
%   Purpose
%   -------
%   Constructs the higher-order strain-gradient matrix Bg for the
%   plane-strain Bogner--Fox--Schmit (BFS) element at every Gauss or
%   evaluation point.
%
%   This routine uses ONLY the second physical derivatives of the scalar
%   BFS basis functions returned by physical_derivatives():
%
%       phys.d2N_dx2
%       phys.d2N_dxdy
%       phys.d2N_dy2
%
%   It does NOT recompute derivatives, does NOT compute constitutive
%   matrices, does NOT compute stiffness matrices, and does NOT perform
%   numerical integration.
%
%   Strain-gradient ordering
%   ------------------------
%   The frozen strain-gradient ordering is
%
%       1: epsilon_xx,x
%       2: epsilon_yy,x
%       3: gamma_xy,x
%       4: epsilon_xx,y
%       5: epsilon_yy,y
%       6: gamma_xy,y
%
%   with engineering shear strain
%
%       gamma_xy = du/dy + dv/dx.
%
%   Therefore,
%
%       epsilon_xx,x = u,xx
%       epsilon_yy,x = v,xy
%       gamma_xy,x   = u,xy + v,xx
%       epsilon_xx,y = u,xy
%       epsilon_yy,y = v,yy
%       gamma_xy,y   = u,yy + v,xy
%
%   BFS element DOF ordering
%   ------------------------
%   The element has 4 nodes and 8 DOFs per node.  At node A, the local
%   nodal DOF ordering is
%
%       1: u
%       2: u,x
%       3: u,y
%       4: u,xy
%       5: v
%       6: v,x
%       7: v,y
%       8: v,xy
%
%   The element therefore has 32 DOFs.
%
%   Scalar BFS basis ordering
%   -------------------------
%   The scalar BFS tensor-product basis contains 16 scalar basis
%   functions.  For node A, the four scalar basis-function columns are
%
%       scalarCols(A) = 4*(A-1)+1 : 4*A.
%
%   These four scalar basis functions multiply the scalar nodal DOFs
%   [w, w_x, w_y, w_xy] for each displacement component.
%
%   Output
%   ------
%   Bgmat : structure with fields
%       Bgmat.Bg        : [6 x 32 x nGauss] strain-gradient matrices
%       Bgmat.numGauss  : number of Gauss/evaluation points
%       Bgmat.numRows   : number of strain-gradient components, equal to 6
%       Bgmat.numDofs   : number of element DOFs, equal to 32

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 1
    error('Bg_matrix:InvalidInputCount', ...
          'Bg_matrix requires exactly one input: phys.');
end

if ~isstruct(phys)
    error('Bg_matrix:InvalidInput', ...
          'Input phys must be a structure returned by physical_derivatives().');
end

requiredFields = {'d2N_dx2', 'd2N_dxdy', 'd2N_dy2'};
for k = 1:numel(requiredFields)
    fieldName = requiredFields{k};
    if ~isfield(phys, fieldName)
        error('Bg_matrix:MissingField', ...
              'phys.%s is required.', fieldName);
    end
end

d2N_dx2  = phys.d2N_dx2;
d2N_dxdy = phys.d2N_dxdy;
d2N_dy2  = phys.d2N_dy2;

if ~isnumeric(d2N_dx2) || ~isreal(d2N_dx2) || ...
   ~isnumeric(d2N_dxdy) || ~isreal(d2N_dxdy) || ...
   ~isnumeric(d2N_dy2) || ~isreal(d2N_dy2)
    error('Bg_matrix:InvalidDerivativeData', ...
          'phys.d2N_dx2, phys.d2N_dxdy, and phys.d2N_dy2 must be real numeric arrays.');
end

if ~isequal(size(d2N_dx2), size(d2N_dxdy), size(d2N_dy2))
    error('Bg_matrix:DerivativeSizeMismatch', ...
          'phys.d2N_dx2, phys.d2N_dxdy, and phys.d2N_dy2 must have identical dimensions.');
end

[nGauss, numScalarBasis] = size(d2N_dx2);

if numScalarBasis ~= 16
    error('Bg_matrix:InvalidNumberOfScalarBasisFunctions', ...
          'Expected 16 scalar BFS basis functions, but found %d.', ...
          numScalarBasis);
end

if nGauss < 1
    error('Bg_matrix:InvalidNumberOfGaussPoints', ...
          'At least one Gauss/evaluation point is required.');
end

if any(~isfinite(d2N_dx2(:))) || ...
   any(~isfinite(d2N_dxdy(:))) || ...
   any(~isfinite(d2N_dy2(:)))
    error('Bg_matrix:NonFiniteDerivativeData', ...
          'All entries of phys.d2N_dx2, phys.d2N_dxdy, and phys.d2N_dy2 must be finite.');
end

%==========================================================================
% 2. Allocate Bg matrix array
%==========================================================================

numNodes = 4;
scalarDofsPerNode = 4;
dofsPerNode = 8;
numGradientComponents = 6;
numElementDofs = numNodes * dofsPerNode;

Bg = zeros(numGradientComponents, numElementDofs, nGauss);

%==========================================================================
% 3. Construct Bg matrix at every Gauss point
%==========================================================================

for q = 1:nGauss
    Bgq = zeros(numGradientComponents, numElementDofs);

    for A = 1:numNodes
        scalarCols = (4*(A-1) + 1):(4*A);

        for r = 1:scalarDofsPerNode
            scalarCol = scalarCols(r);

            N_xx = d2N_dx2(q, scalarCol);
            N_xy = d2N_dxdy(q, scalarCol);
            N_yy = d2N_dy2(q, scalarCol);

            % Local element column numbers for the corresponding u and v
            % scalar BFS DOFs.
            col_u = dofsPerNode*(A-1) + r;
            col_v = dofsPerNode*(A-1) + 4 + r;

            % Row 1: epsilon_xx,x = u,xx
            Bgq(1, col_u) = N_xx;

            % Row 2: epsilon_yy,x = v,xy
            Bgq(2, col_v) = N_xy;

            % Row 3: gamma_xy,x = u,xy + v,xx
            Bgq(3, col_u) = N_xy;
            Bgq(3, col_v) = N_xx;

            % Row 4: epsilon_xx,y = u,xy
            Bgq(4, col_u) = N_xy;

            % Row 5: epsilon_yy,y = v,yy
            Bgq(5, col_v) = N_yy;

            % Row 6: gamma_xy,y = u,yy + v,xy
            Bgq(6, col_u) = N_yy;
            Bgq(6, col_v) = N_xy;
        end
    end

    Bg(:, :, q) = Bgq;
end

%==========================================================================
% 4. Internal verification
%==========================================================================

expectedSize = [6, 32, nGauss];
if ~isequal(size(Bg), expectedSize)
    error('Bg_matrix:InvalidBgSize', ...
          'Bg must have dimensions [6 x 32 x nGauss].');
end

% Verify row and column dimensions explicitly for every Gauss point.
for q = 1:nGauss
    if size(Bg(:, :, q), 1) ~= 6
        error('Bg_matrix:InvalidBgRowCount', ...
              'Bg(:,:,q) must have 6 rows at Gauss point %d.', q);
    end

    if size(Bg(:, :, q), 2) ~= 32
        error('Bg_matrix:InvalidBgColumnCount', ...
              'Bg(:,:,q) must have 32 columns at Gauss point %d.', q);
    end
end

% Store sparsity information for each Gauss point.  This is useful for
% later verification of assembly efficiency.
nnzPerGauss = zeros(nGauss, 1);
for q = 1:nGauss
    nnzPerGauss(q) = nnz(Bg(:, :, q));
end

if any(~isfinite(Bg(:)))
    error('Bg_matrix:NonFiniteBgEntries', ...
          'Bg contains non-finite entries.');
end

% Verify correct DOF placement by checking that rows with purely u or v
% contributions contain zeros in the opposite displacement columns.
uColumns = [];
vColumns = [];
for A = 1:numNodes
    uColumns = [uColumns, dofsPerNode*(A-1) + (1:4)]; %#ok<AGROW>
    vColumns = [vColumns, dofsPerNode*(A-1) + (5:8)]; %#ok<AGROW>
end

allColumns = 1:numElementDofs;
notUColumns = setdiff(allColumns, uColumns);
notVColumns = setdiff(allColumns, vColumns);

if numel(union(uColumns, vColumns)) ~= numElementDofs
    error('Bg_matrix:InvalidDofPartition', ...
          'u and v DOF columns do not cover all 32 element DOFs.');
end

placementTolerance = 1.0e-14;

for q = 1:nGauss
    Bgq = Bg(:, :, q);

    % Row 1: epsilon_xx,x = u,xx must have entries only in u columns.
    if max(abs(Bgq(1, notUColumns))) > placementTolerance
        error('Bg_matrix:IncorrectRow1DofPlacement', ...
              ['Row 1 epsilon_xx,x contains nonzero entries in non-u ', ...
               'DOF columns at Gauss point %d.'], q);
    end

    % Row 2: epsilon_yy,x = v,xy must have entries only in v columns.
    if max(abs(Bgq(2, notVColumns))) > placementTolerance
        error('Bg_matrix:IncorrectRow2DofPlacement', ...
              ['Row 2 epsilon_yy,x contains nonzero entries in non-v ', ...
               'DOF columns at Gauss point %d.'], q);
    end

    % Row 4: epsilon_xx,y = u,xy must have entries only in u columns.
    if max(abs(Bgq(4, notUColumns))) > placementTolerance
        error('Bg_matrix:IncorrectRow4DofPlacement', ...
              ['Row 4 epsilon_xx,y contains nonzero entries in non-u ', ...
               'DOF columns at Gauss point %d.'], q);
    end

    % Row 5: epsilon_yy,y = v,yy must have entries only in v columns.
    if max(abs(Bgq(5, notVColumns))) > placementTolerance
        error('Bg_matrix:IncorrectRow5DofPlacement', ...
              ['Row 5 epsilon_yy,y contains nonzero entries in non-v ', ...
               'DOF columns at Gauss point %d.'], q);
    end

    % Rows 3 and 6 are engineering shear-gradient rows.  They are allowed
    % to contain entries in both u and v columns.
end

%==========================================================================
% 5. Store output structure
%==========================================================================

Bgmat = struct();

Bgmat.Bg = Bg;
Bgmat.numGauss = nGauss;
Bgmat.numRows = numGradientComponents;
Bgmat.numDofs = numElementDofs;
Bgmat.numScalarBasis = numScalarBasis;

% Row indices for the frozen strain-gradient ordering.
Bgmat.epsxx_x_Row = 1;
Bgmat.epsyy_x_Row = 2;
Bgmat.gammaxy_x_Row = 3;
Bgmat.epsxx_y_Row = 4;
Bgmat.epsyy_y_Row = 5;
Bgmat.gammaxy_y_Row = 6;

% Sparsity information per Gauss point.
Bgmat.nnzPerGauss = nnzPerGauss;

Bgmat.gradOrdering = { ...
    'epsilon_xx_x', ...
    'epsilon_yy_x', ...
    'gamma_xy_x', ...
    'epsilon_xx_y', ...
    'epsilon_yy_y', ...
    'gamma_xy_y'};

Bgmat.dofOrderingPerNode = {'u', 'ux', 'uy', 'uxy', 'v', 'vx', 'vy', 'vxy'};
Bgmat.uColumns = uColumns;
Bgmat.vColumns = vColumns;
Bgmat.type = 'Strain-gradient';
Bgmat.kinematics = 'Plane strain';
Bgmat.strainDefinition = 'Engineering strain';
Bgmat.description = 'Higher-order plane-strain engineering Bg matrix for BFS element';

end
