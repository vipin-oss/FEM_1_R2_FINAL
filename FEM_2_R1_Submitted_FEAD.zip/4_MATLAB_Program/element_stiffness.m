function Ke = element_stiffness(Bmat, Bgmat, Cmat, Dmat, jac, gauss)
%ELEMENT_STIFFNESS Compute element stiffness matrix for a BFS rectangle.
%
%   Ke = element_stiffness(Bmat, Bgmat, Cmat, Dmat, jac, gauss)
%
%   Purpose
%   -------
%   Compute the element stiffness matrix for a single four-node
%   Bogner--Fox--Schmit (BFS) plane-strain strain-gradient finite element.
%   Assembles both the classical elasticity contribution and the
%   strain-gradient contribution using Gauss-Legendre numerical integration.
%
%   Inputs
%   ------
%   Bmat  : structure containing Bmat.B [3 x 32 x nGauss]
%   Bgmat : structure containing Bgmat.Bg [6 x 32 x nGauss]
%   Cmat  : structure containing Cmat.C [3 x 3]
%   Dmat  : structure containing Dmat.D [6 x 6]
%   jac   : structure containing jac.detJ [nGauss x 1]
%   gauss : structure containing gauss.weights [nGauss x 1] and numPoints
%
%   Outputs
%   -------
%   Ke : structure containing
%       Ke.classical   : [32 x 32] classical elasticity stiffness matrix
%       Ke.gradient    : [32 x 32] strain-gradient stiffness matrix
%       Ke.total       : [32 x 32] total assembled stiffness matrix
%       Ke.minimumEigenvalue : minimum eigenvalue of Ke.total
%       Ke.maximumEigenvalue : maximum eigenvalue of Ke.total
%       Ke.numDofs     : number of element DOFs, equal to 32
%       Ke.numGauss    : number of Gauss integration points
%       Ke.integration : numerical integration method description
%       Ke.elementType : element formulation description
%       Ke.kinematics  : kinematic assumption description
%       Ke.description : detailed formulation description string
%
%   Important
%   ---------
%   This routine computes ONLY the local element stiffness matrix Ke.
%   It does NOT assemble global matrices, does NOT apply boundary
%   conditions, does NOT solve linear systems, and does NOT modify any
%   constitutive or kinematic routines.
%==========================================================================

%==========================================================================
% 1. Input checking and structure validation
%==========================================================================
if nargin ~= 6
    error('element_stiffness:InvalidInputCount', ...
          'element_stiffness requires exactly 6 input arguments.');
end

if ~isstruct(Bmat) || ~isstruct(Bgmat) || ~isstruct(Cmat) || ...
   ~isstruct(Dmat) || ~isstruct(jac)   || ~isstruct(gauss)
    error('element_stiffness:InvalidStructInput', ...
          'All input arguments (Bmat, Bgmat, Cmat, Dmat, jac, gauss) must be structures.');
end

requiredFields = { ...
    {Bmat, 'B', 'Bmat'}, ...
    {Bgmat, 'Bg', 'Bgmat'}, ...
    {Cmat, 'C', 'Cmat'}, ...
    {Dmat, 'D', 'Dmat'}, ...
    {jac, 'detJ', 'jac'}, ...
    {gauss, 'weights', 'gauss'}, ...
    {gauss, 'numPoints', 'gauss'}};

for k = 1:numel(requiredFields)
    s        = requiredFields{k}{1};
    fName    = requiredFields{k}{2};
    sName    = requiredFields{k}{3};
    if ~isfield(s, fName)
        error('element_stiffness:MissingField', ...
              '%s.%s is required.', sName, fName);
    end
end

B       = Bmat.B;
Bg      = Bgmat.Bg;
C       = Cmat.C;
D       = Dmat.D;
detJ    = jac.detJ(:);
weights = gauss.weights(:);

%==========================================================================
% 2. Numerical and dimensional verification before assembly
%==========================================================================
if ~isnumeric(B) || ~isnumeric(Bg) || ~isnumeric(C) || ~isnumeric(D) || ...
   ~isnumeric(detJ) || ~isnumeric(weights)
    error('element_stiffness:NonNumericData', ...
          'All active matrix and vector input fields must be numeric.');
end

nGauss = numel(weights);
if gauss.numPoints ~= nGauss
    error('element_stiffness:GaussPointsMismatch', ...
          'gauss.numPoints (%d) does not match numel(gauss.weights) (%d).', ...
          gauss.numPoints, nGauss);
end

if numel(detJ) ~= nGauss
    error('element_stiffness:DetJLengthMismatch', ...
          'Length of jac.detJ (%d) must match number of Gauss points (%d).', ...
          numel(detJ), nGauss);
end

if ~isequal(size(B), [3, 32, nGauss])
    error('element_stiffness:InvalidBSize', ...
          'Verification failed: Bmat.B must have dimensions [3 x 32 x nGauss].');
end

if ~isequal(size(Bg), [6, 32, nGauss])
    error('element_stiffness:InvalidBgSize', ...
          'Verification failed: Bgmat.Bg must have dimensions [6 x 32 x nGauss].');
end

if ~isequal(size(C), [3, 3])
    error('element_stiffness:InvalidCSize', ...
          'Verification failed: Cmat.C must have size [3 x 3].');
end

if ~isequal(size(D), [6, 6])
    error('element_stiffness:InvalidDSize', ...
          'Verification failed: Dmat.D must have size [6 x 6].');
end

if any(~isfinite(B(:)))    || any(~isfinite(Bg(:)))   || ...
   any(~isfinite(C(:)))    || any(~isfinite(D(:)))    || ...
   any(~isfinite(detJ(:))) || any(~isfinite(weights(:)))
    error('element_stiffness:NonFiniteInputData', ...
          'Verification failed: all input matrices and vectors must contain finite values.');
end

if any(detJ <= 0.0)
    error('element_stiffness:InvertedElement', ...
          'Verification failed: all(detJ > 0) violated. Element is inverted or severely distorted.');
end

if any(weights <= 0.0)
    error('element_stiffness:NonPositiveWeights', ...
          'Verification failed: all(weights > 0) violated. Quadrature weights must be strictly positive.');
end

%==========================================================================
% 3. Element stiffness assembly via Gauss-Legendre quadrature
%==========================================================================
Kc = zeros(32, 32);
Kg = zeros(32, 32);

for q = 1:nGauss
    Bq  = B(:, :, q);
    Bgq = Bg(:, :, q);
    detJ_q = detJ(q);
    w_q    = weights(q);
    
    factor = detJ_q * w_q;
    
    % Classical elasticity stiffness contribution at Gauss point q.
    Kc_q = (Bq.') * C * Bq * factor;
    
    % Strain-gradient stiffness contribution at Gauss point q.
    Kg_q = (Bgq.') * D * Bgq * factor;
    
    % Accumulate element contributions.
    Kc = Kc + Kc_q;
    Kg = Kg + Kg_q;
end

% Explicitly enforce numerical symmetry to eliminate double-precision round-off 
% artifacts that occur at higher characteristic length scales (\ell = 0.2, 0.3 mm)
Kc = (Kc + Kc.') / 2.0;
Kg = (Kg + Kg.') / 2.0;
Ke_total = Kc + Kg;

%==========================================================================
% 4. Output numerical and symmetry verification
%==========================================================================
if ~isequal(size(Kc), [32, 32]) || ~isequal(size(Kg), [32, 32]) || ...
   ~isequal(size(Ke_total), [32, 32])
    error('element_stiffness:InvalidOutputSize', ...
          'Verification failed: Kc, Kg, and Ke_total must have size [32 x 32].');
end

if any(~isfinite(Kc(:))) || any(~isfinite(Kg(:))) || any(~isfinite(Ke_total(:)))
    error('element_stiffness:NonFiniteOutput', ...
          'Verification failed: computed stiffness matrices contain non-finite entries.');
end

symTol = 1.0e-8; % Adjusted tolerance for high-magnitude constitutive parameters
symErrC = max(max(abs(Kc - Kc.')));
if symErrC > symTol
    error('element_stiffness:NonSymmetricClassicalStiffness', ...
          'Verification failed: Kc is not symmetric (tolerance 1e-8). Error = %.3e.', ...
          symErrC);
end

symErrG = max(max(abs(Kg - Kg.')));
if symErrG > symTol
    error('element_stiffness:NonSymmetricGradientStiffness', ...
          'Verification failed: Kg is not symmetric (tolerance 1e-8). Error = %.3e.', ...
          symErrG);
end

symErrTotal = max(max(abs(Ke_total - Ke_total.')));
if symErrTotal > symTol
    error('element_stiffness:NonSymmetricTotalStiffness', ...
          'Verification failed: Ke_total is not symmetric (tolerance 1e-8). Error = %.3e.', ...
          symErrTotal);
end

%==========================================================================
% 5. Store output structure and metadata
%==========================================================================
eigVals = eig((Ke_total + Ke_total.') / 2.0);

Ke = struct();
Ke.classical = Kc;
Ke.gradient  = Kg;
Ke.total     = Ke_total;

% Diagnostic spectral metadata.
Ke.minimumEigenvalue = min(eigVals);
Ke.maximumEigenvalue = max(eigVals);

% Required metadata fields.
Ke.numDofs     = 32;
Ke.numGauss    = gauss.numPoints;
Ke.integration = 'Gauss-Legendre';
Ke.elementType = 'BFS';
Ke.kinematics  = 'Plane strain';
Ke.description = 'Element stiffness matrix for Mindlin Form-II strain-gradient elasticity';

end
