function [K_global, F_global, assembly] = assembly(K_global, F_global, mesh, geometry, meshParams, constitutive, material, gradient, problem)
%ASSEMBLY Assemble global stiffness matrix and force vector for BFS mesh.
%
%   [K_global, F_global, assembly] = assembly(K_global, F_global, mesh, ...
%       geometry, meshParams, constitutive, material, gradient, problem)
%
%   Purpose
%   -------
%   Assemble the global stiffness matrix and global external force vector
%   for the complete Bogner--Fox--Schmit (BFS) plane-strain strain-gradient
%   finite element mesh.
%
%   Inputs
%   ------
%   K_global     : [numDofs x numDofs] sparse global stiffness matrix
%   F_global     : [numDofs x 1] global external force vector
%   mesh         : finite element mesh structure from mesh_generator()
%   geometry     : problem geometry structure
%   meshParams   : discretization parameter structure
%   constitutive : structure containing constitutive.C and constitutive.D
%   material     : classical material parameter structure
%   gradient     : strain-gradient parameter structure
%   problem      : problem identification structure
%
%   Outputs
%   -------
%   K_global : [numDofs x numDofs] assembled sparse global stiffness matrix
%   F_global : [numDofs x 1] assembled global force vector
%   assembly : metadata structure containing assembly diagnostic information
%
%   Important
%   ---------
%   No body forces are active in the benchmark simple-shear problem.
%   Therefore, F_global is left unchanged except for validation within the
%   assembly framework. This routine does NOT apply boundary conditions,
%   does NOT solve linear systems, and does NOT perform post-processing.
%==========================================================================

%==========================================================================
% 1. Input argument validation and structure checking
%==========================================================================
if nargin < 9
    error('assembly:InvalidInputCount', ...
          'assembly requires exactly 9 input arguments.');
end

if ~isstruct(mesh) || ~isfield(mesh, 'elements') || ~isfield(mesh, 'nodes') || ...
   ~isfield(mesh, 'dofMap') || ~isfield(mesh, 'numElements') || ~isfield(mesh, 'numDofs')
    error('assembly:InvalidMeshStruct', ...
          'Input mesh structure is missing required fields.');
end

if ~isstruct(constitutive)
    error('assembly:InvalidConstitutiveStruct', ...
          'Input constitutive must be a structure.');
end

% Defensive alignment: ensure constitutive.C and constitutive.D strictly
% adhere to the structure interface contracts demanded by element_stiffness.m.
if ~isfield(constitutive, 'C') || ~isfield(constitutive, 'D')
    error('assembly:MissingConstitutiveFields', ...
          'constitutive.C and constitutive.D are required.');
end

if ~isstruct(constitutive.C) || ~isfield(constitutive.C, 'C')
    if isnumeric(constitutive.C)
        constitutive.C = struct('C', constitutive.C);
    else
        error('assembly:InvalidConstitutiveC', ...
              'constitutive.C must be a numeric matrix or a structure containing .C');
    end
end

if ~isstruct(constitutive.D) || ~isfield(constitutive.D, 'D')
    if isnumeric(constitutive.D)
        constitutive.D = struct('D', constitutive.D);
    else
        error('assembly:InvalidConstitutiveD', ...
              'constitutive.D must be a numeric matrix or a structure containing .D');
    end
end

numElements   = mesh.numElements;
numGlobalDofs = mesh.numDofs;

if ~isequal(size(K_global), [numGlobalDofs, numGlobalDofs])
    error('assembly:InvalidGlobalStiffnessSize', ...
          'K_global must have dimensions [%d x %d].', numGlobalDofs, numGlobalDofs);
end

if ~isequal(size(F_global), [numGlobalDofs, 1])
    error('assembly:InvalidGlobalForceSize', ...
          'F_global must have dimensions [%d x 1].', numGlobalDofs);
end

%==========================================================================
% 2. Element loop and global stiffness assembly
%==========================================================================
gaussOrder = 3;

for e = 1:numElements
    % 1. Extract the four node numbers from mesh.elements.
    elemNodes = mesh.elements(e, :);
    
    % 2. Extract element coordinates from mesh.nodes.
    elementCoords = mesh.nodes(elemNodes, :);
    
    % 3. Generate Gauss quadrature rule.
    %    (Use 3x3 integration unless another order is specified later.)
    gauss = gauss_rule(gaussOrder);
    
    % 4. Evaluate 2D tensor-product BFS shape functions.
    shape2D = bfs_tensor_product(gauss.xi, gauss.eta);
    
    % 5. Compute geometric Jacobian mapping.
    jac = jacobian_bfs(elementCoords, shape2D);
    
    % 6. Compute physical spatial derivatives.
    phys = physical_derivatives(shape2D, jac);
    
    % 7. Compute classical strain-displacement B matrix.
    Bmat = B_matrix(phys);
    
    % 8. Compute higher-order strain-gradient Bg matrix.
    Bgmat = Bg_matrix(phys);
    
    % 9. Compute local element stiffness matrices.
    Ke = element_stiffness(Bmat, Bgmat, ...
                           constitutive.C, ...
                           constitutive.D, ...
                           jac, ...
                           gauss);
    
    % 10. Obtain the 32 global DOFs of the element from mesh.dofMap.
    %     Reshaping the transposed nodal DOF block preserves the established
    %     node-by-node kinematic ordering: [node1_DOFs; ...; node4_DOFs].
    edofs = reshape(mesh.dofMap(elemNodes, :).', 32, 1);
    
    % Element-level verification checks.
    if numel(edofs) ~= 32
        error('assembly:InvalidElementDofCount', ...
              'Verification failed: number of element DOFs must be exactly 32.');
    end
    
    if any(edofs < 1) || any(edofs > numGlobalDofs) || any(edofs ~= round(edofs))
        error('assembly:InvalidGlobalDofIndex', ...
              'Verification failed: element %d contains invalid global DOF indices.', e);
    end
    
    if ~isequal(size(Ke.total), [32, 32])
        error('assembly:InvalidKeTotalSize', ...
              'Verification failed: Ke.total must be 32 x 32.');
    end
    
    % 11. Assemble element contributions into global stiffness matrix.
    K_global(edofs, edofs) = K_global(edofs, edofs) + Ke.total;
end

% validation of global external force vector framework.
% Leave F_global unchanged as benchmark body forces are zero.

%==========================================================================
% 3. Global verification checks after assembly
%==========================================================================
if any(~isfinite(K_global(:))) || any(~isfinite(F_global(:)))
    error('assembly:NonFiniteAssembledEntries', ...
          'Verification failed: all assembled global matrix and vector entries must remain finite.');
end

symTol = 1.0e-9;
symErrGlobal = max(max(abs(K_global - K_global.')));
if symErrGlobal > symTol
    error('assembly:NonSymmetricGlobalMatrix', ...
          'Verification failed: K_global remains symmetric check violated. Error = %.3e.', ...
          symErrGlobal);
end

%==========================================================================
% 4. Store metadata
%==========================================================================
assembly = struct();
assembly.numElements = numElements;
assembly.numDofs     = numGlobalDofs;
assembly.gaussOrder  = gaussOrder;
assembly.elementType = 'BFS';

end
