function phys = physical_derivatives(shape2D, jac)
%PHYSICAL_DERIVATIVES Transform BFS derivatives to physical coordinates.
%
%   phys = physical_derivatives(shape2D, jac)
%
%   Purpose
%   -------
%   Transforms the parent-coordinate derivatives of the scalar BFS shape
%   functions from (xi, eta) to physical coordinates (x, y).
%
%   This routine computes ONLY the physical derivatives of the 16 scalar
%   BFS basis functions:
%
%       dN/dx, dN/dy,
%       d2N/dx2, d2N/dy2, d2N/dxdy.
%
%   It does NOT compute strains, B matrices, Bg matrices, or stiffness
%   matrices.
%
%   Inputs
%   ------
%   shape2D : structure returned by bfs_tensor_product()
%       Required fields:
%           shape2D.dN_dxi
%           shape2D.dN_deta
%           shape2D.d2N_dxi2
%           shape2D.d2N_deta2
%           shape2D.d2N_dxideta
%
%   jac : structure returned by jacobian_bfs()
%       Required fields:
%           jac.dxi_dx
%           jac.deta_dx
%           jac.dxi_dy
%           jac.deta_dy
%
%   Outputs
%   -------
%   phys : structure with fields
%       phys.dN_dx       : [nPoints x 16] dN/dx
%       phys.dN_dy       : [nPoints x 16] dN/dy
%       phys.d2N_dx2     : [nPoints x 16] d2N/dx2
%       phys.d2N_dy2     : [nPoints x 16] d2N/dy2
%       phys.d2N_dxdy    : [nPoints x 16] d2N/(dx dy)
%
%   Chain-rule derivation
%   ---------------------
%   For a scalar shape function N(xi,eta), the first derivatives are
%
%       dN/dx = (dxi/dx)  dN/dxi + (deta/dx) dN/deta,
%       dN/dy = (dxi/dy)  dN/dxi + (deta/dy) dN/deta.
%
%   For an affine rectangular mapping, the inverse-Jacobian entries
%   dxi/dx, deta/dx, dxi/dy, deta/dy are constants within the element and
%   all second derivatives of the mapping vanish.  Therefore,
%
%       d2N/dx2
%       = (dxi/dx)^2 d2N/dxi2
%       + 2(dxi/dx)(deta/dx) d2N/(dxi deta)
%       + (deta/dx)^2 d2N/deta2,
%
%       d2N/dy2
%       = (dxi/dy)^2 d2N/dxi2
%       + 2(dxi/dy)(deta/dy) d2N/(dxi deta)
%       + (deta/dy)^2 d2N/deta2,
%
%       d2N/(dx dy)
%       = (dxi/dx)(dxi/dy) d2N/dxi2
%       + [(dxi/dx)(deta/dy) + (deta/dx)(dxi/dy)] d2N/(dxi deta)
%       + (deta/dx)(deta/dy) d2N/deta2.
%
%   These are the only derivative transformations performed here.

%==========================================================================
% 1. Input checking
%==========================================================================

if nargin ~= 2
    error('physical_derivatives:InvalidInputCount', ...
          'physical_derivatives requires exactly two inputs: shape2D and jac.');
end

if ~isstruct(shape2D)
    error('physical_derivatives:InvalidShape2D', ...
          'shape2D must be a structure returned by bfs_tensor_product().');
end

if ~isstruct(jac)
    error('physical_derivatives:InvalidJacobian', ...
          'jac must be a structure returned by jacobian_bfs().');
end

requiredShapeFields = { ...
    'dN_dxi', ...
    'dN_deta', ...
    'd2N_dxi2', ...
    'd2N_deta2', ...
    'd2N_dxideta'};

for k = 1:numel(requiredShapeFields)
    fieldName = requiredShapeFields{k};
    if ~isfield(shape2D, fieldName)
        error('physical_derivatives:MissingShapeField', ...
              'shape2D.%s is required.', fieldName);
    end
end

requiredJacFields = { ...
    'dxi_dx', ...
    'deta_dx', ...
    'dxi_dy', ...
    'deta_dy'};

for k = 1:numel(requiredJacFields)
    fieldName = requiredJacFields{k};
    if ~isfield(jac, fieldName)
        error('physical_derivatives:MissingJacobianField', ...
              'jac.%s is required.', fieldName);
    end
end

% Extract parent-coordinate derivatives.
dN_dxi      = shape2D.dN_dxi;
dN_deta     = shape2D.dN_deta;
d2N_dxi2    = shape2D.d2N_dxi2;
d2N_deta2   = shape2D.d2N_deta2;
d2N_dxideta = shape2D.d2N_dxideta;

% Extract inverse-Jacobian entries.
dxi_dx  = jac.dxi_dx(:);
deta_dx = jac.deta_dx(:);
dxi_dy  = jac.dxi_dy(:);
deta_dy = jac.deta_dy(:);

%==========================================================================
% 2. Dimension checks before transformation
%==========================================================================

if ~isnumeric(dN_dxi) || ~isnumeric(dN_deta) || ...
   ~isnumeric(d2N_dxi2) || ~isnumeric(d2N_deta2) || ...
   ~isnumeric(d2N_dxideta)
    error('physical_derivatives:NonNumericShapeData', ...
          'All derivative arrays in shape2D must be numeric.');
end

[nPoints, numBasis] = size(dN_dxi);

if numBasis ~= 16
    error('physical_derivatives:InvalidNumberOfBasisFunctions', ...
          'shape2D derivative arrays must contain exactly 16 BFS basis functions.');
end

expectedSize = [nPoints, numBasis];

if ~isequal(size(dN_deta), expectedSize) || ...
   ~isequal(size(d2N_dxi2), expectedSize) || ...
   ~isequal(size(d2N_deta2), expectedSize) || ...
   ~isequal(size(d2N_dxideta), expectedSize)
    error('physical_derivatives:InconsistentShapeDimensions', ...
          ['All shape2D derivative arrays must have the same dimensions ', ...
           '[nPoints x 16].']);
end

if numel(dxi_dx) ~= nPoints || numel(deta_dx) ~= nPoints || ...
   numel(dxi_dy) ~= nPoints || numel(deta_dy) ~= nPoints
    error('physical_derivatives:InconsistentJacobianDimensions', ...
          ['jac derivative arrays must have the same number of entries ', ...
           'as the number of Gauss/evaluation points in shape2D.']);
end

if any(~isfinite(dN_dxi(:))) || any(~isfinite(dN_deta(:))) || ...
   any(~isfinite(d2N_dxi2(:))) || any(~isfinite(d2N_deta2(:))) || ...
   any(~isfinite(d2N_dxideta(:)))
    error('physical_derivatives:NonFiniteShapeDerivatives', ...
          'All parent-coordinate derivative values must be finite.');
end

if any(~isfinite(dxi_dx)) || any(~isfinite(deta_dx)) || ...
   any(~isfinite(dxi_dy)) || any(~isfinite(deta_dy))
    error('physical_derivatives:NonFiniteJacobianDerivatives', ...
          'All inverse-Jacobian derivative entries must be finite.');
end

%==========================================================================
% 3. First-order physical derivatives
%==========================================================================

% Chain rule:
%   dN/dx = (dxi/dx) dN/dxi + (deta/dx) dN/deta
%   dN/dy = (dxi/dy) dN/dxi + (deta/dy) dN/deta
%
% bsxfun is used for compatibility with MATLAB versions that do not
% support implicit expansion.
dN_dx = bsxfun(@times, dN_dxi,  dxi_dx) + ...
        bsxfun(@times, dN_deta, deta_dx);

dN_dy = bsxfun(@times, dN_dxi,  dxi_dy) + ...
        bsxfun(@times, dN_deta, deta_dy);

%==========================================================================
% 4. Second-order physical derivatives
%==========================================================================

% For an affine mapping, second derivatives of xi(x,y) and eta(x,y)
% vanish.  Therefore only products of first inverse-Jacobian entries are
% required.

coef_xx_xixi    = dxi_dx.^2;
coef_xx_xieta   = 2.0 * dxi_dx .* deta_dx;
coef_xx_etaeta  = deta_dx.^2;

coef_yy_xixi    = dxi_dy.^2;
coef_yy_xieta   = 2.0 * dxi_dy .* deta_dy;
coef_yy_etaeta  = deta_dy.^2;

coef_xy_xixi    = dxi_dx .* dxi_dy;
coef_xy_xieta   = dxi_dx .* deta_dy + deta_dx .* dxi_dy;
coef_xy_etaeta  = deta_dx .* deta_dy;

% d2N/dx2
d2N_dx2 = bsxfun(@times, d2N_dxi2,    coef_xx_xixi) + ...
          bsxfun(@times, d2N_dxideta, coef_xx_xieta) + ...
          bsxfun(@times, d2N_deta2,   coef_xx_etaeta);

% d2N/dy2
d2N_dy2 = bsxfun(@times, d2N_dxi2,    coef_yy_xixi) + ...
          bsxfun(@times, d2N_dxideta, coef_yy_xieta) + ...
          bsxfun(@times, d2N_deta2,   coef_yy_etaeta);

% d2N/(dx dy)
d2N_dxdy = bsxfun(@times, d2N_dxi2,    coef_xy_xixi) + ...
           bsxfun(@times, d2N_dxideta, coef_xy_xieta) + ...
           bsxfun(@times, d2N_deta2,   coef_xy_etaeta);

%==========================================================================
% 5. Output verification
%==========================================================================

if ~isequal(size(dN_dx), expectedSize)
    error('physical_derivatives:InvaliddNdxDimension', ...
          'phys.dN_dx must have dimensions [nPoints x 16].');
end

if ~isequal(size(dN_dy), expectedSize)
    error('physical_derivatives:InvaliddNdyDimension', ...
          'phys.dN_dy must have dimensions [nPoints x 16].');
end

if ~isequal(size(d2N_dx2), expectedSize)
    error('physical_derivatives:Invalidd2Ndx2Dimension', ...
          'phys.d2N_dx2 must have dimensions [nPoints x 16].');
end

if ~isequal(size(d2N_dy2), expectedSize)
    error('physical_derivatives:Invalidd2Ndy2Dimension', ...
          'phys.d2N_dy2 must have dimensions [nPoints x 16].');
end

if ~isequal(size(d2N_dxdy), expectedSize)
    error('physical_derivatives:Invalidd2NdxdyDimension', ...
          'phys.d2N_dxdy must have dimensions [nPoints x 16].');
end

if any(~isfinite(dN_dx(:))) || any(~isfinite(dN_dy(:))) || ...
   any(~isfinite(d2N_dx2(:))) || any(~isfinite(d2N_dy2(:))) || ...
   any(~isfinite(d2N_dxdy(:)))
    error('physical_derivatives:NonFinitePhysicalDerivatives', ...
          'All physical derivative values must be finite.');
end

% Verify that all output derivative arrays have identical dimensions.
if ~isequal(size(dN_dx), size(dN_dy), size(d2N_dx2), ...
            size(d2N_dy2), size(d2N_dxdy))
    error('physical_derivatives:InconsistentOutputDimensions', ...
          ['All physical derivative arrays must have identical ', ...
           'dimensions [nPoints x 16].']);
end

% Verify derivative identities for the value-basis partition of unity.
% For the BFS Hermite tensor-product basis, the constant-field partition
% is formed by the four value basis columns [1, 5, 9, 13].  The derivative
% basis functions reproduce nodal derivative degrees of freedom and are
% not included in the constant-field partition.
verificationTolerance = 1.0e-12;
valueColumns = [1, 5, 9, 13];

dN_dx_sum = sum(dN_dx(:, valueColumns), 2);
dN_dx_sum_error = max(abs(dN_dx_sum));
if dN_dx_sum_error > verificationTolerance
    error('physical_derivatives:dNdxPartitionCheckFailed', ...
          ['Internal check failed: sum(dN/dx) over the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          dN_dx_sum_error);
end

dN_dy_sum = sum(dN_dy(:, valueColumns), 2);
dN_dy_sum_error = max(abs(dN_dy_sum));
if dN_dy_sum_error > verificationTolerance
    error('physical_derivatives:dNdyPartitionCheckFailed', ...
          ['Internal check failed: sum(dN/dy) over the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          dN_dy_sum_error);
end

d2N_dx2_sum = sum(d2N_dx2(:, valueColumns), 2);
d2N_dx2_sum_error = max(abs(d2N_dx2_sum));
if d2N_dx2_sum_error > verificationTolerance
    error('physical_derivatives:d2Ndx2PartitionCheckFailed', ...
          ['Internal check failed: sum(d2N/dx2) over the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          d2N_dx2_sum_error);
end

d2N_dy2_sum = sum(d2N_dy2(:, valueColumns), 2);
d2N_dy2_sum_error = max(abs(d2N_dy2_sum));
if d2N_dy2_sum_error > verificationTolerance
    error('physical_derivatives:d2Ndy2PartitionCheckFailed', ...
          ['Internal check failed: sum(d2N/dy2) over the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          d2N_dy2_sum_error);
end

d2N_dxdy_sum = sum(d2N_dxdy(:, valueColumns), 2);
d2N_dxdy_sum_error = max(abs(d2N_dxdy_sum));
if d2N_dxdy_sum_error > verificationTolerance
    error('physical_derivatives:d2NdxdyPartitionCheckFailed', ...
          ['Internal check failed: sum(d2N/dxdy) over the value-basis ', ...
           'partition differs from 0. Maximum error = %.3e.'], ...
          d2N_dxdy_sum_error);
end

%==========================================================================
% 6. Store output structure
%==========================================================================

phys = struct();

phys.dN_dx = dN_dx;
phys.dN_dy = dN_dy;
phys.d2N_dx2 = d2N_dx2;
phys.d2N_dy2 = d2N_dy2;
phys.d2N_dxdy = d2N_dxdy;

% Store chain-rule coefficients used in the second-derivative
% transformations.  These are useful for debugging the Bg matrix.
phys.coef_xx_xixi = coef_xx_xixi;
phys.coef_xx_xieta = coef_xx_xieta;
phys.coef_xx_etaeta = coef_xx_etaeta;

phys.coef_yy_xixi = coef_yy_xixi;
phys.coef_yy_xieta = coef_yy_xieta;
phys.coef_yy_etaeta = coef_yy_etaeta;

phys.coef_xy_xixi = coef_xy_xixi;
phys.coef_xy_xieta = coef_xy_xieta;
phys.coef_xy_etaeta = coef_xy_etaeta;

% Metadata for downstream verification and debugging.
phys.numPoints = nPoints;
phys.numBasis = numBasis;
phys.dimension = 2;
phys.coordinateSystem = 'Cartesian';
phys.assumption = 'Affine rectangular mapping';
phys.derivativeSystem = 'physical';
phys.mappingAssumption = 'affine rectangular mapping; second mapping derivatives vanish';

end
