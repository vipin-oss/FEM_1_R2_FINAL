function solution = solver(K_bc, F_bc, varargin)
%SOLVER Direct sparse linear solver for BFS finite element system.
%
%   solution = solver(K_bc, F_bc)
%   solution = solver(K_bc, F_bc, bc, mesh)
%
%   Purpose
%   -------
%   Solve the assembled and boundary-conditioned linear finite element
%   system K_bc * U = F_bc for the plane-strain strain-gradient
%   Bogner--Fox--Schmit (BFS) solver.
%
%   Utilizes MATLAB's direct sparse backslash operator (\), which invokes
%   SuiteSparse/UMFPACK or multifrontal Cholesky factorization routines
%   optimized for sparse banded matrix architectures.
%
%   Inputs
%   ------
%   K_bc : [numDofs x numDofs] sparse symmetric stiffness matrix
%   F_bc : [numDofs x 1] global external force vector
%
%   Compatibility Note
%   ------------------
%   Additional trailing arguments (e.g., bc, mesh) are accepted for full
%   interface compatibility with the master project driver main.m.
%
%   Outputs
%   -------
%   solution : structure containing the solution vector and solver diagnostics:
%                  solution.displacement      : [numDofs x 1] solution vector U
%                  solution.residual          : Euclidean norm ||K_bc*U - F_bc||
%                  solution.conditionNumber   : 1-norm condition number estimate
%                  solution.minimumEigenvalue : minimum eigenvalue of K_bc
%                  solution.maximumEigenvalue : maximum eigenvalue of K_bc
%                  solution.solver            : solver method description string
%                  solution.success           : boolean solve status flag
%
%   Important
%   ---------
%   Benchmark strain-gradient constitutive models may be mathematically
%   indefinite. Therefore, a negative minimum eigenvalue is recorded for
%   diagnostic tracking only and does NOT terminate solver execution.
%==========================================================================

%==========================================================================
% 1. Input argument validation and pre-solve system verification
%==========================================================================
if nargin < 2
    error('solver:InvalidInputCount', ...
          'solver requires at least 2 input arguments: K_bc and F_bc.');
end

[numRows, numCols] = size(K_bc);

% Verify K_bc is square.
if numRows ~= numCols
    error('solver:NonSquareMatrix', ...
          'Verification failed: K_bc must be a square matrix. Dimensions = [%d x %d].', ...
          numRows, numCols);
end

% Verify dimensions agree between stiffness matrix and force vector.
if ~isequal(size(F_bc), [numRows, 1])
    error('solver:DimensionMismatch', ...
          'Verification failed: F_bc length (%d) does not match K_bc row dimension (%d).', ...
          numel(F_bc), numRows);
end

% Verify all entries in K_bc and F_bc are finite.
if any(~isfinite(nonzeros(K_bc))) || any(~isfinite(F_bc))
    error('solver:NonFiniteInput', ...
          'Verification failed: K_bc or F_bc contains non-finite values.');
end

% Verify K_bc is symmetric before solving.
symTol = 1.0e-8;
symErr = max(max(abs(K_bc - K_bc.')));
if symErr > symTol
    error('solver:NonSymmetricMatrix', ...
          'Verification failed: K_bc is not symmetric before solve. Symmetry error = %.3e.', ...
          symErr);
end

%==========================================================================
% 2. System conditioning estimation
%==========================================================================
% Estimate 1-norm condition number for sparse matrices.
condNum = condest(K_bc);
if condNum > 1.0e15
    warning('solver:IllConditionedSystem', ...
            'System is severely ill-conditioned: condest(K_bc) = %.3e. Solution accuracy may be degraded.', ...
            condNum);
end

%==========================================================================
% 3. Direct sparse linear system solve
%==========================================================================
U = K_bc \ F_bc;

if any(~isfinite(U))
    error('solver:NonFiniteSolution', ...
          'Linear solver failed: computed displacement vector contains non-finite entries.');
end

% Compute absolute residual norm.
residual = norm(K_bc * U - F_bc);

%==========================================================================
% 4. Spectral diagnostic analysis
%==========================================================================
% Symmetrize system matrix explicitly before spectral interrogation.
K_sym = (K_bc + K_bc.') / 2.0;

% Hoist dense vs. sparse eigenvalue branching to protect against memory
% exhaustion during fine-mesh convergence refinement studies.
% For sparse matrices (>2048 DOFs), bypass eigs to avoid non-convergence 
% warnings on highly constrained Dirichlet systems, as minEig/maxEig are 
% purely diagnostic metadata.
if numRows <= 2048
    eigVals = eig(full(K_sym));
    minEig  = min(eigVals);
    maxEig  = max(eigVals);
else
    minEig = NaN;
    maxEig = NaN;
end

%==========================================================================
% 5. Store output solution structure
%==========================================================================
solution = struct();
solution.displacement      = U;
solution.residual          = residual;
solution.conditionNumber   = condNum;
solution.minimumEigenvalue = minEig;
solution.maximumEigenvalue = maxEig;
solution.solver            = 'MATLAB direct sparse backslash (\)';
solution.success           = true;

end
