function mesh = mesh_generator(geometry, meshParams)
%MESH_GENERATOR Generate a structured rectangular BFS finite element mesh.
%
%   mesh = mesh_generator(geometry, meshParams)
%
%   Purpose
%   -------
%   Generates a structured rectangular mesh for the four-node
%   Bogner--Fox--Schmit (BFS) element.  This routine only creates the
%   geometric mesh, element connectivity, boundary-node sets, and global
%   degree-of-freedom numbering.  It does NOT impose periodic constraints,
%   does NOT impose boundary conditions, and does NOT evaluate shape
%   functions.
%
%   Inputs
%   ------
%   geometry : structure with fields
%       geometry.xMin : minimum x-coordinate
%       geometry.xMax : maximum x-coordinate
%       geometry.yMin : minimum y-coordinate
%       geometry.yMax : maximum y-coordinate
%
%   meshParams : structure with fields
%       meshParams.Nx          : number of elements in x-direction
%       meshParams.Ny          : number of elements in y-direction
%       meshParams.dofsPerNode : number of DOFs per node; must be 8 for BFS
%
%   Outputs
%   -------
%   mesh : structure with fields
%       mesh.nodes       : [numNodes x 2] nodal coordinates [x, y]
%       mesh.elements    : [numElements x 4] element connectivity
%                          ordered as [bottom-left, bottom-right,
%                                      top-right, top-left]
%       mesh.numNodes    : total number of nodes
%       mesh.numElements : total number of elements
%       mesh.numDofs     : total number of global DOFs
%       mesh.dofMap      : [numNodes x 8] global DOF numbers per node
%       mesh.leftNodes   : nodes on x = xMin
%       mesh.rightNodes  : nodes on x = xMax
%       mesh.bottomNodes : nodes on y = yMin
%       mesh.topNodes    : nodes on y = yMax
%
%   BFS Nodal DOF Ordering
%   ----------------------
%   Each node has 8 degrees of freedom ordered as
%
%       1: u
%       2: u,x
%       3: u,y
%       4: u,xy
%       5: v
%       6: v,x
%       7: v,y
%       8: v,xy
%
%   Global Node Numbering
%   ---------------------
%   Nodes are numbered row-wise from bottom to top, with x varying fastest:
%
%       nodeID(i,j) = j*(Nx+1) + i + 1,
%
%   where i = 0,...,Nx and j = 0,...,Ny.
%
%   Element Connectivity
%   --------------------
%   Elements are numbered row-wise from bottom to top, with x varying
%   fastest.  For each rectangular element, the local node ordering is
%
%       [1 2 3 4] = [bottom-left, bottom-right, top-right, top-left].
%
%   This ordering is consistent with the parent BFS element coordinates
%
%       1: (-1,-1),  2: ( 1,-1),  3: ( 1, 1),  4: (-1, 1).

%==========================================================================
% 1. Basic input checking
%==========================================================================

if nargin ~= 2
    error('mesh_generator:InvalidInputCount', ...
          'mesh_generator requires exactly two inputs: geometry and meshParams.');
end

if ~isstruct(geometry)
    error('mesh_generator:InvalidGeometry', ...
          'Input geometry must be a structure.');
end

if ~isstruct(meshParams)
    error('mesh_generator:InvalidMeshParams', ...
          'Input meshParams must be a structure.');
end

requiredGeometryFields = {'xMin','xMax','yMin','yMax'};
for k = 1:numel(requiredGeometryFields)
    fieldName = requiredGeometryFields{k};
    if ~isfield(geometry, fieldName)
        error('mesh_generator:MissingGeometryField', ...
              'geometry.%s is required.', fieldName);
    end
end

requiredMeshFields = {'Nx','Ny','dofsPerNode'};
for k = 1:numel(requiredMeshFields)
    fieldName = requiredMeshFields{k};
    if ~isfield(meshParams, fieldName)
        error('mesh_generator:MissingMeshField', ...
              'meshParams.%s is required.', fieldName);
    end
end

xMin = geometry.xMin;
xMax = geometry.xMax;
yMin = geometry.yMin;
yMax = geometry.yMax;

Nx = meshParams.Nx;
Ny = meshParams.Ny;
dofsPerNode = meshParams.dofsPerNode;

if ~isscalar(xMin) || ~isscalar(xMax) || ~isscalar(yMin) || ~isscalar(yMax)
    error('mesh_generator:InvalidGeometryValues', ...
          'geometry bounds must be scalar values.');
end

if ~isfinite(xMin) || ~isfinite(xMax) || ~isfinite(yMin) || ~isfinite(yMax)
    error('mesh_generator:NonFiniteGeometry', ...
          'geometry bounds must be finite values.');
end

if xMax <= xMin
    error('mesh_generator:InvalidXBounds', ...
          'geometry.xMax must be greater than geometry.xMin.');
end

if yMax <= yMin
    error('mesh_generator:InvalidYBounds', ...
          'geometry.yMax must be greater than geometry.yMin.');
end

if ~isscalar(Nx) || Nx < 1 || Nx ~= round(Nx)
    error('mesh_generator:InvalidNx', ...
          'meshParams.Nx must be a positive integer.');
end

if ~isscalar(Ny) || Ny < 1 || Ny ~= round(Ny)
    error('mesh_generator:InvalidNy', ...
          'meshParams.Ny must be a positive integer.');
end

if ~isscalar(dofsPerNode) || dofsPerNode ~= 8
    error('mesh_generator:InvalidDofsPerNode', ...
          'meshParams.dofsPerNode must be 8 for the BFS plane-strain element.');
end

%==========================================================================
% 2. Mesh dimensions
%==========================================================================

numNodesX = Nx + 1;
numNodesY = Ny + 1;

numNodes    = numNodesX * numNodesY;
numElements = Nx * Ny;
numDofs     = numNodes * dofsPerNode;

% Uniform structured grid coordinates.
xCoords = linspace(xMin, xMax, numNodesX);
yCoords = linspace(yMin, yMax, numNodesY);

%==========================================================================
% 3. Generate nodal coordinates
%==========================================================================

nodes = zeros(numNodes, 2);

% Node numbering:
%   j = 0,...,Ny labels rows in the y-direction.
%   i = 0,...,Nx labels columns in the x-direction.
%   x varies fastest.
for j = 0:Ny
    for i = 0:Nx
        nodeID = j * numNodesX + i + 1;
        nodes(nodeID, 1) = xCoords(i + 1);
        nodes(nodeID, 2) = yCoords(j + 1);
    end
end

%==========================================================================
% 4. Generate element connectivity
%==========================================================================

elements = zeros(numElements, 4);

elemID = 0;
for ey = 1:Ny
    for ex = 1:Nx
        elemID = elemID + 1;

        % Convert element indices to zero-based lower-left grid indices.
        i = ex - 1;
        j = ey - 1;

        % Local node ordering:
        %   n1 = bottom-left
        %   n2 = bottom-right
        %   n3 = top-right
        %   n4 = top-left
        n1 = j       * numNodesX + i     + 1;
        n2 = j       * numNodesX + i + 1 + 1;
        n3 = (j + 1) * numNodesX + i + 1 + 1;
        n4 = (j + 1) * numNodesX + i     + 1;

        elements(elemID, :) = [n1, n2, n3, n4];
    end
end

%==========================================================================
% 5. Generate global DOF numbering table
%==========================================================================

% dofMap(I,r) gives the global DOF number associated with node I and
% local nodal DOF r.
dofMap = zeros(numNodes, dofsPerNode);

for I = 1:numNodes
    firstDof = dofsPerNode * (I - 1) + 1;
    lastDof  = dofsPerNode * I;
    dofMap(I, :) = firstDof:lastDof;
end

%==========================================================================
% 6. Generate boundary-node sets
%==========================================================================

% Since the mesh is structured, boundary nodes can be generated directly
% from the node-numbering rule.

bottomNodes = zeros(numNodesX, 1);
topNodes    = zeros(numNodesX, 1);
leftNodes   = zeros(numNodesY, 1);
rightNodes  = zeros(numNodesY, 1);

% Bottom and top boundaries: x varies fastest.
for i = 0:Nx
    bottomNodes(i + 1) = 0  * numNodesX + i + 1;
    topNodes(i + 1)    = Ny * numNodesX + i + 1;
end

% Left and right boundaries: y varies from bottom to top.
for j = 0:Ny
    leftNodes(j + 1)  = j * numNodesX + 0  + 1;
    rightNodes(j + 1) = j * numNodesX + Nx + 1;
end

%==========================================================================
% 7. Store mesh data in output structure
%==========================================================================

mesh = struct();

mesh.nodes       = nodes;
mesh.elements    = elements;
mesh.numNodes    = numNodes;
mesh.numElements = numElements;
mesh.numDofs     = numDofs;
mesh.dofMap      = dofMap;

% Descriptive local DOF names following the established BFS ordering:
%   1: u,  2: u,x,  3: u,y,  4: u,xy,
%   5: v,  6: v,x,  7: v,y,  8: v,xy.
% These names are useful for debugging, boundary-condition application,
% and post-processing.
mesh.dofNames = { ...
    'u', ...
    'ux', ...
    'uy', ...
    'uxy', ...
    'v', ...
    'vx', ...
    'vy', ...
    'vxy'};

mesh.leftNodes   = leftNodes;
mesh.rightNodes  = rightNodes;
mesh.topNodes    = topNodes;
mesh.bottomNodes = bottomNodes;

% Boundary DOF lists.  Each array contains all global DOF numbers
% associated with the corresponding boundary-node set, preserving the
% established local DOF ordering at each node.
mesh.leftDofs   = reshape(dofMap(leftNodes,   :).', [], 1);
mesh.rightDofs  = reshape(dofMap(rightNodes,  :).', [], 1);
mesh.topDofs    = reshape(dofMap(topNodes,    :).', [], 1);
mesh.bottomDofs = reshape(dofMap(bottomNodes, :).', [], 1);

% Store useful metadata for later modules.
mesh.Nx = Nx;
mesh.Ny = Ny;
mesh.numNodesX = numNodesX;
mesh.numNodesY = numNodesY;
mesh.dofsPerNode = dofsPerNode;
mesh.dofsPerElement = 4 * dofsPerNode;
mesh.xCoords = xCoords(:);
mesh.yCoords = yCoords(:);
mesh.xMin = xMin;
mesh.xMax = xMax;
mesh.yMin = yMin;
mesh.yMax = yMax;
mesh.hx = (xMax - xMin) / Nx;
mesh.hy = (yMax - yMin) / Ny;

% Element area for the structured rectangular mesh.  This value is useful
% for Gaussian integration checks and error calculations.
mesh.elementArea = mesh.hx * mesh.hy;

% Geometric centre of each element, computed from the existing element
% connectivity without modifying the connectivity itself.
mesh.elementCenters = zeros(numElements, 2);
for e = 1:numElements
    elemNodes = elements(e, :);
    elemCoords = nodes(elemNodes, :);
    mesh.elementCenters(e, :) = mean(elemCoords, 1);
end

end
