function gauss = gauss_rule(order)
%GAUSS_RULE Generate 2D Gauss-Legendre quadrature rule for parent BFS element.
%
%   gauss = gauss_rule(order)
%
%   Purpose
%   -------
%   Generate the two-dimensional Gauss-Legendre quadrature rule for the
%   parent Bogner--Fox--Schmit (BFS) rectangular element over the domain
%
%       (-1 <= xi <= 1, -1 <= eta <= 1).
%
%   Requirements
%   ------------
%   1. Input order = 1, 2, 3, 4, or 5 representing an order x order
%      tensor-product Gauss quadrature.
%   2. Returns a structure with fields:
%          gauss.points    : [order^2 x 2] array [xi_q, eta_q]
%          gauss.weights   : [order^2 x 1] array of tensor-product weights
%          gauss.numPoints : total number of quadrature points
%          gauss.order     : quadrature order
%          gauss.xi        : [order^2 x 1] parent xi coordinates
%          gauss.eta       : [order^2 x 1] parent eta coordinates
%          gauss.domain    : domain description string
%          gauss.type      : quadrature type description string
%          gauss.dimension : spatial dimension, equal to 2
%          gauss.referenceElement : element geometry description string
%   3. Constructed via tensor products of exact 1D Gauss-Legendre rules.
%
%   Important
%   ---------
%   This routine defines ONLY the geometric parent-domain quadrature rule.
%   It does NOT evaluate shape functions, does NOT compute Jacobians, does
%   NOT assemble stiffness matrices, and does NOT perform numerical
%   integration.
%==========================================================================

%==========================================================================
% 1. Input checking and validation
%==========================================================================
if nargin ~= 1
    error('gauss_rule:InvalidInputCount', ...
          'gauss_rule requires exactly one input argument: order.');
end

if ~isnumeric(order) || ~isreal(order) || ~isscalar(order) || ~isfinite(order)
    error('gauss_rule:InvalidOrderType', ...
          'Input order must be a finite real scalar integer.');
end

if order ~= round(order) || order < 1 || order > 5
    error('gauss_rule:InvalidOrderValue', ...
          'Input order must be an integer: 1, 2, 3, 4, or 5.');
end

%==========================================================================
% 2. Obtain standard 1D Gauss-Legendre quadrature rule on [-1, 1]
%==========================================================================
[x1d, w1d] = gauss_legendre_1d(order);

% Ensure column vectors for clean tensor-product expansion.
x1d = x1d(:);
w1d = w1d(:);

%==========================================================================
% 3. Construct 2D tensor-product rule
%==========================================================================
% Note: The tensor-product quadrature ordering is arbitrary as long as
% points and weights remain consistent.
[XI, ETA] = ndgrid(x1d, x1d);
[WX, WY]  = ndgrid(w1d, w1d);

points  = [XI(:), ETA(:)];
weights = WX(:) .* WY(:);

numExpectedPoints = order^2;

%==========================================================================
% 4. Verification checks
%==========================================================================
% Check size(points) = [order^2 x 2]
if ~isequal(size(points), [numExpectedPoints, 2])
    error('gauss_rule:InvalidPointsSize', ...
          'Verification failed: points array must have size [%d x 2].', ...
          numExpectedPoints);
end

% Check size(weights) = [order^2 x 1]
if ~isequal(size(weights), [numExpectedPoints, 1])
    error('gauss_rule:InvalidWeightsSize', ...
          'Verification failed: weights array must have size [%d x 1].', ...
          numExpectedPoints);
end

% Check all weights > 0
if any(weights <= 0.0)
    error('gauss_rule:NonPositiveWeights', ...
          'Verification failed: all quadrature weights must be strictly positive.');
end

% Check all points lie inside [-1, 1]
domainTolerance = 1.0e-14;
if any(points(:) < -1.0 - domainTolerance) || any(points(:) > 1.0 + domainTolerance)
    error('gauss_rule:PointsOutsideDomain', ...
          'Verification failed: all quadrature points must lie within [-1, 1].');
end

% Check sum(weights) = 4 (within a tolerance of 1e-12)
weightSumError = abs(sum(weights) - 4.0);
if weightSumError > 1.0e-12
    error('gauss_rule:InvalidWeightSum', ...
          'Verification failed: sum(weights) differs from 4.0. Error = %.3e.', ...
          weightSumError);
end

%==========================================================================
% 5. Store output structure and metadata
%==========================================================================
gauss = struct();
gauss.points    = points;
gauss.weights   = weights;
gauss.numPoints = numExpectedPoints;
gauss.order     = order;

% Expose individual parent coordinate vectors.
gauss.xi  = points(:,1);
gauss.eta = points(:,2);

% Required metadata fields.
gauss.domain = '[-1,1] x [-1,1]';
gauss.type   = 'Tensor-product Gauss-Legendre quadrature';
gauss.dimension = 2;
gauss.referenceElement = 'Rectangle';

end


%==========================================================================
% Helper Subfunction: 1D Gauss-Legendre Rules
%==========================================================================
function [x, w] = gauss_legendre_1d(order)
%GAUSS_LEGENDRE_1D Return exact 1D Gauss-Legendre points and weights on [-1,1].

switch order
    case 1
        x = 0.0;
        w = 2.0;
        
    case 2
        pt = 1.0 / sqrt(3.0);
        x = [-pt; pt];
        w = [1.0; 1.0];
        
    case 3
        pt = sqrt(3.0 / 5.0);
        x = [-pt; 0.0; pt];
        w = [5.0/9.0; 8.0/9.0; 5.0/9.0];
        
    case 4
        pt1 = sqrt((3.0 - 2.0*sqrt(6.0/5.0)) / 7.0);
        pt2 = sqrt((3.0 + 2.0*sqrt(6.0/5.0)) / 7.0);
        wt1 = (18.0 + sqrt(30.0)) / 36.0;
        wt2 = (18.0 - sqrt(30.0)) / 36.0;
        x = [-pt2; -pt1; pt1; pt2];
        w = [wt2; wt1; wt1; wt2];
        
    case 5
        pt1 = (1.0 / 3.0) * sqrt(5.0 - 2.0*sqrt(10.0/7.0));
        pt2 = (1.0 / 3.0) * sqrt(5.0 + 2.0*sqrt(10.0/7.0));
        wt0 = 128.0 / 225.0;
        wt1 = (322.0 + 13.0*sqrt(70.0)) / 900.0;
        wt2 = (322.0 - 13.0*sqrt(70.0)) / 900.0;
        x = [-pt2; -pt1; 0.0; pt1; pt2];
        w = [wt2; wt1; wt0; wt1; wt2];
        
    otherwise
        error('gauss_legendre_1d:UnsupportedOrder', ...
              'Order %d is not supported.', order);
end

end
