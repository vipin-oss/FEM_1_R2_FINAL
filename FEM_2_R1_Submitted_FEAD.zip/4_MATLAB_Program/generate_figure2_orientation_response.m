%% generate_figure2_orientation_response.m
%=========================================================================%
%  Figure 2: Orientation-dependent displacement response
%  Proposed anisotropic ellipsoidal strain-gradient model
%=========================================================================%
%  Purpose:
%    Generates Figure 2 for the Results and Discussion section using the
%    proposed anisotropic ellipsoidal characteristic-length tensor.
%
%  Important:
%    This script does NOT modify the validation benchmark, validation code,
%    analytical solution, or validation discussion. It is a standalone
%    post-validation results script.
%
%  Parameter set:
%    Nx = Ny = 32
%    L = H = 1.0
%    U_top = 0.05
%    E = 1.0, nu = 0.30
%    AR = a1/a2 = 5
%    a2 = 0.10, a1 = AR*a2
%    alpha = 0, 15, 30, 45, 60, 90 degrees
%    4 x 4 Gauss integration
%=========================================================================%

clear;
clc;
close all;

fprintf('========================================================================\n');
fprintf(' Generating Figure 2: Orientation-dependent displacement response\n');
fprintf('========================================================================\n');

%% 1. Problem and material parameters

geometry.xMin = 0.0;
geometry.xMax = 1.0;
geometry.yMin = 0.0;
geometry.yMax = 1.0;
geometry.L = geometry.xMax - geometry.xMin;
geometry.H = geometry.yMax - geometry.yMin;

material.E = 1.0;
material.nu = 0.30;
material.model = 'isotropic_linear_elastic_reference';

U_top = 0.05;

%% 2. Mesh parameters

N = 32;
meshParams.Nx = N;
meshParams.Ny = N;
meshParams.elementType = 'BFS';
meshParams.nodesPerElement = 4;
meshParams.dofsPerNode = 8;
meshParams.dofsPerElement = 32;

mesh = mesh_generator(geometry, meshParams);
ndof = mesh.numDofs;

%% 3. Anisotropic ellipsoidal parameter set

AR = 5.0;
a2 = 0.10;
a1 = AR * a2;
alphaListDeg = [0, 15, 30, 45, 60, 90];
numCases = numel(alphaListDeg);

gaussOrder = 4;  % exact for bicubic BFS stiffness integrands under affine mapping

%% 4. Classical constitutive matrix

Cmat = constitutive_C(material);
C = Cmat.C;

%% 5. Storage arrays

yMidStore = [];
uMidStore = [];
vMidStore = [];
summary = zeros(numCases, 8);

%% 6. Loop over ellipsoid orientation angle

for ia = 1:numCases
    alphaDeg = alphaListDeg(ia);
    alpha = alphaDeg * pi / 180.0;

    fprintf('Solving alpha = %g deg ...\n', alphaDeg);

    %------------------------------------------------------------------
    % 6.1 Rotated ellipsoidal characteristic-length tensor
    %------------------------------------------------------------------
    g11 = (a1^2*cos(alpha)^2 + a2^2*sin(alpha)^2) / 5.0;
    g22 = (a1^2*sin(alpha)^2 + a2^2*cos(alpha)^2) / 5.0;
    g12 = ((a1^2 - a2^2)*sin(alpha)*cos(alpha)) / 5.0;
    g21 = g12;

    % Engineering strain-gradient ordering:
    % [eps_xx,x; eps_yy,x; gamma_xy,x; eps_xx,y; eps_yy,y; gamma_xy,y]
    Dmat = struct();
    Dmat.D = [g11*C, g12*C; ...
              g21*C, g22*C];
    Dmat.g2 = [g11, g12; g21, g22];
    Dmat.alphaDeg = alphaDeg;
    Dmat.AR = AR;
    Dmat.a1 = a1;
    Dmat.a2 = a2;
    Dmat.type = 'Anisotropic ellipsoidal engineering strain-gradient matrix';

    constitutive = struct();
    constitutive.C = Cmat;
    constitutive.D = Dmat;

    %------------------------------------------------------------------
    % 6.2 Assemble global stiffness matrix
    %------------------------------------------------------------------
    [K_global, F_global] = local_assemble_uniform_BFS(mesh, constitutive, gaussOrder);

    %------------------------------------------------------------------
    % 6.3 Apply simple-shear Dirichlet boundary conditions
    %------------------------------------------------------------------
    boundary = local_build_simple_shear_boundary(mesh, U_top);
    [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, mesh, boundary);

    %------------------------------------------------------------------
    % 6.4 Apply lateral periodic boundary conditions
    %------------------------------------------------------------------
    [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry);

    %------------------------------------------------------------------
    % 6.5 Solve system
    %------------------------------------------------------------------
    solution = solver(K_bc, F_bc, bc, mesh);
    solution.displacement(slaveDofs) = solution.displacement(masterDofs);
    d = solution.displacement;

    %------------------------------------------------------------------
    % 6.6 Extract mid-span vertical displacement profile
    %------------------------------------------------------------------
    [yMid, uMid, vMid] = local_extract_midline_profile(mesh, d, geometry);

    if ia == 1
        yMidStore = yMid(:);
        uMidStore = zeros(numel(yMid), numCases);
        vMidStore = zeros(numel(yMid), numCases);
    end

    uMidStore(:, ia) = uMid(:);
    vMidStore(:, ia) = vMid(:);

    summary(ia, :) = [alphaDeg, g11, g12, g22, sqrt(g22), ...
                      max(uMid/U_top), min(uMid/U_top), max(abs(vMid/U_top))];

    fprintf('  g11 = %.6e, g12 = %.6e, g22 = %.6e, sqrt(g22) = %.6e\n', ...
            g11, g12, g22, sqrt(g22));
    fprintf('  max |v|/U_top = %.3e\n\n', max(abs(vMid/U_top)));
end

%% 7. Print numerical summary to command window only
% No CSV/table files are written.  Only EPS and PNG figure files are exported.

fprintf('Numerical summary for Figure 2:\n');
fprintf(' alpha      g11              g12              g22              sqrt(g22)        max|v|/Utop\n');
for ia = 1:numCases
    fprintf('%6.1f  % .6e  % .6e  % .6e  % .6e  % .3e\n', ...
        summary(ia, 1), summary(ia, 2), summary(ia, 3), summary(ia, 4), ...
        summary(ia, 5), summary(ia, 8));
end
fprintf('\n');

%% 8. Plot Figure 2

fig = figure('Name', 'Figure 2 Orientation Response', 'NumberTitle', 'off');
hold on;

colors = [ ...
    0.0000, 0.0000, 0.0000; ...
    0.0000, 0.4470, 0.7410; ...
    0.0000, 0.6200, 0.4510; ...
    0.8500, 0.3250, 0.0980; ...
    0.8000, 0.4750, 0.6550; ...
    0.9290, 0.6940, 0.1250];

lineStyles = {'--', '-', '-', '-', '-', '-'};
legendHandles = gobjects(numCases, 1);
legendLabels = cell(numCases, 1);

for ia = 1:numCases
    alphaDeg = alphaListDeg(ia);
    legendHandles(ia) = plot(uMidStore(:, ia)/U_top, yMidStore/geometry.H, ...
        'LineStyle', lineStyles{ia}, ...
        'Color', colors(ia, :), ...
        'LineWidth', 2.0);
    legendLabels{ia} = sprintf('$\\alpha=%d^\\circ$', alphaDeg);
end

xlabel('Normalized horizontal displacement $u/U_{\mathrm{top}}$', 'Interpreter', 'latex');
ylabel('Normalized vertical coordinate $y/H$', 'Interpreter', 'latex');

lgd = legend(legendHandles, legendLabels, 'Interpreter', 'latex', 'Location', 'southeast');

local_apply_figure2_formatting(fig, gca, lgd);

%% 9. Export figure: EPS + PNG only

exportBaseName = 'Figure2_orientation_displacement_response';
scriptDir = fileparts(mfilename('fullpath'));
if isempty(scriptDir)
    scriptDir = pwd;
end

local_export_eps_png(fig, exportBaseName, scriptDir);

fprintf('========================================================================\n');
fprintf(' Figure 2 generated successfully.\n');
fprintf(' Only EPS and PNG files were exported.\n');
fprintf('========================================================================\n');

%=========================================================================%
% Local helper functions
%=========================================================================%

function [K_global, F_global] = local_assemble_uniform_BFS(mesh, constitutive, gaussOrder)
%LOCAL_ASSEMBLE_UNIFORM_BFS Assemble global stiffness for a structured uniform BFS mesh.
% The element stiffness is computed once and reused because mesh_generator()
% creates a uniform structured rectangular mesh with identical element sizes.

    numDofs = mesh.numDofs;
    numElements = mesh.numElements;

    % Compute representative element stiffness from the first element.
    elemNodes = mesh.elements(1, :);
    elementCoords = mesh.nodes(elemNodes, :);

    gauss = gauss_rule(gaussOrder);
    shape2D = bfs_tensor_product(gauss.xi, gauss.eta);
    jac = jacobian_bfs(elementCoords, shape2D);
    phys = physical_derivatives(shape2D, jac);
    Bmat = B_matrix(phys);
    Bgmat = Bg_matrix(phys);

    Ke = element_stiffness(Bmat, Bgmat, constitutive.C, constitutive.D, jac, gauss);
    KeTotal = Ke.total;

    % Sparse triplet assembly.
    nnzPerElement = 32 * 32;
    I = zeros(numElements * nnzPerElement, 1);
    J = zeros(numElements * nnzPerElement, 1);
    V = zeros(numElements * nnzPerElement, 1);

    cursor = 0;
    for e = 1:numElements
        elemNodes = mesh.elements(e, :);
        edofs = reshape(mesh.dofMap(elemNodes, :).', 32, 1);

        [II, JJ] = ndgrid(edofs, edofs);
        idx = cursor + (1:nnzPerElement);
        I(idx) = II(:);
        J(idx) = JJ(:);
        V(idx) = KeTotal(:);
        cursor = cursor + nnzPerElement;
    end

    K_global = sparse(I, J, V, numDofs, numDofs);
    F_global = zeros(numDofs, 1);
end

function boundary = local_build_simple_shear_boundary(mesh, U_top)
%LOCAL_BUILD_SIMPLE_SHEAR_BOUNDARY Build Case-1-style simple-shear essential BCs.

    bottomDofs = mesh.bottomDofs(:);
    topDofs = mesh.topDofs(:);

    numBottomNodes = numel(bottomDofs) / 8;
    numTopNodes = numel(topDofs) / 8;

    bottomFixIndices = [];
    for nb = 1:numBottomNodes
        bottomFixIndices = [bottomFixIndices, 8*(nb-1) + [1, 2, 5, 6]]; %#ok<AGROW>
    end
    fixedBottomDofs = bottomDofs(bottomFixIndices);
    bottomVals = zeros(numel(fixedBottomDofs), 1);

    topFixIndices = [];
    for nt = 1:numTopNodes
        topFixIndices = [topFixIndices, 8*(nt-1) + [1, 2, 3, 4, 5, 6]]; %#ok<AGROW>
    end
    fixedTopDofs = topDofs(topFixIndices);
    topVals = zeros(numel(fixedTopDofs), 1);

    % The first fixed DOF in each top-node block is u.
    uTopIndices = 1:6:numel(fixedTopDofs);
    topVals(uTopIndices) = U_top;

    boundary = struct();
    boundary.fixedDofs = [fixedBottomDofs(:); fixedTopDofs(:)];
    boundary.values = [bottomVals(:); topVals(:)];
end

function [K_bc, F_bc, masterDofs, slaveDofs] = local_apply_periodic_lr(K_bc, F_bc, mesh, boundary, geometry)
%LOCAL_APPLY_PERIODIC_LR Enforce left-right periodicity by master-slave elimination.

    xTol = 1.0e-7 * geometry.L;

    leftNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMin) <= xTol);
    rightNodeIndices = find(abs(mesh.nodes(:, 1) - geometry.xMax) <= xTol);

    [~, sortLeft] = sort(mesh.nodes(leftNodeIndices, 2));
    leftNodeIndices = leftNodeIndices(sortLeft);

    [~, sortRight] = sort(mesh.nodes(rightNodeIndices, 2));
    rightNodeIndices = rightNodeIndices(sortRight);

    masterDofs = [];
    slaveDofs = [];

    for k = 1:numel(leftNodeIndices)
        nodeL = leftNodeIndices(k);
        nodeR = rightNodeIndices(k);

        for c = 1:8
            dofL = mesh.dofMap(nodeL, c);
            dofR = mesh.dofMap(nodeR, c);

            if ~ismember(dofL, boundary.fixedDofs) && ~ismember(dofR, boundary.fixedDofs)
                if ~ismember(dofR, slaveDofs) && ~ismember(dofL, masterDofs) && (dofL ~= dofR)
                    masterDofs = [masterDofs; dofL]; %#ok<AGROW>
                    slaveDofs = [slaveDofs; dofR]; %#ok<AGROW>
                end
            end
        end
    end

    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(m, :) = K_bc(m, :) + K_bc(s, :);
        F_bc(m) = F_bc(m) + F_bc(s);
    end

    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        m = masterDofs(idx);
        K_bc(:, m) = K_bc(:, m) + K_bc(:, s);
    end

    for idx = 1:numel(slaveDofs)
        s = slaveDofs(idx);
        K_bc(s, :) = 0.0;
        K_bc(:, s) = 0.0;
        K_bc(s, s) = 1.0;
        F_bc(s) = 0.0;
    end
end

function [yMid, uMid, vMid] = local_extract_midline_profile(mesh, d, geometry)
%LOCAL_EXTRACT_MIDLINE_PROFILE Extract u and v along x=L/2.

    xMid = 0.5 * (geometry.xMin + geometry.xMax);
    xTol = 1.0e-7 * geometry.L;

    midNodeIndices = find(abs(mesh.nodes(:, 1) - xMid) <= xTol);

    if isempty(midNodeIndices)
        [~, closest] = min(abs(mesh.nodes(:, 1) - xMid));
        xClosest = mesh.nodes(closest, 1);
        midNodeIndices = find(abs(mesh.nodes(:, 1) - xClosest) <= xTol);
    end

    [yMid, sortIdx] = sort(mesh.nodes(midNodeIndices, 2));
    midNodeIndices = midNodeIndices(sortIdx);

    uMid = d(mesh.dofMap(midNodeIndices, 1));
    vMid = d(mesh.dofMap(midNodeIndices, 5));
end

function local_apply_figure2_formatting(fig, ax, lgd)
%LOCAL_APPLY_FIGURE2_FORMATTING Apply the same SCI style used in the validation script.

    set(fig, 'Color', 'w', 'Units', 'centimeters');
    fig.Position = [1 1 16 12];

    if ~isempty(ax) && isvalid(ax)
        ax.FontName   = 'Times New Roman';
        ax.FontSize   = 9;
        ax.FontWeight = 'normal';
        ax.Box        = 'on';
        ax.LineWidth  = 0.8;
        ax.TickDir    = 'out';
        ax.XLim(1)    = 0.0;
        ax.YLim       = [0.0, 1.0];

        grid(ax, 'on');
        grid(ax, 'minor');
        ax.GridLineStyle = '-';
        ax.MinorGridLineStyle = ':';
        ax.GridAlpha = 0.20;
        ax.MinorGridAlpha = 0.10;

        if ~isempty(ax.XLabel)
            ax.XLabel.Interpreter = 'latex';
            ax.XLabel.FontSize    = 10;
            ax.XLabel.FontWeight  = 'normal';
            ax.XLabel.FontName    = 'Times New Roman';
        end

        if ~isempty(ax.YLabel)
            ax.YLabel.Interpreter = 'latex';
            ax.YLabel.FontSize    = 10;
            ax.YLabel.FontWeight  = 'normal';
            ax.YLabel.FontName    = 'Times New Roman';
        end

        if ~isempty(ax.Title)
            ax.Title.String = '';
        end
    end

    if ~isempty(lgd) && isvalid(lgd)
        lgd.Interpreter = 'latex';
        lgd.FontName    = 'Times New Roman';
        lgd.FontSize    = 8;
        lgd.NumColumns  = 1;
        lgd.Box         = 'off';
    end

    drawnow;
end

function local_export_eps_png(fig, exportBaseName, preferredDir)
%LOCAL_EXPORT_EPS_PNG Export EPS and PNG robustly using validation-script style.
% First tries the script directory. If that is not writable, falls back to tempdir.

    epsName = [exportBaseName, '.eps'];
    pngName = [exportBaseName, '.png'];

    if nargin < 3 || isempty(preferredDir)
        preferredDir = pwd;
    end

    fprintf('Exporting %s (EPS + PNG via print)...\n', exportBaseName);

    try
        if ~exist(preferredDir, 'dir')
            mkdir(preferredDir);
        end

        pEps = fullfile(preferredDir, epsName);
        pPng = fullfile(preferredDir, pngName);

        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');

        fprintf('  -> Successfully saved:\n');
        fprintf('     1. Vector EPS : %s\n', pEps);
        fprintf('     2. 600 DPI PNG: %s\n', pPng);

    catch
        saveDir = fullfile(tempdir, 'SCI_Figures');
        if ~exist(saveDir, 'dir')
            mkdir(saveDir);
        end

        pEps = fullfile(saveDir, epsName);
        pPng = fullfile(saveDir, pngName);

        print(fig, pEps, '-depsc');
        print(fig, pPng, '-dpng', '-r600');

        fprintf('  -> Preferred folder was not writable. Saved to writable directory:\n');
        fprintf('     1. Vector EPS : %s\n', pEps);
        fprintf('     2. 600 DPI PNG: %s\n', pPng);
    end
end
