function [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, mesh, boundary)
%APPLY_BOUNDARY_CONDITIONS Apply Dirichlet boundary conditions to BFS mesh.
%
%   [K_bc, F_bc, bc] = apply_boundary_conditions(K_global, F_global, mesh, boundary)
%
%   Purpose
%   -------
%   Apply essential (Dirichlet) boundary conditions to the global stiffness
%   matrix and external force vector for the plane-strain strain-gradient
%   Bogner--Fox--Schmit (BFS) finite element solver.
%
%   Enforces prescribed nodal degrees of freedom using the classical
%   symmetric elimination (row-column modification) method. This approach
%   retains the original matrix dimensions and exact global symmetry while
%   supporting arbitrary non-zero prescribed displacement values.
%
%   Inputs
%   ------
%   K_global : [numDofs x numDofs] assembled sparse global stiffness matrix
%   F_global : [numDofs x 1] assembled global external force vector
%   mesh     : finite element mesh structure from mesh_generator()
%   boundary : structure defining prescribed Dirichlet constraints:
%                  boundary.fixedDofs : [nConstrained x 1] global DOF indices
%                  boundary.values    : [nConstrained x 1] prescribed values
%
%   Outputs
%   -------
%   K_bc : [numDofs x numDofs] modified symmetric sparse stiffness matrix
%   F_bc : [numDofs x 1] modified global force vector
%   bc   : structure containing diagnostic metadata and constraint statistics
%
%   Finalized BFS Nodal DOF Ordering
%   --------------------------------
%   At every node A, the 8 kinematic degrees of freedom are ordered as:
%       1: u      (horizontal displacement)
%       2: ux     (du/dx)
%       3: uy     (du/dy)
%       4: uxy    (d2u/dxdy)
%       5: v      (vertical displacement)
%       6: vx     (dv/dx)
%       7: vy     (dv/dy)
%       8: vxy    (d2v/dxdy)
%
%   Important
%   ---------
%   This routine strictly implements the classical elimination method.
%   It does NOT implement penalty methods, does NOT implement Lagrange
%   multipliers, and does NOT modify element-level kernel routines.
%==========================================================================

%==========================================================================
% 1. Input argument validation and structure verification
%==========================================================================
if nargin < 4
    error('apply_boundary_conditions:InvalidInputCount', ...
          'apply_boundary_conditions requires exactly 4 input arguments: K_global, F_global, mesh, boundary.');
end

if ~isstruct(mesh) || ~isfield(mesh, 'numDofs')
    error('apply_boundary_conditions:InvalidMeshStruct', ...
          'Input mesh must be a structure containing field .numDofs.');
end

if ~isstruct(boundary)
    error('apply_boundary_conditions:InvalidBoundaryStruct', ...
          'Input boundary must be a structure.');
end

if ~isfield(boundary, 'fixedDofs') || ~isfield(boundary, 'values')
    error('apply_boundary_conditions:MissingBoundaryFields', ...
          'boundary.fixedDofs and boundary.values are required fields.');
end

numGlobalDofs = mesh.numDofs;
if ~isequal(size(K_global), [numGlobalDofs, numGlobalDofs])
    error('apply_boundary_conditions:InvalidGlobalStiffnessSize', ...
          'K_global dimensions [%d x %d] do not match mesh.numDofs (%d).', ...
          size(K_global,1), size(K_global,2), numGlobalDofs);
end

if ~isequal(size(F_global), [numGlobalDofs, 1])
    error('apply_boundary_conditions:InvalidGlobalForceSize', ...
          'F_global dimensions [%d x %d] do not match mesh.numDofs (%d).', ...
          size(F_global,1), size(F_global,2), numGlobalDofs);
end

fixedDofs = boundary.fixedDofs(:);
values    = boundary.values(:);

if ~isnumeric(fixedDofs) || ~isnumeric(values)
    error('apply_boundary_conditions:NonNumericBoundaryData', ...
          'boundary.fixedDofs and boundary.values must be numeric vectors.');
end

if numel(fixedDofs) ~= numel(values)
    error('apply_boundary_conditions:LengthMismatch', ...
          'Verification failed: boundary.fixedDofs length (%d) must match boundary.values length (%d).', ...
          numel(fixedDofs), numel(values));
end

if any(~isfinite(values))
    error('apply_boundary_conditions:NonFiniteBoundaryValues', ...
          'Verification failed: all prescribed boundary displacement values must be finite.');
end

% Verify indices are valid integers within global matrix bounds.
if any(fixedDofs < 1) || any(fixedDofs > numGlobalDofs) || any(fixedDofs ~= round(fixedDofs))
    error('apply_boundary_conditions:InvalidDofIndices', ...
          'Verification failed: boundary.fixedDofs contains invalid integer indices outside [1, %d].', ...
          numGlobalDofs);
end

% Verify no duplicate constrained DOFs exist.
if numel(unique(fixedDofs)) ~= numel(fixedDofs)
    error('apply_boundary_conditions:DuplicateConstrainedDofs', ...
          'Verification failed: boundary.fixedDofs contains duplicate degree-of-freedom indices.');
end

%==========================================================================
% 2. Essential boundary condition enforcement via classical elimination
%==========================================================================
numConstrained = numel(fixedDofs);
numFree        = numGlobalDofs - numConstrained;

% Form full global prescribed displacement vector.
d_prescribed = zeros(numGlobalDofs, 1);
d_prescribed(fixedDofs) = values;

% 1. Modify right-hand side external force vector to account for coupling
%    forces exerted by prescribed displacement values on free DOFs.
F_bc = F_global - K_global * d_prescribed;

% Replace constrained force entries directly with their prescribed values.
F_bc(fixedDofs) = values;

% 2. Modify global stiffness matrix symmetrically.
%    Zero out constrained rows and columns to decouple fixed DOFs.
K_bc = K_global;
K_bc(fixedDofs, :) = 0.0;
K_bc(:, fixedDofs) = 0.0;

% Place ones on the diagonal of constrained DOFs so that the uncoupled
% equations strictly reduce to: 1.0 * d_i = prescribed_value.
K_bc = K_bc + sparse(fixedDofs, fixedDofs, 1.0, numGlobalDofs, numGlobalDofs);

%==========================================================================
% 3. Post-modification numerical and symmetry verification
%==========================================================================
if any(~isfinite(nonzeros(K_bc))) || any(~isfinite(F_bc))
    error('apply_boundary_conditions:NonFiniteOutput', ...
          'Verification failed: modified system K_bc or F_bc contains non-finite entries.');
end

symTol = 1.0e-9;
symErr = max(max(abs(K_bc - K_bc.')));
if symErr > symTol
    error('apply_boundary_conditions:NonSymmetricModifiedMatrix', ...
          'Verification failed: K_bc symmetry check violated after elimination. Error = %.3e.', ...
          symErr);
end

%==========================================================================
% 4. Store diagnostic metadata structure
%==========================================================================
bc = struct();
bc.numConstrained = numConstrained;
bc.numFree        = numFree;
bc.method         = 'Classical elimination (row-column modification)';
bc.description    = 'Symmetric Dirichlet boundary condition enforcement for BFS strain-gradient elasticity';

end
