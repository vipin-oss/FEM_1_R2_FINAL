# Cross-check of manuscript vs authors' MATLAB code (Program.zip) and stored EPS figures

Verified (code run in Octave / closed form): Fig.6 peaks (N=16), Table 1 (l=0.1,0.2,0.3; N=4..32), a2=0.1, mesh per figure
(Fig2-5 N=32, Fig6 N=16, Fig7 N=24, Fig9-11 N=16), BCs, delta algorithm (1% of max|tau|), energy fractions (2.3/7.7/14.4/34.9 %).

delta/H: current code gives min 0.2003 (AR=1), max 0.9794; contour levels 0.3561, 0.5509, 0.7457, 0.8859.
Fig. 9/10 EPS colorbars start at ~0.2, i.e. figures agree with the code. The submitted TEXT (0.1534; 0.3168/0.5230/0.8776)
was stale and is corrected in R1 (tracked in blue).
Stored EPS variants (newer Fig03, Fig10-polar; Fig10_EnergyPartitionSpectrum; Figure2_orientation...) were NOT used:
newer Fig03 has legend overlapping curves, newer polar Fig10 clips the 'Gradient-dominated' label; the others are older versions.
