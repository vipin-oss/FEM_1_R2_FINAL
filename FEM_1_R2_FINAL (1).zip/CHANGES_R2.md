# CHANGES_R2 — Revision 2 change log

Manuscript: **Finite Element Analysis of Second-Order Strain-Gradient Elasticity with Ellipsoidal Nonlocal Characteristic Lengths**  
Journal: *Finite Elements in Analysis and Design*, ID `FINEL-D-26-00567`

Base file: `final_R1_unmarked.tex` (Revision 1, clean).  
Delivered: `final_R2.tex` (Revision-2 changes in **red**, macro `\revtwo{}`) and `final_R2_unmarked.tex` (identical text, no colour).

Scope: **Reviewer 3, Revision-1 points 1 and 2 only.** Nothing was changed for Reviewer 1 or Reviewer 2. No numerical result, equation, figure, table entry or reference outside the edits listed below was altered, and no new computation was performed.

---

## 0. Verification summary

`verify_all.py` runs 42 automated checks. All pass.

| Check | Result |
|---|---|
| final_R1_unmarked.tex identical to the submitted original | PASS |
| final_R2.tex minus \revtwo markup == final_R2_unmarked.tex | PASS |
| removing all 13 R2 edits reproduces final_R1_unmarked.tex byte-for-byte | PASS |
| diff R1 -> R2_unmarked has exactly 14 change hunks | PASS — (got 14) |
| no Revision-1 text wrapped in \revtwo{} | PASS — (13 blocks) |
| Revision-1 blue macro \rev{} untouched and unused | PASS |
| every \cite key resolves in references_R2.bib | PASS — 54 cited / 58 available; unresolved: none |
| every \ref/\eqref target is labelled | PASS — unresolved: none |
| references_R2.bib = references_R1.bib + 3 appended entries | PASS |
| bibliography count 55 -> 58 | PASS |
| the 3 new keys are present and cited | PASS |
| Rauter & Lammering recorded as volume 62 (Crossref-verified) | PASS |
| final_R2.tex produced a PDF | PASS — 1212 KiB |
| final_R2_unmarked.tex produced a PDF | PASS — 1212 KiB |
| Response_to_Reviewer3_R2.tex produced a PDF | PASS — 88 KiB |
| final_R2: no undefined reference/citation | PASS |
| final_R2: no LaTeX error | PASS |
| final_R2: only the pre-existing duplicate-label warning remains | PASS |
| final_R2_unmarked: no undefined reference/citation | PASS |
| final_R2_unmarked: no LaTeX error | PASS |
| final_R2_unmarked: only the pre-existing duplicate-label warning remains | PASS |
| Response letter: no undefined reference/citation | PASS |
| no "??" anywhere in the compiled manuscript | PASS |
| Table B.3 numbered B.3 (unchanged from Revision 1) | PASS |
| rendered: ansatz statement | PASS |
| rendered: correlation-length definition | PASS |
| rendered: do-not-overstate caveat | PASS |
| rendered: future work | PASS |
| rendered: Table B.3 forward ref | PASS |
| rendered: h_x/a ratios | PASS |
| rendered: bounds but does not eliminate | PASS |
| rendered: C1 vs C0 statement | PASS |
| rendered: no fully-resolved claim | PASS |
| rendered: l_x/L_x = 1 caveat | PASS |
| rendered: step 7 | PASS |
| rendered: not experimentally validated | PASS |
| rendered: App B table intro | PASS |
| rendered: new table column value | PASS |
| all 12 figure files byte-identical to the submitted originals | PASS |
| highlights.tex byte-identical to the submitted original | PASS |
| Response_to_Reviewers.tex (R1 letter) left in place and unmodified | PASS |
| every new numeric token is re-derived from Revision-1 data | PASS — 7 new tokens, all accounted for |

**42/42 checks passed.**

### Colour marking in `final_R2.tex`

`\revtwo{}` uses `RGB(200,0,0)`, which the PDF writer emits as the operator `0.784 0 0 rg`.
Scanning every content stream of the compiled `final_R2.pdf` for that operator shows red text on
exactly these pages:

    3   (E13 broken-reference fix, Introduction contributions list)
    5-6 (E1  Sec. 2.1 — two new paragraphs; the second flows onto p. 6)
    17  (E2  Sec. 5.4 — Table B.3 pointer)
    18  (E3, E4  Sec. 5.5 — Table B.3 forward reference and resolution statement)
    28  (E5  Sec. 6.4 — qualification of the coarse-grid claim)
    34  (E6  Sec. 6.6 — l_x/L_x = 1 validity pointer)
    37-38 (E7 step 7, E8 limitation bullet; E8 flows onto p. 38)
    40  (E9 Appendix B introduction, E10 Table B.3 columns, E11 caption clause)

38 red text runs in total, and **no red anywhere else** — so no Revision-1 text has been marked.
`final_R1_unmarked.tex` contains no `\rev{}` calls, and the Revision-1 blue macro is untouched.

### How the compile check was performed (please read)

Tectonic (the XeTeX-based engine available here) cannot embed PostScript, and the manuscript
references its figures with explicit `.eps` extensions, so a straight compile of the delivered
files fails at the *image-embedding* stage — not at the LaTeX stage. There is no Ghostscript in
this sandbox to run `epstopdf`.

To still verify the LaTeX properly, `verify_compile.py` builds a **scratch copy** in
`/home/user/build_check/` in which each `\includegraphics{X.eps}` is redirected to a generated
blank placeholder PDF of the same aspect placeholder size. Everything else — preamble, text,
labels, citations, table and equation numbering, page breaks — is untouched.

**The delivered `final_R2.tex` and `final_R2_unmarked.tex` keep the original `.eps` filenames**
and are not modified by the harness. They will compile normally in the journal's
`latex → dvips → ps2pdf` (or `epstopdf`) workflow, exactly as `final_R1.tex` did.

Two consequences you should know about:

* **Page numbers quoted in `Response_to_Reviewer3_R2.tex` are from this placeholder build.**
  Section, subsection, equation and table numbers are exact and will not change. Page numbers
  may shift by a page or two once the real EPS figures are embedded, because the placeholders do
  not have the same heights as your figures. Worth a quick eyeball after you compile locally —
  the locations are: Sec. 2.1 p. 5, Sec. 5.4 p. 17, Sec. 5.5 p. 18, Sec. 6.4 p. 28,
  Sec. 6.6 p. 34, Sec. 7.1/7.2 p. 37, Appendix B / Table B.3 p. 40.
* The preview PDFs in `_PREVIEW_placeholder_figures_DO_NOT_SUBMIT/` show the red Revision-2
  marking correctly but have **blank boxes where your figures belong**. Do not submit them.

---

## 1. Every change, before → after

### E1 — R3 Point 1

**Location:** Sec. 2.1 “Nonlocal Strain Averaging”  
**Type:** insertion (2 new paragraphs)  
**Anchor:** immediately after “…$QAA^TQ^T$, where $Q$ is an orthogonal rotation tensor.”

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
A caution is needed regarding the physical status of the
ellipsoidal neighbourhood. The second-moment construction guarantees
that an axis-aligned or rotated ellipsoid yields an anisotropic tensor
$L_{mn}$, but that is a geometric statement about the averaging domain
chosen here; it is not evidence that a given real microstructure
possesses an anisotropic interaction domain. The features usually
invoked in this connection --- aligned fibres, elongated or drawn
grains, oriented lattice struts --- are well documented to produce
anisotropic macroscopic response, and anisotropic response is a weaker
statement than anisotropic interaction. The ellipsoidal kernel adopted
in Eq.~\eqref{eq:ellipsoid_domain} should therefore be read as a
modelling ansatz: a parsimonious geometric parameterisation that admits
direction-dependent interaction ranges and that collapses to the usual
isotropic gradient model when $l_1=l_2=l_3$.

The ansatz is nevertheless testable, because an interaction
range is an operationally well-defined quantity in its own right. In a
weakly nonlocal description the neighbourhood over which the state at
$\mathbf{x}$ is influenced by the state at $\mathbf{x}+\boldsymbol{\xi}$
plays the role of a correlation length of a local field measured between
material points, so it can be estimated from microstructural images
without reference to any stiffness measurement, and it can be resolved
along and across a preferred material direction. Micro-computed
tomography reconstructions of fibre paths in fibre-reinforced polymers
have been used in exactly this way: microstructural descriptors are
correlated as a function of separation distance and the distance over
which that correlation decays defines a length scale of the
microstructure, the three-dimensional reconstruction allowing the
analysis to be performed along and across the fibres rather than on
two-dimensional sections alone \cite{Schey2019,ScheyStapleton2022}. In a
related but distinct setting, the elasticity tensor of short
fibre-reinforced composites has been shown to possess an anisotropic
spatial correlation structure whose correlation functions differ between
directions and reflect the overall transversely isotropic material
behaviour \cite{RauterLammering2020}. These studies measure the spatial
correlation of microstructural or material-property fields; they do not
measure a strain-averaging kernel, and they do not establish the
particular ellipsoidal form of $\mathcal{V}$ or the coefficient $1/10$
used here. What they do show is that direction-resolved correlation
lengths are measurable properties of real heterogeneous media, so that
an anisotropic $L_{mn}$ is not purely a mathematical artefact of the
averaging geometry. A direct experimental determination of the
interaction-level anisotropy postulated in Eq.~\eqref{eq:ellipsoid_domain},
as opposed to an inference from macroscopic response, is not attempted in
the present work and remains essential future work; the measurement
route is outlined as step~7 of the calibration protocol in
Sec.~\ref{sec:exp_calib}.
```

**Why:** States that the ellipsoidal kernel is a modelling ansatz; defines the nonlocal interaction range operationally as a direction-resolved correlation length of a local field between material points, measurable independently of stiffness; adds the three new citations `Schey2019`, `ScheyStapleton2022`, `RauterLammering2020`; states explicitly that those studies do **not** measure a strain-averaging kernel and do not validate the ellipsoidal form or the coefficient $1/10$; declares direct interaction-level determination essential future work and points to step 7 of Sec. 7.1.

---

### E2 — R3 Point 2(a)

**Location:** Sec. 5.4 “Three-Dimensional Tricubic Hermite Brick Element”  
**Type:** insertion (1 sentence)  
**Anchor:** at the end of the subsection, after the consistent-mass equation `eq:3d_hermite_mass`

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
The mesh density adopted for the three-dimensional computations,
together with its sensitivity, is quantified in
Table~\ref{tab:mesh3D} (\ref{app:energy}).
```

**Why:** Embeds Table B.3 in the text. `\ref{tab:mesh3D}` → **B.3**, `\ref{app:energy}` → **Appendix B**.

---

### E3 — R3 Point 2(a)

**Location:** Sec. 5.5 “Implementation Remarks”  
**Type:** insertion (1 sentence)  
**Anchor:** immediately **before** “Real output from `mesh_sensitivity_3D.m` shows displacement increasing…”

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
Full results for all three meshes are reported in
Table~\ref{tab:mesh3D} (\ref{app:energy}).
```

**Why:** Placed exactly where requested, i.e. before the sentence quoting the solver output.

---

### E4 — R3 Point 2(b)

**Location:** Sec. 5.5 “Implementation Remarks”  
**Type:** insertion (1 passage)  
**Anchor:** immediately after “…consistent with a conforming over-stiff formulation.” and before “A fourth-order rate is expected only when…”

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
 Expressed as a resolution ratio, the three meshes give
$h_{x}/a=31.6$, $15.8$ and $10.5$ for $2\times1\times1$, $4\times2\times2$
and $6\times3\times3$ respectively, so none of them reaches the
$h_{x}\ll a$ regime. The monotonic trend and the $5.9\%$ and $9.3\%$
spreads therefore bound the discretisation error associated with the
boundary layer, but they do not eliminate it. The $4\times2\times2$ mesh
used throughout Sec.~\ref{sec:numerical_results} differs from the finest
mesh tested by about $1.0\%$ in displacement and $2.1\%$ in frequency,
and because the trend has not saturated these figures are lower bounds on
the error remaining at that density. The element choice partially offsets
the coarse resolution: since the tricubic Hermite element carries slope
and curvature degrees of freedom, it can represent the exponential decay
$\theta(x)\propto1-e^{-x/a}$ within a single element, whereas a $C^{0}$
element of the same size can reproduce that profile only piecewise
linearly. That is a relative advantage at a given $h_{x}/a$, not a
substitute for resolving the layer, and the boundary layer is not claimed
to be fully resolved at any of the three densities.
```

**Why:** Reports the boundary-layer resolution honestly. `h_x/a` = 31.6 / 15.8 / 10.5 for the three meshes; states that none reaches `h_x << a`, that the study **bounds but does not eliminate** the discretisation error, that the C¹ tricubic Hermite element represents the exponential layer better than a C⁰ element at the same `h_x/a`, and that the layer is **not** claimed to be fully resolved. The 1.0 % / 2.1 % figures are arithmetic on the existing Table B.3 rows: `(4.8371-4.7876)/4.8371 = 1.02 %`, `(178.72-174.96)/174.96 = 2.15 %`. No new data.

---

### E5 — R3 Point 2(b)

**Location:** Sec. 6.4 “Three-Dimensional Tricubic Hermite Formulation”  
**Type:** insertion (1 sentence, appended to an existing sentence which is left word-for-word intact)  
**Anchor:** after “…while still being fine enough to capture the physics.”

**Before**
```latex
The relatively coarse $4\times2\times2$ grid used here accounts for the
much greater computational expense of the three-dimensional approach while
still being fine enough to capture the physics.
```

**After**
```latex
The relatively coarse $4\times2\times2$ grid used here accounts for the
much greater computational expense of the three-dimensional approach while
still being fine enough to capture the physics.  This applies to the global static and dynamic response and
should not be read as a claim that the near-boundary strain-gradient
layer is fully resolved: for $l=0.05$\,m the layer thickness is
$a=\sqrt{l^{2}/10}=0.0158$\,m, so the $4\times2\times2$ grid corresponds
to $h_{x}/a\approx15.8$. The mesh-sensitivity study summarised in
Table~\ref{tab:mesh3D} and discussed in
Sec.~\ref{subsec:fem_implementation_remarks} quantifies the resulting
discretisation error.
```

**Why:** The pre-existing claim is now qualified: it applies to the global static and dynamic response, not to the near-boundary layer. No original wording was deleted.

---

### E6 — R3 Point 2(c)

**Location:** Sec. 6.6 “Anisotropic Design-Space Exploration”  
**Type:** insertion (1 sentence)  
**Anchor:** after “…is 400 times larger than the transverse one $l_{y}^{2} = 0.0025$\,m$^{2}$.”

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
This corner corresponds to $l_{x}/L_{x}=1$, well outside the
weakly nonlocal regime in which the second-order Taylor expansion of
Sec.~2.1 is derived; as noted in
Sec.~\ref{sec:calibration}, cases with $l/L>0.10$ are parametric
sensitivity studies that map the trend of the model rather than
physically admissible configurations, and the integral form of the
averaging operator, not its gradient approximation, should be used
there.
```

**Why:** Points to the statement already present in Sec. 7 that `l/L > 0.10` cases are parametric sensitivity studies outside the strict validity of the Taylor expansion, and that the integral form of the averaging operator should be used there. **No result, number or figure was changed.**

---

### E7 — R3 Point 1

**Location:** Sec. 7.1 “Experimental calibration of characteristic lengths”  
**Type:** insertion (new list item 7)  
**Anchor:** after item 6 “…Report $l_i\pm \delta l_i$ from least-squares covariance.”, before `\end{enumerate}`

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
  \item \textbf{Interaction-level verification:} Steps 1--6 infer
  $l_{x},l_{y},l_{z}$ from macroscopic response, so they cannot by
  themselves distinguish an anisotropic interaction domain from an
  anisotropic constitutive response. An independent check should
  therefore be made at the microstructural level. The microstructure is
  reconstructed by micro-computed tomography, a local field is extracted
  from it (fibre path geometry, local orientation, or a local elasticity
  estimate from resolved representative volume elements), and the
  two-point correlation of that field is computed as a function of the
  separation vector $\boldsymbol{\xi}$, resolved along and across the
  principal material directions. The decay lengths of these
  direction-resolved correlations provide estimates of $l_{1},l_{2},l_{3}$
  that involve no stiffness measurement, and they can then be compared
  with the values inferred in steps 1--6. Agreement between the two would
  support the interaction-level interpretation of $L_{mn}$ adopted in
  Sec.~2.1, whereas disagreement would
  indicate that the ellipsoidal kernel does not adequately represent the
  true interaction domain. This comparison has not been carried out here,
  and a direct interaction-level calibration of $L_{mn}$ remains essential
  future work.
```

**Why:** New **step 7 “Interaction-level verification”**: micro-CT reconstruction, extraction of a local field, two-point correlation versus the separation vector resolved along and across the principal material directions, giving `l1, l2, l3` with no stiffness measurement; to be compared against the values inferred in steps 1–6. States that this comparison has **not** been carried out and that direct interaction-level calibration of `L_mn` remains essential future work.

---

### E8 — R3 Point 1

**Location:** Sec. 7.2 “Limitations of present framework”  
**Type:** insertion (new bullet)  
**Anchor:** after the last existing bullet “…which would require a separate solver.”, before `\end{itemize}`

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
  \item The anisotropy of the interaction domain is a modelling
  assumption rather than an established experimental fact. Aligned fibres,
  elongated grains and oriented lattice struts evidence anisotropic
  response, not anisotropic interaction, and neither the present work nor
  the literature cited here measures the strain-averaging kernel directly.
  The ellipsoidal form of $\mathcal{V}$ and the coefficient $1/10$ are
  therefore not experimentally validated; step~7 of
  Sec.~\ref{sec:exp_calib} outlines how they could be tested.
```

**Why:** Makes the status of the assumption explicit: the ellipsoidal form of `V` and the coefficient `1/10` are **not experimentally validated**.

---

### E9 — R3 Point 2(a)

**Location:** Appendix B “Energy breakdown and DSI definition”  
**Type:** insertion (1 sentence at the start of the appendix)  
**Anchor:** immediately after `\label{app:energy}`, before “Total strain energy $U=U_{cl}+U_{g}$…”

**Before**
```latex
*(nothing — pure insertion)*
```

**After**
```latex
Table~\ref{tab:mesh3D} at the end of this appendix collects the
three-dimensional mesh-sensitivity results referred to in
Sec.~\ref{subsec:three_dimensional_hermite_element},
Sec.~\ref{subsec:fem_implementation_remarks}; for each of the three grids it
reports the mesh density, the number of degrees of freedom, the element
size $h_{x}$, the boundary-layer resolution ratio $h_{x}/a$, the mean
right-face displacement and the fundamental frequency.
```

**Why:** Introduces Table B.3 and lists what each of its columns contains.

---

### E10 — R3 Point 2(b)

**Location:** Appendix B, Table B.3 (`tab:mesh3D`)  
**Type:** table body: 2 columns added, 4 → 6  
**Anchor:** the `tabular` environment of Table B.3

**Before**
```latex
\begin{tabular}{cccc}
\hline
Mesh & DOF (=nodes$\times$24) & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 4.8371 & 174.96 \\
\hline
\end{tabular}
```

**After**
```latex
\begin{tabular}{cccccc}
\hline
Mesh & DOF (=nodes$\times$24) & $h_x$ (m) & $h_x/a$ & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 0.500 & 31.6 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 0.250 & 15.8 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 0.167 & 10.5 & 4.8371 & 174.96 \\
\hline
\end{tabular}
```

**Why:** Adds `h_x` (m) and `h_x/a`. `h_x = L_x/n_ex` with `L_x = 1` m: 1/2 = 0.500, 1/4 = 0.250, 1/6 = 0.167. `a = sqrt(l^2/10) = 0.015811` m for `l = 0.05` m, giving `h_x/a` = 31.6 / 15.8 / 10.5. **All pre-existing cells (DOF, u_avg, f_1) are unchanged.** Note: the existing Sec. 5.5 text quotes `h_x = 0.166 m` for the 6×3×3 mesh; the new column uses 0.167 m (correct rounding of 1/6 = 0.1667). This 0.001 m discrepancy is pre-existing wording vs. new column — see §3 below.

---

### E11 — R3 Point 2(b)

**Location:** Appendix B, Table B.3 caption  
**Type:** caption: 1 clause appended  
**Anchor:** end of the `\caption{…}` of Table B.3

**Before**
```latex
…Convergence is monotonic, with fourth-order rate expected when $h_x \ll a$.}
```

**After**
```latex
…Convergence is monotonic, with fourth-order rate expected when $h_x \ll a$. The added columns give the element size $h_x=L_x/n_{ex}$ and the boundary-layer resolution ratio $h_x/a$ with $a=0.0158$~m; none of the three meshes reaches $h_x\ll a$.}
```

**Why:** Explains the two new columns. Existing caption text unchanged.

---

### E12 — mechanical

**Location:** end of document  
**Type:** 1 token  
**Anchor:** `\bibliography{…}`

**Before**
```latex
\bibliography{references_R1}
```

**After**
```latex
\bibliography{references_R2}
```

**Why:** Points the manuscript at the Revision-2 bibliography.

---

### E13 — compile gate (pre-existing defect)

**Location:** Sec. 1 Introduction, contributions list  
**Type:** 1 token — bug fix  
**Anchor:** “(formally defined in Sec.~\ref{…})”

**Before**
```latex
(formally defined in Sec.~\ref{sec:fem_formulation})
```

**After**
```latex
(formally defined in Sec.~\ref{sec:finite_element_formulation})
```

**Why:** **Not part of R3’s two points.** `sec:fem_formulation` was never defined in `final_R1_unmarked.tex`, so the Revision-1 manuscript compiled with an undefined reference and printed “Sec. ??” on p. 3. The intended label is `sec:finite_element_formulation` (Sec. 5). Fixed because the delivery requirement is “no undefined references”. Marked in red in `final_R2.tex` so the editor can see it. **To revert:** change `\revtwo{\ref{sec:finite_element_formulation}}` back to `\ref{sec:fem_formulation}`.

---

### E14 — mechanical

**Location:** preamble of `final_R2.tex` only  
**Type:** 2 lines added  
**Anchor:** after `\newcommand{\rev}[1]{\textcolor{revcolor}{#1}}`

**Before**
```latex
\newcommand{\rev}[1]{\textcolor{revcolor}{#1}}
```

**After**
```latex
\newcommand{\rev}[1]{\textcolor{revcolor}{#1}}
\definecolor{revtwocolor}{RGB}{200,0,0}
\newcommand{\revtwo}[1]{\textcolor{revtwocolor}{#1}}
```

**Why:** New Revision-2 colour, dark red `RGB(200,0,0)`. The existing Revision-1 blue `\rev{}` macro and its colour are untouched, and **no Revision-1 text is wrapped in either macro** — `final_R1_unmarked.tex` contained no `\rev{}` calls, and `final_R2.tex` contains 13 `\revtwo{}` calls, all of them new Revision-2 text. Not present in `final_R2_unmarked.tex`.

---

## 2. `references_R2.bib`

`references_R1.bib` had **55** entries; `references_R2.bib` has **58**. The first 55 entries are **byte-identical** to `references_R1.bib`; only three were appended.

Verified: `references_R2.bib` starts with the exact bytes of `references_R1.bib`.

Appended entries:

```bibtex
% ==== Revision 2: three references added in response to Reviewer 3, Point 1 ====
% Bibliographic data verified against Crossref on 2026-10-14.

@inproceedings{Schey2019,
  author    = {Schey, Mathew J. and Stapleton, Scott E. and Przybyla, Craig P. and Uchic, Michael and Zabler, Simon},
  title     = {Determining a Length Scale of {FRP} Composite Microstructures},
  booktitle = {Proceedings of the American Society for Composites --- 34th Technical Conference},
  address   = {Atlanta, GA, USA},
  year      = {2019},
  publisher = {DEStech Publications, Inc.},
  doi       = {10.12783/asc34/31409}
}

@inproceedings{ScheyStapleton2022,
  author    = {Schey, Mathew and Stapleton, Scott E.},
  title     = {The Determination of a {3D} Length Scale Using Long Reconstructed Fiber Paths},
  booktitle = {Proceedings of the American Society for Composites --- 37th Technical Conference},
  address   = {Tucson, AZ, USA},
  year      = {2022},
  publisher = {DEStech Publications, Inc.},
  doi       = {10.12783/asc37/36446}
}

@article{RauterLammering2020,
  author    = {Rauter, Natalie and Lammering, Rolf},
  title     = {Correlation structure in the elasticity tensor for short fiber-reinforced composites},
  journal   = {Probabilistic Engineering Mechanics},
  volume    = {62},
  pages     = {103100},
  year      = {2020},
  publisher = {Elsevier},
  doi       = {10.1016/j.probengmech.2020.103100}
}
```

**Bibliographic verification (Crossref, 2026-10-14).** All three DOIs resolve and the metadata matches:

| Key | Crossref check |
|---|---|
| `Schey2019` | title, 5 authors, `proceedings-article`, DEStech Publications, 2019 — DOI 10.12783/asc34/31409 ✔ |
| `ScheyStapleton2022` | title, 2 authors, `proceedings-article`, Destech Publications, 2022 — DOI 10.12783/asc37/36446 ✔ |
| `RauterLammering2020` | title, 2 authors, *Probabilistic Engineering Mechanics*, **vol. 62**, 103100, 2020 — DOI 10.1016/j.probengmech.2020.103100 ✔ |

> ⚠️ **One correction to the data I was given:** the brief listed Rauter & Lammering as
> *Probabilistic Engineering Mechanics* **61** (2020) 103100. Crossref, ScienceDirect and three
> independent citing sources all give **volume 62**, October 2020, article 103100. The `.bib` entry
> uses **62**. Please confirm you are happy with this before submission.

## 3. Things deliberately NOT changed, and two points to confirm


1. **`h_x = 0.166 m` in Sec. 5.5 vs `0.167` in the new Table B.3 column.** The Revision-1 text already
   says `$h_x=0.166$ m` for the 6×3×3 mesh. The new column uses `0.167` (= 1/6 = 0.1667 rounded).
   Harmonising them would mean editing a Revision-1 sentence outside the two points in scope, so it was
   left alone. If you want them to agree, the one-word change is `0.166` → `0.167` in Sec. 5.5
   (`final_R2.tex` and `final_R2_unmarked.tex`). **Not done — your call.**

2. **Duplicate label `sec:3D_tricubic`** (defined twice in `final_R1_unmarked.tex`, at the start of
   Sec. 6.4 and again after the closing paragraph of Sec. 6.4.2). Pre-existing. It produces a
   `multiply defined` LaTeX **warning**, not an undefined reference, and the label is never `\ref`'d
   anywhere, so it does not affect the printed output. Left untouched because it is outside scope and
   does not breach the compile gate. **To fix:** delete the second `\label{sec:3D_tricubic}`
   (the stray one that follows “…the fidelity required for quantitative three-dimensional predictions.”).
   No new text in Revision 2 uses that label, precisely to avoid depending on it.

3. **No new numbers anywhere.** Every quantity added in Revision 2 is either already in the
   Revision-1 manuscript or obtained from it by arithmetic:
   `a = sqrt(l²/10) = sqrt(0.05²/10) = 0.015811 m`; `h_x = L_x/n_ex` = 0.500 / 0.250 / 0.1667 m;
   `h_x/a` = 31.6 / 15.8 / 10.5; 4×2×2 vs 6×3×3 = 1.0 % (u) and 2.1 % (f₁).
   `u`, `f₁`, DOF, 5.9 %, 9.3 %, 186.26 → 173.06 Hz, 178.72 Hz, DSI values: all unchanged.

4. **The orientation result stays monotonic** (186.26 → 173.06 Hz). Nothing about it was touched,
   and the earlier-corrected 45° matter is not mentioned anywhere in Revision 2.

5. **`highlights.tex` unchanged** — verified byte-identical to the submitted original.

6. **Reviewer 1 and Reviewer 2:** nothing changed in response to either.

## 4. Files in `FEM_1_R2.zip`


| File | Status |
|---|---|
| `final_R2.tex` | **new** — Revision-2 changes in red via `\revtwo{}`; all Revision-1 text unmarked |
| `final_R2_unmarked.tex` | **new** — identical text, no colour marking (clean copy for the journal) |
| `references_R2.bib` | **new** — `references_R1.bib` + 3 entries |
| `Response_to_Reviewer3_R2.tex` / `.pdf` | **new** — point-wise reply to Reviewer 3, 8 pages |
| `CHANGES_R2.md` | **new** — this file |
| `Fig01…Fig11 *.eps` (11), `Fig1_Ellipsoidal_Neighbourhood.png` | **unchanged**, byte-identical |
| `highlights.tex` | **unchanged**, byte-identical |
| `_diff_baseline/final_R1_unmarked.tex`, `references_R1.bib` | **unchanged**, in a subfolder so they cannot be mistaken for deliverables |
| `_scripts/` | the five scripts that build and verify this package, so every edit is reproducible |
| `_PREVIEW_placeholder_figures_DO_NOT_SUBMIT/` | preview PDFs — see the README inside |


## Addendum
- E15 (editorial): Sec. 5.5 `h_x=0.166 m` -> `0.167 m` (= 1/6 m), to agree with the h_x column added to Table B.3. Marked red in final_R2.tex.
