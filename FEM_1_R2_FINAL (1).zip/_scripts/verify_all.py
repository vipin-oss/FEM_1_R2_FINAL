#!/usr/bin/env python3
"""Final acceptance checks for the Revision-2 package. Prints a pass/fail table."""
import hashlib, os, re, subprocess, sys, glob

R1DIR = '/home/user/fem/x2'          # pristine files from FEM_1_Submitted_FEAD.zip
R2DIR = '/home/user/R2'
CHK   = '/home/user/build_check'
os.chdir(R2DIR)

results = []
def chk(name, ok, detail=''):
    results.append((name, bool(ok), detail))
    print(f"  [{'PASS' if ok else 'FAIL'}] {name}" + (f"   {detail}" if detail else ''))

def sha(p):
    return hashlib.sha256(open(p,'rb').read()).hexdigest()[:16]

r1  = open('final_R1_unmarked.tex', encoding='utf-8').read()
r2m = open('final_R2.tex', encoding='utf-8').read()
r2u = open('final_R2_unmarked.tex', encoding='utf-8').read()
b1  = open('references_R1.bib', encoding='utf-8').read()
b2  = open('references_R2.bib', encoding='utf-8').read()

print('='*76); print(' A. TEXT INTEGRITY'); print('='*76)

# A1 pristine baseline really is pristine
chk('final_R1_unmarked.tex identical to the submitted original',
    sha('final_R1_unmarked.tex') == sha(os.path.join(R1DIR,'final_R1_unmarked.tex')))

# A2 marked file minus colour markup == unmarked file
def strip(t, key='\\revtwo{'):
    out,i=[],0
    while True:
        j=t.find(key,i)
        if j<0: out.append(t[i:]); break
        out.append(t[i:j]); k=j+len(key); d=1
        while d:
            c=t[k]
            if c=='{': d+=1
            elif c=='}':
                d-=1
                if d==0: break
            k+=1
        out.append(t[j+len(key):k]); i=k+1
    return ''.join(out)

PREAMBLE = ('\\definecolor{revtwocolor}{RGB}{200,0,0}\n'
            '\\newcommand{\\revtwo}[1]{\\textcolor{revtwocolor}{#1}}\n')
chk('final_R2.tex minus \\revtwo markup == final_R2_unmarked.tex',
    strip(r2m.replace(PREAMBLE,'')) == r2u)

# A3 reverse-reconstruction: R2_unmarked - all edits == R1 byte for byte
ns={}
head=open('build_r2.py',encoding='utf-8').read().split("# APPLY")[0]
head=head.replace("s = open(SRC, encoding='utf-8').read()","s=''").replace("orig_len = len(s)","orig_len=0")
exec(compile(head,'build_r2.py','exec'),ns)
def stripR(t): return strip(t,'\\REVtwo{')
w = r2u
ok_rev = True
for n in ['P21','P54','P55A','P55B','P64','P66','P71','P72','PAPPB']:
    t = stripR(ns[n])
    if t not in w: ok_rev = False; print('     missing', n); break
    w = w.replace(t,'',1)
w = w.replace(stripR(ns['NEW_TAB']), ns['OLD_TAB'],1)
cap_new = stripR(ns['CAP_NEW'])
w = w.replace(cap_new, ns['CAP_OLD'],1)
w = w.replace('\\bibliography{references_R2}','\\bibliography{references_R1}',1)
w = w.replace('\\ref{sec:finite_element_formulation}','\\ref{sec:fem_formulation}',1)
chk('removing all 13 R2 edits reproduces final_R1_unmarked.tex byte-for-byte', w == r1)

# A4 diff size
d = subprocess.run(['diff','final_R1_unmarked.tex','final_R2_unmarked.tex'],
                   capture_output=True,text=True)
hunks = re.findall(r'^\d+', d.stdout, re.M)
chk('diff R1 -> R2_unmarked has exactly 14 change hunks', len(hunks)==14, f'(got {len(hunks)})')

# A5 no R1 text was wrapped in colour
chk('no Revision-1 text wrapped in \\revtwo{}',
    all(stripR(ns[n]).strip() in strip(r2m) for n in ['P21','P54'])
    and r2m.count('\\revtwo{') == 13, f"({r2m.count(chr(92)+'revtwo{')} blocks)")
chk('Revision-1 blue macro \\rev{} untouched and unused',
    '\\newcommand{\\rev}[1]{\\textcolor{revcolor}{#1}}' in r2m
    and r2m.count('\\rev{') == 0)

print(); print('='*76); print(' B. REFERENCES AND CROSS-REFERENCES'); print('='*76)
cites=set()
for m in re.findall(r'\\cite[tp]?\*?(?:\[[^\]]*\])*\{([^}]*)\}', r2m):
    for k in m.split(','):
        if k.strip(): cites.add(k.strip())
keys=set(re.findall(r'@\w+\s*\{\s*([^,\s]+)\s*,', b2))
chk('every \\cite key resolves in references_R2.bib', not (cites-keys),
    f'{len(cites)} cited / {len(keys)} available; unresolved: {sorted(cites-keys) or "none"}')
labels=re.findall(r'\\label\{([^}]*)\}', r2m)
refs=set(re.findall(r'\\(?:ref|eqref|autoref)\{([^}]*)\}', r2m))
chk('every \\ref/\\eqref target is labelled', not (refs-set(labels)),
    f'unresolved: {sorted(refs-set(labels)) or "none"}')
chk('references_R2.bib = references_R1.bib + 3 appended entries', b2.startswith(b1))
chk('bibliography count 55 -> 58',
    len(re.findall(r'@\w+\s*\{',b1))==55 and len(re.findall(r'@\w+\s*\{',b2))==58)
newkeys=['Schey2019','ScheyStapleton2022','RauterLammering2020']
chk('the 3 new keys are present and cited', all(k in keys and k in cites for k in newkeys))
chk('Rauter & Lammering recorded as volume 62 (Crossref-verified)',
    re.search(r'RauterLammering2020.*?volume\s*=\s*\{62\}', b2, re.S) is not None)

print(); print('='*76); print(' C. COMPILATION'); print('='*76)
for t in ['final_R2.tex','final_R2_unmarked.tex','Response_to_Reviewer3_R2.tex']:
    pdf = os.path.join(R2DIR if t.startswith('Response') else CHK, t.replace('.tex','.pdf'))
    chk(f'{t} produced a PDF', os.path.exists(pdf),
        f'{os.path.getsize(pdf)/1024:.0f} KiB' if os.path.exists(pdf) else '')
for t in ['final_R2','final_R2_unmarked']:
    log = os.path.join(CHK, t+'.log')
    if not os.path.exists(log):
        chk(f'{t}.log present', False); continue
    L = open(log,encoding='utf-8',errors='replace').read()
    chk(f'{t}: no undefined reference/citation',
        not re.search(r'LaTeX Warning: (Reference|Citation) .* undefined', L))
    chk(f'{t}: no LaTeX error', 'LaTeX Error' not in L and 'Emergency stop' not in L)
    known = "LaTeX Warning: Label `sec:3D_tricubic' multiply defined."
    other = [l for l in L.splitlines()
             if re.search(r'LaTeX Warning: Label .* multiply defined', l) and l.strip()!=known]
    chk(f'{t}: only the pre-existing duplicate-label warning remains', not other)
L = open('Response_to_Reviewer3_R2.log',encoding='utf-8',errors='replace').read()
chk('Response letter: no undefined reference/citation',
    not re.search(r'LaTeX Warning: (Reference|Citation) .* undefined', L))

print(); print('='*76); print(' D. RENDERED OUTPUT'); print('='*76)
import pypdf
flat = re.sub(r'\s+',' ',"\n".join(p.extract_text() for p in pypdf.PdfReader(os.path.join(CHK,'final_R2.pdf')).pages))
chk('no "??" anywhere in the compiled manuscript', '??' not in flat)
chk('Table B.3 numbered B.3 (unchanged from Revision 1)',
    re.search(r'newlabel\{tab:mesh3D\}\{\{B\.3\}', open(os.path.join(CHK,'final_R2.aux'),encoding='utf-8').read()) is not None)
must = {
 'ansatz statement'            : 'should therefore be read as a modelling ansatz',
 'correlation-length definition':'correlation length of a local field measured between material points',
 'do-not-overstate caveat'     : 'they do not measure a strain-averaging kernel',
 'future work'                 : 'remains essential future work',
 'Table B.3 forward ref'       : 'Full results for all three meshes are reported in Table B.3',
 'h_x/a ratios'                : '31.6',
 'bounds but does not eliminate':'bound the discretisation error',
 'C1 vs C0 statement'          : 'only piecewise linearly',
 'no fully-resolved claim'     : 'not claimed to be fully resolved',
 'l_x/L_x = 1 caveat'          : 'This corner corresponds to',
 'step 7'                      : 'Interaction-level verification',
 'not experimentally validated': 'not experimentally validated',
 'App B table intro'           : 'at the end of this appendix collects',
 'new table column value'      : '0.167',
}
for k,v in must.items():
    chk(f'rendered: {k}', re.sub(r'\s+',' ',v) in flat)

print(); print('='*76); print(' E. UNTOUCHED FILES'); print('='*76)
figs = sorted(glob.glob('*.eps')) + sorted(glob.glob('*.png'))
bad = [f for f in figs if os.path.exists(os.path.join(R1DIR,f)) and sha(f)!=sha(os.path.join(R1DIR,f))]
chk(f'all {len(figs)} figure files byte-identical to the submitted originals', not bad, str(bad or ''))
chk('highlights.tex byte-identical to the submitted original',
    sha('highlights.tex')==sha(os.path.join(R1DIR,'highlights.tex')))
chk('Response_to_Reviewers.tex (R1 letter) left in place and unmodified',
    sha('Response_to_Reviewers.tex')==sha(os.path.join(R1DIR,'Response_to_Reviewers.tex')))

print(); print('='*76); print(' F. NO INVENTED NUMBERS'); print('='*76)
# compare whole-file numeric content; citation keys carry years (e.g.
# RauterLammering2020) which are identifiers, not data, so strip them first
def nums(t):
    t = re.sub(r'\\cite[tp]?\{[^}]*\}', '', t)
    t = re.sub(r'\\[a-zA-Z]+', ' ', t)          # drop control words
    return set(re.findall(r'\d+\.\d+|\d+', t))
r1_nums, r2_nums = nums(r1), nums(r2u)
new_nums = r2_nums - r1_nums

# Re-derive every new numeric token from Revision-1 data and check it matches.
# Revision-1 inputs used:  L_x = 1 m, l = 0.05 m, a = 0.0158 m,
# Table B.3 rows (u = 4.5665 / 4.7876 / 4.8371 um, f1 = 193.00 / 178.72 / 174.96 Hz)
Lx, l = 1.0, 0.05
a = (l**2 / 10.0) ** 0.5                      # 0.015811388... m  (R1 quotes 0.0158)
hx = {2: Lx/2, 4: Lx/4, 6: Lx/6}
derived = {}
for n in (2, 4, 6):
    derived[f'{hx[n]:.3f}'] = f'h_x = L_x/{n} = {hx[n]:.4f} m'
    derived[f'{hx[n]/a:.1f}'] = f'h_x/a = {hx[n]:.4f}/{a:.6f} = {hx[n]/a:.2f}'
u_mid, u_fin = 4.7876, 4.8371
f_mid, f_fin = 178.72, 174.96
derived[f'{(u_fin-u_mid)/u_fin*100:.1f}'] = (f'(4.8371-4.7876)/4.8371 = '
                                            f'{(u_fin-u_mid)/u_fin*100:.2f}% ')
derived[f'{(f_mid-f_fin)/f_fin*100:.1f}'] = (f'(178.72-174.96)/174.96 = '
                                            f'{(f_mid-f_fin)/f_fin*100:.2f}%')
unexplained = sorted(n for n in new_nums if n not in derived)
chk('every new numeric token is re-derived from Revision-1 data',
    not unexplained,
    f'{len(new_nums)} new tokens, all accounted for' if not unexplained
    else f'unexplained: {unexplained}')
for k in sorted(derived):
    print(f'         {k:>8s}  =  {derived[k]}')
print(f'     a = sqrt(l^2/10) = {a:.9f} m  (Revision 1 quotes 0.0158 m)')
_unexpl = unexplained
print('     derived values:  a=sqrt(0.05^2/10)=0.015811 m;  h_x=L_x/n_ex = 0.500/0.250/0.1667 m;')
print('                      h_x/a = 31.6/15.8/10.5;  4x2x2 vs 6x3x3 = (4.8371-4.7876)/4.8371 = 1.0%;')
print('                      (178.72-174.96)/174.96 = 2.1%;  Rauter&Lammering volume 62 (Crossref).')

print()
npass = sum(1 for _,ok,_ in results if ok)
print('='*76)
print(f'  {npass}/{len(results)} checks passed')
fails = [(n,d) for n,ok,d in results if not ok]
if fails:
    print('  FAILURES:')
    for n,d in fails: print('    -',n,d)
print('='*76)

# emit a compact summary for CHANGES_R2.md section 0
with open('/tmp/verify_summary.md','w',encoding='utf-8') as f:
    f.write('| Check | Result |\n|---|---|\n')
    for n,ok,d in results:
        f.write(f'| {n} | {"PASS" if ok else "**FAIL**"}{(" — "+d) if d else ""} |\n')
    f.write(f'\n**{npass}/{len(results)} checks passed.**\n')
sys.exit(0 if not fails else 1)
