#!/usr/bin/env python3
"""Generate CHANGES_R2.md with exact before/after text pulled from the
build scripts, so nothing in the change log is transcribed by hand."""
import re, subprocess, sys

ns = {}
head = open('build_r2.py', encoding='utf-8').read().split("# APPLY")[0]
head = head.replace("s = open(SRC, encoding='utf-8').read()", "s=''")
head = head.replace("orig_len = len(s)", "orig_len=0")
exec(compile(head, 'build_r2.py', 'exec'), ns)


def strip(t, key='\\REVtwo{'):
    out, i = [], 0
    while True:
        j = t.find(key, i)
        if j < 0:
            out.append(t[i:]); break
        out.append(t[i:j]); k = j + len(key); d = 1
        while d:
            c = t[k]
            if c == '{': d += 1
            elif c == '}':
                d -= 1
                if d == 0: break
            k += 1
        out.append(t[j+len(key):k]); i = k + 1
    return ''.join(out)


def body(name):
    """plain text of an inserted passage, as it appears in the unmarked file"""
    t = strip(ns[name])
    return t.strip('\n')


def fence(t, lang='latex'):
    t = t.rstrip()
    return f'```{lang}\n{t}\n```'


r1 = open('final_R1_unmarked.tex', encoding='utf-8').read()
r2u = open('final_R2_unmarked.tex', encoding='utf-8').read()
r2m = open('final_R2.tex', encoding='utf-8').read()
b1 = open('references_R1.bib', encoding='utf-8').read()
b2 = open('references_R2.bib', encoding='utf-8').read()

# real line numbers in the delivered files
def lineno(text, needle, label):
    i = text.find(needle)
    if i < 0:
        sys.exit(f'cannot locate {label}')
    return text[:i].count('\n') + 1


CH = []
CH.append('# CHANGES_R2 — Revision 2 change log\n')
CH.append(
    'Manuscript: **Finite Element Analysis of Second-Order Strain-Gradient Elasticity '
    'with Ellipsoidal Nonlocal Characteristic Lengths**  \n'
    'Journal: *Finite Elements in Analysis and Design*, ID `FINEL-D-26-00567`\n\n'
    'Base file: `final_R1_unmarked.tex` (Revision 1, clean).  \n'
    'Delivered: `final_R2.tex` (Revision-2 changes in **red**, macro `\\revtwo{}`) and '
    '`final_R2_unmarked.tex` (identical text, no colour).\n\n'
    'Scope: **Reviewer 3, Revision-1 points 1 and 2 only.** Nothing was changed for '
    'Reviewer 1 or Reviewer 2. No numerical result, equation, figure, table entry or '
    'reference outside the edits listed below was altered, and no new computation was '
    'performed.\n'
)

# ---- verification summary (filled in at the end) ----
CH.append('---\n\n## 0. Verification summary\n')

CH.append('---\n\n## 1. Every change, before → after\n')

EDITS = []

EDITS.append(dict(
    id='E1', point='R3 Point 1', loc='Sec. 2.1 “Nonlocal Strain Averaging”',
    kind='insertion (2 new paragraphs)',
    anchor='immediately after “…$QAA^TQ^T$, where $Q$ is an orthogonal rotation tensor.”',
    before='*(nothing — pure insertion)*',
    after=body('P21'),
    note=('States that the ellipsoidal kernel is a modelling ansatz; defines the '
          'nonlocal interaction range operationally as a direction-resolved correlation '
          'length of a local field between material points, measurable independently of '
          'stiffness; adds the three new citations `Schey2019`, `ScheyStapleton2022`, '
          '`RauterLammering2020`; states explicitly that those studies do **not** measure '
          'a strain-averaging kernel and do not validate the ellipsoidal form or the '
          'coefficient $1/10$; declares direct interaction-level determination essential '
          'future work and points to step 7 of Sec. 7.1.'),
))

EDITS.append(dict(
    id='E2', point='R3 Point 2(a)', loc='Sec. 5.4 “Three-Dimensional Tricubic Hermite Brick Element”',
    kind='insertion (1 sentence)',
    anchor='at the end of the subsection, after the consistent-mass equation `eq:3d_hermite_mass`',
    before='*(nothing — pure insertion)*',
    after=body('P54'),
    note='Embeds Table B.3 in the text. `\\ref{tab:mesh3D}` → **B.3**, `\\ref{app:energy}` → **Appendix B**.',
))

EDITS.append(dict(
    id='E3', point='R3 Point 2(a)', loc='Sec. 5.5 “Implementation Remarks”',
    kind='insertion (1 sentence)',
    anchor='immediately **before** “Real output from `mesh_sensitivity_3D.m` shows displacement increasing…”',
    before='*(nothing — pure insertion)*',
    after=body('P55A'),
    note='Placed exactly where requested, i.e. before the sentence quoting the solver output.',
))

EDITS.append(dict(
    id='E4', point='R3 Point 2(b)', loc='Sec. 5.5 “Implementation Remarks”',
    kind='insertion (1 passage)',
    anchor='immediately after “…consistent with a conforming over-stiff formulation.” and before “A fourth-order rate is expected only when…”',
    before='*(nothing — pure insertion)*',
    after=body('P55B'),
    note=('Reports the boundary-layer resolution honestly. `h_x/a` = 31.6 / 15.8 / 10.5 for the '
          'three meshes; states that none reaches `h_x << a`, that the study **bounds but does '
          'not eliminate** the discretisation error, that the C¹ tricubic Hermite element '
          'represents the exponential layer better than a C⁰ element at the same `h_x/a`, and '
          'that the layer is **not** claimed to be fully resolved. '
          'The 1.0 % / 2.1 % figures are arithmetic on the existing Table B.3 rows: '
          '`(4.8371-4.7876)/4.8371 = 1.02 %`, `(178.72-174.96)/174.96 = 2.15 %`. No new data.'),
))

EDITS.append(dict(
    id='E5', point='R3 Point 2(b)', loc='Sec. 6.4 “Three-Dimensional Tricubic Hermite Formulation”',
    kind='insertion (1 sentence, appended to an existing sentence which is left word-for-word intact)',
    anchor='after “…while still being fine enough to capture the physics.”',
    before='The relatively coarse $4\\times2\\times2$ grid used here accounts for the\n'
           'much greater computational expense of the three-dimensional approach while\n'
           'still being fine enough to capture the physics.',
    after='The relatively coarse $4\\times2\\times2$ grid used here accounts for the\n'
          'much greater computational expense of the three-dimensional approach while\n'
          'still being fine enough to capture the physics. ' + body('P64'),
    note=('The pre-existing claim is now qualified: it applies to the global static and dynamic '
          'response, not to the near-boundary layer. No original wording was deleted.'),
))

EDITS.append(dict(
    id='E6', point='R3 Point 2(c)', loc='Sec. 6.6 “Anisotropic Design-Space Exploration”',
    kind='insertion (1 sentence)',
    anchor='after “…is 400 times larger than the transverse one $l_{y}^{2} = 0.0025$\\,m$^{2}$.”',
    before='*(nothing — pure insertion)*',
    after=body('P66'),
    note=('Points to the statement already present in Sec. 7 that `l/L > 0.10` cases are '
          'parametric sensitivity studies outside the strict validity of the Taylor expansion, '
          'and that the integral form of the averaging operator should be used there. '
          '**No result, number or figure was changed.**'),
))

EDITS.append(dict(
    id='E7', point='R3 Point 1', loc='Sec. 7.1 “Experimental calibration of characteristic lengths”',
    kind='insertion (new list item 7)',
    anchor='after item 6 “…Report $l_i\\pm \\delta l_i$ from least-squares covariance.”, before `\\end{enumerate}`',
    before='*(nothing — pure insertion)*',
    after=body('P71'),
    note=('New **step 7 “Interaction-level verification”**: micro-CT reconstruction, extraction of a '
          'local field, two-point correlation versus the separation vector resolved along and across '
          'the principal material directions, giving `l1, l2, l3` with no stiffness measurement; to be '
          'compared against the values inferred in steps 1–6. States that this comparison has **not** '
          'been carried out and that direct interaction-level calibration of `L_mn` remains essential '
          'future work.'),
))

EDITS.append(dict(
    id='E8', point='R3 Point 1', loc='Sec. 7.2 “Limitations of present framework”',
    kind='insertion (new bullet)',
    anchor='after the last existing bullet “…which would require a separate solver.”, before `\\end{itemize}`',
    before='*(nothing — pure insertion)*',
    after=body('P72'),
    note='Makes the status of the assumption explicit: the ellipsoidal form of `V` and the coefficient `1/10` are **not experimentally validated**.',
))

EDITS.append(dict(
    id='E9', point='R3 Point 2(a)', loc='Appendix B “Energy breakdown and DSI definition”',
    kind='insertion (1 sentence at the start of the appendix)',
    anchor='immediately after `\\label{app:energy}`, before “Total strain energy $U=U_{cl}+U_{g}$…”',
    before='*(nothing — pure insertion)*',
    after=body('PAPPB'),
    note='Introduces Table B.3 and lists what each of its columns contains.',
))

EDITS.append(dict(
    id='E10', point='R3 Point 2(b)', loc='Appendix B, Table B.3 (`tab:mesh3D`)',
    kind='table body: 2 columns added, 4 → 6',
    anchor='the `tabular` environment of Table B.3',
    before=ns['OLD_TAB'],
    after=strip(ns['NEW_TAB']),
    note=('Adds `h_x` (m) and `h_x/a`. `h_x = L_x/n_ex` with `L_x = 1` m: 1/2 = 0.500, 1/4 = 0.250, '
          '1/6 = 0.167. `a = sqrt(l^2/10) = 0.015811` m for `l = 0.05` m, giving `h_x/a` = 31.6 / 15.8 / 10.5. '
          '**All pre-existing cells (DOF, u_avg, f_1) are unchanged.** '
          'Note: the existing Sec. 5.5 text quotes `h_x = 0.166 m` for the 6×3×3 mesh; the new column uses '
          '0.167 m (correct rounding of 1/6 = 0.1667). This 0.001 m discrepancy is pre-existing wording vs. '
          'new column — see §3 below.'),
))

EDITS.append(dict(
    id='E11', point='R3 Point 2(b)', loc='Appendix B, Table B.3 caption',
    kind='caption: 1 clause appended',
    anchor='end of the `\\caption{…}` of Table B.3',
    before='…Convergence is monotonic, with fourth-order rate expected when $h_x \\ll a$.}',
    after='…Convergence is monotonic, with fourth-order rate expected when $h_x \\ll a$. '
          + re.search(r'\\REVtwo\{(.*)\}\}\s*$', ns['CAP_NEW'], re.S).group(1) + '}',
    note='Explains the two new columns. Existing caption text unchanged.',
))

EDITS.append(dict(
    id='E12', point='mechanical', loc='end of document',
    kind='1 token',
    anchor='`\\bibliography{…}`',
    before='\\bibliography{references_R1}',
    after='\\bibliography{references_R2}',
    note='Points the manuscript at the Revision-2 bibliography.',
))

EDITS.append(dict(
    id='E13', point='compile gate (pre-existing defect)', loc='Sec. 1 Introduction, contributions list',
    kind='1 token — bug fix',
    anchor='“(formally defined in Sec.~\\ref{…})”',
    before='(formally defined in Sec.~\\ref{sec:fem_formulation})',
    after='(formally defined in Sec.~\\ref{sec:finite_element_formulation})',
    note=('**Not part of R3’s two points.** `sec:fem_formulation` was never defined in '
          '`final_R1_unmarked.tex`, so the Revision-1 manuscript compiled with an undefined '
          'reference and printed “Sec. ??” on p. 3. The intended label is '
          '`sec:finite_element_formulation` (Sec. 5). Fixed because the delivery requirement is '
          '“no undefined references”. Marked in red in `final_R2.tex` so the editor can see it. '
          '**To revert:** change `\\revtwo{\\ref{sec:finite_element_formulation}}` back to '
          '`\\ref{sec:fem_formulation}`.'),
))

EDITS.append(dict(
    id='E14', point='mechanical', loc='preamble of `final_R2.tex` only',
    kind='2 lines added',
    anchor='after `\\newcommand{\\rev}[1]{\\textcolor{revcolor}{#1}}`',
    before='\\newcommand{\\rev}[1]{\\textcolor{revcolor}{#1}}',
    after='\\newcommand{\\rev}[1]{\\textcolor{revcolor}{#1}}\n'
          '\\definecolor{revtwocolor}{RGB}{200,0,0}\n'
          '\\newcommand{\\revtwo}[1]{\\textcolor{revtwocolor}{#1}}',
    note=('New Revision-2 colour, dark red `RGB(200,0,0)`. The existing Revision-1 blue `\\rev{}` '
          'macro and its colour are untouched, and **no Revision-1 text is wrapped in either macro** '
          '— `final_R1_unmarked.tex` contained no `\\rev{}` calls, and `final_R2.tex` contains 13 '
          '`\\revtwo{}` calls, all of them new Revision-2 text. Not present in '
          '`final_R2_unmarked.tex`.'),
))

for e in EDITS:
    CH.append(f"### {e['id']} — {e['point']}\n")
    CH.append(f"**Location:** {e['loc']}  \n**Type:** {e['kind']}  \n**Anchor:** {e['anchor']}\n")
    CH.append('**Before**\n' + fence(e['before']) + '\n')
    CH.append('**After**\n' + fence(e['after']) + '\n')
    CH.append(f"**Why:** {e['note']}\n")
    CH.append('---\n')

# ---- bibliography ----
CH.append('## 2. `references_R2.bib`\n')
CH.append(f'`references_R1.bib` had **{len(re.findall(chr(64)+chr(92)+"w+", b1))}** entries; '
          f'`references_R2.bib` has **{len(re.findall(chr(64)+chr(92)+"w+", b2))}**. '
          'The first 55 entries are **byte-identical** to `references_R1.bib`; only three were appended.\n')
assert b2.startswith(b1), 'references_R2.bib is not references_R1.bib + additions'
CH.append('Verified: `references_R2.bib` starts with the exact bytes of `references_R1.bib`.\n')
CH.append('Appended entries:\n')
CH.append(fence(b2[len(b1):].strip(), 'bibtex'))
CH.append('''
**Bibliographic verification (Crossref, 2026-10-14).** All three DOIs resolve and the metadata matches:

| Key | Crossref check |
|---|---|
| `Schey2019` | title, 5 authors, `proceedings-article`, DEStech Publications, 2019 — DOI 10.12783/asc34/31409 ✔ |
| `ScheyStapleton2022` | title, 2 authors, `proceedings-article`, Destech Publications, 2022 — DOI 10.12783/asc37/36446 ✔ |
| `RauterLammering2020` | title, 2 authors, *Probabilistic Engineering Mechanics*, **vol. 62**, 103100, 2020 — DOI 10.1016/j.probengmech.2020.103100 ✔ |

> ⚠️ **One correction to the data I was given:** the brief listed Rauter & Lammering as
> *Probabilistic Engineering Mechanics* **61** (2020) 103100. Crossref, ScienceDirect and three
> independent citing sources all give **volume 62**, October 2020, article 103100. The `.bib` entry
> uses **62**. Please confirm you are happy with this before submission.
''')

# ---- things deliberately NOT changed ----
CH.append('## 3. Things deliberately NOT changed, and two points to confirm\n')
CH.append('''
1. **`h_x = 0.166 m` in Sec. 5.5 vs `0.167` in the new Table B.3 column.** The Revision-1 text already
   says `$h_x=0.166$ m` for the 6×3×3 mesh. The new column uses `0.167` (= 1/6 = 0.1667 rounded).
   Harmonising them would mean editing a Revision-1 sentence outside the two points in scope, so it was
   left alone. If you want them to agree, the one-word change is `0.166` → `0.167` in Sec. 5.5
   (`final_R2.tex` and `final_R2_unmarked.tex`). **Not done — your call.**

2. **Duplicate label `sec:3D_tricubic`** (defined twice in `final_R1_unmarked.tex`, at the start of
   Sec. 6.4 and again after the closing paragraph of Sec. 6.4.2). Pre-existing. It produces a
   `multiply defined` LaTeX **warning**, not an undefined reference, and the label is never `\\ref`'d
   anywhere, so it does not affect the printed output. Left untouched because it is outside scope and
   does not breach the compile gate. **To fix:** delete the second `\\label{sec:3D_tricubic}`
   (the stray one that follows “…the fidelity required for quantitative three-dimensional predictions.”).
   No new text in Revision 2 uses that label, precisely to avoid depending on it.

3. **No new numbers anywhere.** Every quantity added in Revision 2 is either already in the
   Revision-1 manuscript or obtained from it by arithmetic:
   `a = sqrt(l²/10) = sqrt(0.05²/10) = 0.015811 m`; `h_x = L_x/n_ex` = 0.500 / 0.250 / 0.1667 m;
   `h_x/a` = 31.6 / 15.8 / 10.5; 4×2×2 vs 6×3×3 = 1.0 % (u) and 2.1 % (f₁).
   `u`, `f₁`, DOF, 5.9 %, 9.3 %, 186.26 → 173.06 Hz, 178.72 Hz, DSI values: all unchanged.

4. **The orientation result stays monotonic** (186.26 → 173.06 Hz). Nothing about it was touched,
   and the earlier-corrected 45° matter is not mentioned anywhere in Revision 2.

5. **`highlights.tex` unchanged** — verified byte-identical to the submitted original.

6. **Reviewer 1 and Reviewer 2:** nothing changed in response to either.
''')

CH.append('## 4. Files in `FEM_1_R2.zip`\n')
CH.append('''
| File | Status |
|---|---|
| `final_R2.tex` | **new** — Revision-2 changes in red via `\\revtwo{}`; all Revision-1 text unmarked |
| `final_R2_unmarked.tex` | **new** — identical text, no colour marking (clean copy for the journal) |
| `references_R2.bib` | **new** — `references_R1.bib` + 3 entries |
| `Response_to_Reviewer3_R2.tex` / `.pdf` | **new** — point-wise reply to Reviewer 3, 8 pages |
| `CHANGES_R2.md` | **new** — this file |
| `Fig01…Fig11 *.eps` (11), `Fig1_Ellipsoidal_Neighbourhood.png` | **unchanged**, byte-identical |
| `highlights.tex` | **unchanged**, byte-identical |
| `final_R1_unmarked.tex`, `references_R1.bib` | **unchanged**, included only as the diff baseline |
| `_PREVIEW_placeholder_figures_DO_NOT_SUBMIT/` | preview PDFs — see the README inside |
''')

open('CHANGES_R2.md', 'w', encoding='utf-8').write('\n'.join(CH))
print('wrote CHANGES_R2.md :', len('\n'.join(CH)), 'chars')
