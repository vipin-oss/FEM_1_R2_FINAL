#!/usr/bin/env python3
"""
Build Revision-2 deliverables from final_R1_unmarked.tex.

Strategy that guarantees final_R2.tex and final_R2_unmarked.tex carry
IDENTICAL text:
  1. all new passages are inserted wrapped in a placeholder macro \REVtwo{...}
  2. final_R2.tex          <- placeholder renamed to \revtwo (coloured)
  3. final_R2_unmarked.tex <- placeholder stripped, contents kept
"""
import re, sys

SRC = 'final_R1_unmarked.tex'
s = open(SRC, encoding='utf-8').read()
orig_len = len(s)
log = []


def sub_once(text, old, new, tag):
    n = text.count(old)
    if n != 1:
        sys.exit(f"FATAL: anchor {tag} matched {n} times (expected 1)")
    log.append(tag)
    return text.replace(old, new, 1)


# =====================================================================
# NEW PASSAGES  (all wrapped in \REVtwo{...})
# =====================================================================

# ---- (1) Sec 2.1 : modelling-ansatz statement + 3 new citations ----
P21 = r"""

\REVtwo{A caution is needed regarding the physical status of the
ellipsoidal neighbourhood. The second-moment construction guarantees
that an axis-aligned or rotated ellipsoid yields an anisotropic tensor
$L_{mn}$, but that is a geometric statement about the averaging domain
chosen here; it is not evidence that a given real microstructure
possesses an anisotropic interaction domain. The features usually
invoked in this connection --- aligned fibres, elongated or drawn
grains, oriented lattice struts --- are well documented to produce
anisotropic macroscopic response, and anisotropic response is a weaker
statement than anisotropic interaction. The ellipsoidal kernel adopted
in Eq.~\eqref{eq:ellipsoid_domain} should therefore be read as a
modelling ansatz: a parsimonious geometric parameterisation that admits
direction-dependent interaction ranges and that collapses to the usual
isotropic gradient model when $l_1=l_2=l_3$.}

\REVtwo{The ansatz is nevertheless testable, because an interaction
range is an operationally well-defined quantity in its own right. In a
weakly nonlocal description the neighbourhood over which the state at
$\mathbf{x}$ is influenced by the state at $\mathbf{x}+\boldsymbol{\xi}$
plays the role of a correlation length of a local field measured between
material points, so it can be estimated from microstructural images
without reference to any stiffness measurement, and it can be resolved
along and across a preferred material direction. Micro-computed
tomography reconstructions of fibre paths in fibre-reinforced polymers
have been used in exactly this way: microstructural descriptors are
correlated as a function of separation distance and the distance over
which that correlation decays defines a length scale of the
microstructure, the three-dimensional reconstruction allowing the
analysis to be performed along and across the fibres rather than on
two-dimensional sections alone \cite{Schey2019,ScheyStapleton2022}. In a
related but distinct setting, the elasticity tensor of short
fibre-reinforced composites has been shown to possess an anisotropic
spatial correlation structure whose correlation functions differ between
directions and reflect the overall transversely isotropic material
behaviour \cite{RauterLammering2020}. These studies measure the spatial
correlation of microstructural or material-property fields; they do not
measure a strain-averaging kernel, and they do not establish the
particular ellipsoidal form of $\mathcal{V}$ or the coefficient $1/10$
used here. What they do show is that direction-resolved correlation
lengths are measurable properties of real heterogeneous media, so that
an anisotropic $L_{mn}$ is not purely a mathematical artefact of the
averaging geometry. A direct experimental determination of the
interaction-level anisotropy postulated in Eq.~\eqref{eq:ellipsoid_domain},
as opposed to an inference from macroscopic response, is not attempted in
the present work and remains essential future work; the measurement
route is outlined as step~7 of the calibration protocol in
Sec.~\ref{sec:exp_calib}.}
"""

# ---- (2) Sec 5.4 : pointer to Table B.3 ----
P54 = r"""

\REVtwo{The mesh density adopted for the three-dimensional computations,
together with its sensitivity, is quantified in
Table~\ref{tab:mesh3D} (\ref{app:energy}).}
"""

# ---- (3) Sec 5.5 : explicit forward reference to Table B.3 ----
P55A = r"""\REVtwo{Full results for all three meshes are reported in
Table~\ref{tab:mesh3D} (\ref{app:energy}). }"""

# ---- (4) Sec 5.5 : honest boundary-layer resolution statement ----
P55B = r""" \REVtwo{Expressed as a resolution ratio, the three meshes give
$h_{x}/a=31.6$, $15.8$ and $10.5$ for $2\times1\times1$, $4\times2\times2$
and $6\times3\times3$ respectively, so none of them reaches the
$h_{x}\ll a$ regime. The monotonic trend and the $5.9\%$ and $9.3\%$
spreads therefore bound the discretisation error associated with the
boundary layer, but they do not eliminate it. The $4\times2\times2$ mesh
used throughout Sec.~\ref{sec:numerical_results} differs from the finest
mesh tested by about $1.0\%$ in displacement and $2.1\%$ in frequency,
and because the trend has not saturated these figures are lower bounds on
the error remaining at that density. The element choice partially offsets
the coarse resolution: since the tricubic Hermite element carries slope
and curvature degrees of freedom, it can represent the exponential decay
$\theta(x)\propto1-e^{-x/a}$ within a single element, whereas a $C^{0}$
element of the same size can reproduce that profile only piecewise
linearly. That is a relative advantage at a given $h_{x}/a$, not a
substitute for resolving the layer, and the boundary layer is not claimed
to be fully resolved at any of the three densities.}"""

# ---- (5) Sec 6.4 : qualify the "fine enough" claim ----
P64 = r""" \REVtwo{This applies to the global static and dynamic response and
should not be read as a claim that the near-boundary strain-gradient
layer is fully resolved: for $l=0.05$\,m the layer thickness is
$a=\sqrt{l^{2}/10}=0.0158$\,m, so the $4\times2\times2$ grid corresponds
to $h_{x}/a\approx15.8$. The mesh-sensitivity study summarised in
Table~\ref{tab:mesh3D} and discussed in
Sec.~\ref{subsec:fem_implementation_remarks} quantifies the resulting
discretisation error.}"""

# ---- (6) Sec 6.6 : l_x/L_x = 1 validity pointer ----
P66 = r"""
\REVtwo{This corner corresponds to $l_{x}/L_{x}=1$, well outside the
weakly nonlocal regime in which the second-order Taylor expansion of
Sec.~2.1 is derived; as noted in
Sec.~\ref{sec:calibration}, cases with $l/L>0.10$ are parametric
sensitivity studies that map the trend of the model rather than
physically admissible configurations, and the integral form of the
averaging operator, not its gradient approximation, should be used
there.}
"""

# ---- (7) Sec 7.1 : new step 7, interaction-level verification ----
P71 = r"""
  \item \REVtwo{\textbf{Interaction-level verification:} Steps 1--6 infer
  $l_{x},l_{y},l_{z}$ from macroscopic response, so they cannot by
  themselves distinguish an anisotropic interaction domain from an
  anisotropic constitutive response. An independent check should
  therefore be made at the microstructural level. The microstructure is
  reconstructed by micro-computed tomography, a local field is extracted
  from it (fibre path geometry, local orientation, or a local elasticity
  estimate from resolved representative volume elements), and the
  two-point correlation of that field is computed as a function of the
  separation vector $\boldsymbol{\xi}$, resolved along and across the
  principal material directions. The decay lengths of these
  direction-resolved correlations provide estimates of $l_{1},l_{2},l_{3}$
  that involve no stiffness measurement, and they can then be compared
  with the values inferred in steps 1--6. Agreement between the two would
  support the interaction-level interpretation of $L_{mn}$ adopted in
  Sec.~2.1, whereas disagreement would
  indicate that the ellipsoidal kernel does not adequately represent the
  true interaction domain. This comparison has not been carried out here,
  and a direct interaction-level calibration of $L_{mn}$ remains essential
  future work.}
"""

# ---- (8) Sec 7.2 : new limitation bullet ----
P72 = r"""
  \item \REVtwo{The anisotropy of the interaction domain is a modelling
  assumption rather than an established experimental fact. Aligned fibres,
  elongated grains and oriented lattice struts evidence anisotropic
  response, not anisotropic interaction, and neither the present work nor
  the literature cited here measures the strain-averaging kernel directly.
  The ellipsoidal form of $\mathcal{V}$ and the coefficient $1/10$ are
  therefore not experimentally validated; step~7 of
  Sec.~\ref{sec:exp_calib} outlines how they could be tested.}
"""

# ---- (9) Appendix B : sentence introducing Table B.3 ----
PAPPB = r"""\REVtwo{Table~\ref{tab:mesh3D} at the end of this appendix collects the
three-dimensional mesh-sensitivity results referred to in
Sec.~\ref{subsec:three_dimensional_hermite_element},
Sec.~\ref{subsec:fem_implementation_remarks}; for each of the three grids it
reports the mesh density, the number of degrees of freedom, the element
size $h_{x}$, the boundary-layer resolution ratio $h_{x}/a$, the mean
right-face displacement and the fundamental frequency. }"""

# ---- (10) Table B.3 : add h_x and h_x/a columns ----
OLD_TAB = r"""\begin{tabular}{cccc}
\hline
Mesh & DOF (=nodes$\times$24) & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 4.8371 & 174.96 \\
\hline
\end{tabular}"""

NEW_TAB = r"""\REVtwo{\begin{tabular}{cccccc}
\hline
Mesh & DOF (=nodes$\times$24) & $h_x$ (m) & $h_x/a$ & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 0.500 & 31.6 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 0.250 & 15.8 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 0.167 & 10.5 & 4.8371 & 174.96 \\
\hline
\end{tabular}}"""

CAP_OLD = r"""Convergence is monotonic, with fourth-order rate expected when $h_x \ll a$.}"""
CAP_NEW = r"""Convergence is monotonic, with fourth-order rate expected when $h_x \ll a$. \REVtwo{The added columns give the element size $h_x=L_x/n_{ex}$ and the boundary-layer resolution ratio $h_x/a$ with $a=0.0158$~m; none of the three meshes reaches $h_x\ll a$.}}"""


# =====================================================================
# APPLY
# =====================================================================

# (1) Sec 2.1
a = "$QAA^TQ^T$, where $Q$ is an orthogonal rotation tensor."
s = sub_once(s, a, a + P21, 'E1  Sec 2.1  modelling-ansatz + 3 citations')

# (2) Sec 5.4
a = """The consistent mass matrix is
\\begin{equation}
\\label{eq:3d_hermite_mass}
\\mathbf{M}^{e}
=
\\int_{\\Omega_e}
\\rho\\,\\mathbf{N}_v^T\\mathbf{N}_v\\,d\\Omega .
\\end{equation}"""
s = sub_once(s, a, a + P54, 'E2  Sec 5.4  pointer to Table B.3')

# (3) Sec 5.5 forward ref
a = "Real output from \\texttt{mesh\\_sensitivity\\_3D.m} shows displacement increasing"
s = sub_once(s, a, P55A + a, 'E3  Sec 5.5  forward ref to Table B.3')

# (4) Sec 5.5 resolution honesty
a = "consistent with a conforming over-stiff formulation."
s = sub_once(s, a, a + P55B, 'E4  Sec 5.5  h_x/a resolution + error bound')

# (5) Sec 6.4 qualify coarse-grid claim
a = "while\nstill being fine enough to capture the physics."
s = sub_once(s, a, a + P64, 'E5  Sec 6.4  qualify coarse-grid claim')

# (6) Sec 6.6 l_x/L_x = 1
a = "$l_{y}^{2} = 0.0025$\\,m$^{2}$."
s = sub_once(s, a, a + P66, 'E6  Sec 6.6  l_x/L_x=1 validity pointer')

# (7) Sec 7.1 step 7
a = "Report $l_i\\pm \\delta l_i$ from least-squares covariance.\n\\end{enumerate}"
s = sub_once(s, a,
             "Report $l_i\\pm \\delta l_i$ from least-squares covariance.\n"
             + P71 + "\\end{enumerate}",
             'E7  Sec 7.1  new step 7 (interaction-level verification)')

# (8) Sec 7.2 limitation bullet
a = "which would require a separate solver.\n\\end{itemize}"
s = sub_once(s, a,
             "which would require a separate solver.\n" + P72 + "\\end{itemize}",
             'E8  Sec 7.2  new limitation bullet')

# (9) Appendix B intro sentence
a = "\\label{app:energy}\nTotal strain energy"
s = sub_once(s, a, "\\label{app:energy}\n" + PAPPB + "Total strain energy",
             'E9  App B  sentence introducing Table B.3')

# (10) Table B.3 columns + caption clause
s = sub_once(s, OLD_TAB, NEW_TAB, 'E10 Table B.3  add h_x and h_x/a columns')
s = sub_once(s, CAP_OLD, CAP_NEW, 'E11 Table B.3 caption  h_x/a clause')

# (12) bibliography file
s = sub_once(s, "\\bibliography{references_R1}", "\\bibliography{references_R2}",
             'E12 switch to references_R2.bib')

# (13) pre-existing broken \ref  (needed for a clean compile)
s = sub_once(s, "\\ref{sec:fem_formulation}",
             "\\REVtwo{\\ref{sec:finite_element_formulation}}",
             'E13 fix pre-existing undefined \\ref{sec:fem_formulation}')


# =====================================================================
# helper: strip \REVtwo{...} keeping contents (brace-balanced)
# =====================================================================
def strip_revtwo(t):
    out = []
    i = 0
    key = '\\REVtwo{'
    while True:
        j = t.find(key, i)
        if j < 0:
            out.append(t[i:])
            break
        out.append(t[i:j])
        k = j + len(key)
        depth = 1
        while depth:
            c = t[k]
            if c == '{':
                depth += 1
            elif c == '}':
                depth -= 1
                if depth == 0:
                    break
            k += 1
        out.append(t[j + len(key):k])       # inner content
        i = k + 1                            # skip closing brace
    return ''.join(out)


# =====================================================================
# EMIT
# =====================================================================
PREAMBLE_ANCHOR = "\\newcommand{\\rev}[1]{\\textcolor{revcolor}{#1}}"
COLOUR_MACROS = PREAMBLE_ANCHOR + """
\\definecolor{revtwocolor}{RGB}{200,0,0}
\\newcommand{\\revtwo}[1]{\\textcolor{revtwocolor}{#1}}"""

# ---- marked version ----
marked = s.replace('\\REVtwo{', '\\revtwo{')
n_marked = marked.count('\\revtwo{')
marked = sub_once(marked, PREAMBLE_ANCHOR, COLOUR_MACROS,
                  'E14 preamble  revtwocolor + \\revtwo macro')
open('final_R2.tex', 'w', encoding='utf-8').write(marked)

# ---- unmarked version ----
unmarked = strip_revtwo(s)
assert '\\REVtwo' not in unmarked, 'placeholder survived stripping'
open('final_R2_unmarked.tex', 'w', encoding='utf-8').write(unmarked)

# ---- identity check: text of the two files must be the same ----
_back = marked.replace(COLOUR_MACROS, PREAMBLE_ANCHOR).replace('\\revtwo{', '\\REVtwo{')
m_txt = strip_revtwo(_back)
if m_txt != unmarked:
    sys.exit('FATAL: marked and unmarked text differ')

print('inserted passages:', len(log))
for e in log:
    print('   ', e)
print()
print(f'\\revtwo{{}} blocks in final_R2.tex : {n_marked}')
print(f'chars  R1 -> R2 (unmarked)         : {orig_len} -> {len(unmarked)}  (+{len(unmarked)-orig_len})')
print('identity check marked/unmarked     : OK')
