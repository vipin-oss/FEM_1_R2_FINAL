#!/usr/bin/env python3
"""Assemble Response_to_Reviewer3_R2.tex, quoting the exact inserted
manuscript passages programmatically so that nothing is transcribed by hand."""
import sys

import re as _re
_re_cap = _re.compile(r'\\REVtwo\{(.*)\}\}\s*$', _re.S)

ns = {}
head = open('build_r2.py', encoding='utf-8').read().split("# APPLY")[0]
head = head.replace("s = open(SRC, encoding='utf-8').read()", "s=''")
head = head.replace("orig_len = len(s)", "orig_len=0")
exec(compile(head, 'build_r2.py', 'exec'), ns)


def strip(t, key='\\REVtwo{'):
    out, i = [], 0
    while True:
        j = t.find(key, i)
        if j < 0:
            out.append(t[i:]); break
        out.append(t[i:j]); k = j + len(key); d = 1
        while d:
            c = t[k]
            if c == '{': d += 1
            elif c == '}':
                d -= 1
                if d == 0: break
            k += 1
        out.append(t[j+len(key):k]); i = k + 1
    return ''.join(out)


RESOLVED = {
    r'\eqref{eq:ellipsoid_domain}':                  '(3)',
    r'\ref{tab:mesh3D}':                             'B.3',
    r'\ref{app:energy}':                             'Appendix~B',
    r'\ref{sec:exp_calib}':                          '7.1',
    r'\ref{sec:calibration}':                        '7',
    r'\ref{subsec:three_dimensional_hermite_element}':'5.4',
    r'\ref{subsec:fem_implementation_remarks}':      '5.5',
    r'\ref{sec:numerical_results}':                  '6',
}


def q(name, leading_ws=True):
    """exact manuscript text of an inserted passage, ready to quote.
    Cross-reference numbers are resolved so that the response letter, which
    has no labels of its own, shows what the manuscript actually prints."""
    t = strip(ns[name]).strip('\n')
    t = t.replace(r'\item ', '').replace(r'\item', '')
    for k, v in RESOLVED.items():
        t = t.replace(k, v)
    return t


def resolve(t):
    for k, v in RESOLVED.items():
        t = t.replace(k, v)
    return t


_parts = [resolve(t).strip() for t in strip(ns['P21']).split('\n\n') if t.strip()]
assert len(_parts) == 2, f'expected 2 paragraphs in Sec 2.1 insertion, got {len(_parts)}'
Q21A, Q21B = _parts
Q54 = q('P54')
Q55A = q('P55A')
Q55B = q('P55B').lstrip()
Q64 = q('P64').lstrip()
Q66 = q('P66')
Q71 = q('P71')
Q72 = q('P72')
QAPPB = q('PAPPB')

NEWTAB = r"""\begin{tabular}{cccccc}
\hline
Mesh & DOF (=nodes$\times$24) & $h_x$ (m) & $h_x/a$ & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 0.500 & 31.6 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 0.250 & 15.8 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 0.167 & 10.5 & 4.8371 & 174.96 \\
\hline
\end{tabular}"""

OLDTAB = r"""\begin{tabular}{cccc}
\hline
Mesh & DOF (=nodes$\times$24) & $u_{avg}$ ($\mu$m) & $f_1$ (Hz) \\
\hline
$2\times1\times1$ (12 nodes) & 288 & 4.5665 & 193.00 \\
$4\times2\times2$ (45 nodes) & 1080 & 4.7876 & 178.72 \\
$6\times3\times3$ (112 nodes) & 2688 & 4.8371 & 174.96 \\
\hline
\end{tabular}"""

# the caption clause is exactly the body of the \REVtwo{...} added to the caption
_m = _re_cap.search(ns['CAP_NEW'])
assert _m, 'could not locate the added caption clause'
CAPCLAUSE = resolve(_m.group(1).strip())
assert ns['CAP_OLD'][:-1] not in CAPCLAUSE, 'caption clause wrongly includes pre-existing text'
assert CAPCLAUSE.count('{') == CAPCLAUSE.count('}'), 'caption clause unbalanced'
assert not CAPCLAUSE.endswith('}'), 'caption clause carries the caption closing brace'


NEWTAB = resolve(NEWTAB)
for nm, val in [('Q21A', Q21A), ('Q21B', Q21B), ('Q54', Q54), ('Q55A', Q55A),
                ('Q55B', Q55B), ('Q64', Q64), ('Q66', Q66), ('Q71', Q71),
                ('Q72', Q72), ('QAPPB', QAPPB), ('CAPCLAUSE', CAPCLAUSE)]:
    assert val.strip(), f'{nm} is empty'
    print(f'  {nm:10s} {len(val):5d} chars')

# ---------------------------------------------------------------------
BODY = r"""
\section*{Comment 1 --- physical origin of the anisotropic interactions}

\begin{quote}\small\itshape
The fundamental concern raised in my previous review has not been resolved. The ellipsoidal averaging domain generates anisotropic second moments mathematically, but this does not establish that a particular physical microstructure gives rise to such an interaction domain. References to aligned fibres, elongated grains, and lattice struts provide plausible cases of anisotropic response but do not provide any physics-based background on the origin of anisotropic interactions (which experiment would, respectively could prove that related interactions (i.e.\ interactions and not the resulting constitutive relations) are direction dependent?).
\end{quote}

\textbf{Response.} The reviewer is correct, and the distinction drawn in the comment is one we had blurred. The examples we gave --- aligned fibres, elongated or drawn grains, oriented lattice struts --- are evidence that such materials respond anisotropically. They are not evidence that the range over which material points interact is itself direction dependent, and nothing in our earlier text established the second claim from the first. We have therefore rewritten the relevant passage instead of defending it, and the ellipsoidal kernel is now described in Sec.~2.1 as what it actually is: a modelling ansatz.

We would like to set out why we nevertheless consider the ansatz testable rather than merely convenient, since this is what allows the reviewer's question to be answered with a concrete experiment. A nonlocal interaction range is operationally a correlation length. It is the separation over which a local field measured at one material point remains correlated with the same field measured at another. A correlation length of this kind can be estimated from microstructural images alone, with no stiffness measurement and no constitutive model involved, and it can be resolved along and across a preferred material direction. If the correlation length obtained that way depends on direction, then the interaction range depends on direction. That is a statement about the microstructure and not about the resulting constitutive relation, which is precisely the separation the reviewer asks for.

Measurements of this kind have been reported for fibre-reinforced polymers, and we have added three references to the manuscript. Schey et al.\ \cite{Schey2019} reconstruct fibre-reinforced polymer microstructures by micro-computed tomography and correlate microstructural descriptors as a function of separation distance in order to determine a length scale of the microstructure. Schey and Stapleton \cite{ScheyStapleton2022} extend that procedure to long reconstructed fibre paths in three dimensions, which allows the length scale to be resolved along and across the fibres rather than inferred from two-dimensional sections. Rauter and Lammering \cite{RauterLammering2020} examine the spatial correlation structure of the elasticity tensor of short fibre-reinforced composites and find correlation functions that differ between directions, consistent with an overall transversely isotropic material behaviour.

We want to be explicit about the limits of this support, because overstating it would repeat the error the reviewer identified. Those studies measure the spatial correlation of microstructural or material-property fields. They do not measure a strain-averaging kernel. They do not establish the ellipsoidal shape of $\mathcal{V}$, and they do not establish the coefficient $1/10$ that follows from it. What they do establish is that direction-resolved correlation lengths are measurable properties of real heterogeneous media, so that a direction-dependent $L_{mn}$ is not purely an artefact of the averaging geometry we chose. The revised manuscript says this in those terms.

Two passages have been added to Sec.~2.1 (p.~5). The first states the ansatz and its scope:

\begin{quote}\small
\textit{Q21A}
\end{quote}

\noindent The second defines the interaction range operationally, cites the three references above, and states what they do and do not show:

\begin{quote}\small
\textit{Q21B}
\end{quote}

The reviewer's question --- which experiment could show that the interactions rather than the constitutive response are direction dependent --- is answered by a measurement, not by an argument, so we have added it as a new step~7 of the calibration protocol in Sec.~7.1 (p.~37):

\begin{quote}\small
\textit{Q71}
\end{quote}

\noindent and, so that the status of the assumption is not left implicit anywhere in the paper, as a new entry in the limitations list in Sec.~7.2 (p.~37):

\begin{quote}\small
\textit{Q72}
\end{quote}

We have not performed the comparison described in step~7 and we do not claim that the ellipsoidal kernel has been experimentally validated. Steps~1 to 6 of the protocol infer $l_x,l_y,l_z$ from macroscopic response and therefore cannot by themselves separate an anisotropic interaction domain from an anisotropic constitutive response; only step~7 can, and it remains future work. We are grateful for the insistence on this point, because the earlier version of the manuscript did read as though the geometric construction carried physical evidence that it does not carry.

\section*{Comment 2 --- scope of the examples, validity range, Table~B.3 and 3D discretisation}

\begin{quote}\small\itshape
The new orientation study and Directional Stiffening Index illustrate the mathematical consequences of the assumed tensorial length scale, but the examples remain limited to idealised bars, rectangles, and cuboids. Some of the strongest effects are obtained for characteristic lengths comparable to the structural dimension, including $l_x/L_x = 1$, although the Taylor expansion requires $l_{\max} \ll L_\varepsilon$. Moreover Table B.3 seems not to be appropriately embedded in the (text of the) paper and the appendix. Independent of the results summarized in Table B.3, are the discretizations chosen sufficiently fine in order to appropriate capture boundary effects (in 3D)?
\end{quote}

\textbf{Response.} We deal with the four matters raised here in turn.

\subsection*{(a) Table B.3 was not embedded in the text}

The reviewer is right. Table~B.3 carried a label but was never cited anywhere in the manuscript, so it appeared in the appendix with no textual anchor. It is now referred to from three places, and the appendix introduces it explicitly.

At the end of Sec.~5.4, where the three-dimensional element and its consistent mass matrix are defined (p.~17):

\begin{quote}\small
\textit{Q54}
\end{quote}

\noindent In the mesh-sensitivity paragraph of Sec.~5.5, immediately before the sentence that quotes the solver output (p.~18):

\begin{quote}\small
\textit{Q55A}
\end{quote}

\noindent At the start of Appendix~B (p.~40):

\begin{quote}\small
\textit{QAPPB}
\end{quote}

\subsection*{(b) Are the 3D discretisations fine enough to capture boundary effects?}

Not to the standard the question implies, and we have said so in the revised manuscript rather than leaving the reader to infer it from the table.

For $l=0.05$\,m and $L_x=1$\,m the boundary-layer thickness is $a=\sqrt{l^2/10}=0.0158$\,m. The three meshes in Table~B.3 therefore correspond to the following resolution ratios, which we have added to the table as two new columns:

\begin{center}\small
\begin{tabular}{lcccc}
\hline
Mesh & $h_x$ (m) & $h_x/a$ & DOF & $h_x\ll a$ reached? \\
\hline
$2\times1\times1$ & 0.500 & 31.6 & 288  & no \\
$4\times2\times2$ & 0.250 & 15.8 & 1080 & no \\
$6\times3\times3$ & 0.167 & 10.5 & 2688 & no \\
\hline
\end{tabular}
\end{center}

None of the three reaches $h_x\ll a$; on the evidence of the existing results this would require more than twenty elements along $x$. The table is unchanged in every other respect:

\begin{center}\small
\textit{NEWTAB}
\end{center}

\noindent together with the following addition to its caption:

\begin{quote}\small
\textit{CAPCLAUSE}
\end{quote}

The honest reading of the existing data is that the mesh-sensitivity study bounds the discretisation error but does not eliminate it. Displacement increases monotonically from $u=4.5665$\,$\mu$m to $u=4.8371$\,$\mu$m and the fundamental frequency decreases monotonically from $f_1=193.00$\,Hz to $f_1=174.96$\,Hz between the coarsest and finest meshes, a total change of $5.9\%$ and $9.3\%$ respectively. The $4\times2\times2$ mesh used throughout Sec.~6 sits close to the fine end of that range, differing from the $6\times3\times3$ mesh by about $1.0\%$ in displacement and $2.1\%$ in frequency; since the trend has not saturated, those two figures are lower bounds on the error remaining at that density rather than estimates of it. This is now stated in Sec.~5.5 (p.~18):

\begin{quote}\small
\textit{Q55B}
\end{quote}

\noindent Sec.~6.4 previously asserted, without qualification, that the $4\times2\times2$ grid is ``fine enough to capture the physics''. That sentence has been left as it stands but is now immediately qualified (p.~28):

\begin{quote}\small
\textit{Q64}
\end{quote}

We do not claim that the boundary layer is fully resolved at any of the three mesh densities, and the revised text no longer implies it.

\subsection*{(c) Cases with $l_x/L_x = 1$}

No result has been changed. The strongest effects in the design-space map of Sec.~6.6 do occur at $l_x/L_x=1$, and the manuscript already carries the necessary caveat in Sec.~7.2, where cases with $l/L>0.10$ are described as a parametric sensitivity study rather than a realisation of the weakly nonlocal regime. What was missing was a pointer at the place where those cases actually appear. One sentence has been added in Sec.~6.6, immediately after the discussion of the $(\mathrm{AR}=20,\theta=0^\circ)$ corner (p.~34):

\begin{quote}\small
\textit{Q66}
\end{quote}

\subsection*{(d) Examples limited to idealised bars, rectangles and cuboids}

We agree, and we have not attempted to conceal it. The restriction is a consequence of the discretisation rather than of the theory: the tensor-product Hermite elements used here are defined on rectangular and cuboidal grids, and extending them to curved or irregular boundaries requires isoparametric $C^1$ Hermite elements, isogeometric analysis or a virtual element formulation. This is already recorded in the manuscript in Sec.~5.5, where the isoparametric extension is set out and curved boundaries are left as future work, and again as an entry in the limitations list in Sec.~7.2. Since the reviewer's concern here is one of scope rather than of a specific claim, and since both statements were already present in the revised version, we have not modified them. Adding a genuinely non-rectangular three-dimensional example would require a different element technology and is beyond what can be delivered in this revision; we would rather state that plainly than extend the examples in a way that does not answer the objection.
"""

# splice exact passages into the body
repl = {
    'Q21A': Q21A, 'Q21B': Q21B, 'Q54': Q54, 'Q55A': Q55A, 'Q55B': Q55B,
    'Q64': Q64, 'Q66': Q66, 'Q71': Q71, 'Q72': Q72, 'QAPPB': QAPPB,
    'NEWTAB': NEWTAB, 'CAPCLAUSE': CAPCLAUSE,
}
body = BODY
for k, v in repl.items():
    body = body.replace('\\textit{' + k + '}', v)
    body = body.replace('\n' + k + '\n', '\n' + v + '\n')

for k in repl:
    assert '\\textit{' + k + '}' not in body, f'placeholder {k} left unspliced'

DOC = r"""\documentclass[12pt,a4paper]{article}
\usepackage[margin=1in]{geometry}
\usepackage{booktabs}
\usepackage{setspace}
\usepackage{amsmath,amssymb}
\usepackage{enumitem}
\usepackage{xcolor}
\usepackage[colorlinks=true,linkcolor=blue,urlcolor=blue,citecolor=blue]{hyperref}
\setstretch{1.15}
\usepackage[numbers,sort&compress]{natbib}
\bibliographystyle{elsarticle-num}

% allow the quoted manuscript passages to carry their own inline math
\newcommand{\ms}{\text{m}}

\begin{document}

\begin{center}
{\Large\bfseries Response to Reviewer 3}\\[2pt]
Manuscript ID: FINEL-D-26-00567\\[2pt]
Revision 2\\[4pt]
\textit{Finite Element Analysis of Second-Order Strain-Gradient Elasticity with\\ Ellipsoidal Nonlocal Characteristic Lengths}
\end{center}

\vspace{0.3cm}

We thank Reviewer~3 for the second report. The two remaining points are well taken, and the first of them identifies a real weakness in how the earlier version of the manuscript was framed. Both are addressed below. New and changed text in the revised manuscript is marked in red; page numbers refer to the compiled Revision-2 manuscript.

\vspace{0.2cm}
""" + body + r"""

\vspace{0.4cm}

\noindent\textbf{Summary of the changes made for Reviewer 3}

\vspace{0.2cm}

\begingroup\small
\begin{tabular}{@{}p{0.30\textwidth}p{0.62\textwidth}@{}}
\hline
Location & Change \\
\hline
Sec.~2.1, p.~5 & Two new paragraphs: the ellipsoidal kernel is stated to be a modelling ansatz; the interaction range is defined operationally as a direction-resolved correlation length; three references added \cite{Schey2019,ScheyStapleton2022,RauterLammering2020}; direct interaction-level calibration declared essential future work. \\
Sec.~5.4, p.~17 & New sentence referring to Table~B.3. \\
Sec.~5.5, p.~18 & New sentence referring to Table~B.3 before the quoted solver output; new passage reporting $h_x/a=31.6/15.8/10.5$, stating that the study bounds but does not eliminate the discretisation error, that the $4\times2\times2$ mesh differs from the finest by about $1.0\%$ ($u$) and $2.1\%$ ($f_1$), and that the boundary layer is not claimed to be fully resolved. \\
Sec.~6.4, p.~28 & Qualification of the statement that the $4\times2\times2$ grid is fine enough to capture the physics. \\
Sec.~6.6, p.~34 & New sentence noting that $l_x/L_x=1$ lies outside the weakly nonlocal regime and referring to the existing statement in Sec.~7. \\
Sec.~7.1, p.~37 & New step~7, interaction-level verification by micro-CT and direction-resolved correlation-length analysis. \\
Sec.~7.2, p.~37 & New limitation entry stating that the anisotropy of the interaction domain is a modelling assumption and that the ellipsoidal kernel and the coefficient $1/10$ are not experimentally validated. \\
Appendix~B, p.~40 & New introductory sentence for Table~B.3; two new columns ($h_x$, $h_x/a$) added to Table~B.3 with a corresponding caption clause. \\
References & \texttt{references\_R2.bib} adds three entries, which appear as refs.\ 52--54 of the revised manuscript. No existing entry was changed and no other citation was added. \\
\hline
\end{tabular}
\endgroup

\vspace{0.3cm}

No numerical result, figure, table entry or equation elsewhere in the manuscript has been altered, and no new computation has been performed for this revision. Every quantity quoted above is either taken directly from the Revision-1 manuscript or obtained from those values by arithmetic: $h_x=L_x/n_{ex}$, $a=\sqrt{l^2/10}=0.0158$\,m, $h_x/a$, and the differences between the $4\times2\times2$ and $6\times3\times3$ rows of Table~B.3.

\bibliography{references_R2}

\end{document}
"""

import re as _re
_bad = _re.findall(r'\\(?:ref|eqref)\{[^}]*\}', DOC)
if _bad:
    sys.exit('FATAL: unresolved cross-references would appear in the letter: ' + str(sorted(set(_bad))))

open('Response_to_Reviewer3_R2.tex', 'w', encoding='utf-8').write(DOC)
print('\nwrote Response_to_Reviewer3_R2.tex :', len(DOC), 'chars')
