#!/usr/bin/env python3
"""
Compile-verification harness.

Tectonic (XeTeX + xdvipdfmx) cannot embed PostScript/EPS figures, and the
manuscript references its figures with explicit .eps extensions. To still
verify that the LaTeX source compiles cleanly (all \ref / \cite resolve,
correct table and page numbering), this script builds a SCRATCH copy in
which every \includegraphics{X.eps} is redirected to a generated blank
placeholder PDF. The delivered .tex files keep the original .eps names.

Nothing in the delivered files is modified by this script.
"""
import os, re, shutil, subprocess, sys, glob

TECTONIC = '/tmp/tectonic'
SRC_DIR  = '/home/user/R2'
OUT_DIR  = '/home/user/build_check'
TARGETS  = ['final_R2.tex', 'final_R2_unmarked.tex']


def mkpdf(path, label):
    label_esc = label.replace('\\', '\\\\').replace('(', '\\(').replace(')', '\\)')
    content = f"BT /F1 12 Tf 12 100 Td ({label_esc}) Tj ET\n0.8 w 0 0 400 200 re S"
    objs = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 400 200] "
        b"/Resources << /Font << /F1 5 0 R >> >> /Contents 4 0 R >>",
        f"<< /Length {len(content)} >>\nstream\n{content}\nendstream".encode('latin-1'),
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offs = []
    for i, o in enumerate(objs, 1):
        offs.append(len(out))
        out += f"{i} 0 obj\n".encode() + o + b"\nendobj\n"
    xref = len(out)
    out += f"xref\n0 {len(objs)+1}\n0000000000 65535 f \n".encode()
    for off in offs:
        out += f"{off:010d} 00000 n \n".encode()
    out += (f"trailer\n<< /Size {len(objs)+1} /Root 1 0 R >>\n"
            f"startxref\n{xref}\n%%EOF\n").encode()
    open(path, 'wb').write(bytes(out))


def redirect_graphics(tex_src, workdir):
    names = set(m.group(1) for m in
                re.finditer(r'\\includegraphics(?:\[[^\]]*\])?\{([^}]*)\}', tex_src))
    out = tex_src
    for n in sorted(names):
        if n.endswith('.eps'):
            tgt = n[:-4] + '_PLACEHOLDER.pdf'
            mkpdf(os.path.join(workdir, tgt), n[:-4])
            out = out.replace('{' + n + '}', '{' + tgt + '}')
        elif not os.path.exists(os.path.join(workdir, os.path.basename(n))):
            print('   !! graphic not found in package:', n)
    return out


def check(name, workdir):
    print(f'\n{"="*72}\n  COMPILING {name}\n{"="*72}')
    r = subprocess.run([TECTONIC, '-X', 'compile', name,
                        '--keep-intermediates', '--keep-logs'],
                       cwd=workdir, capture_output=True, text=True, timeout=1200)
    out = (r.stdout or '') + (r.stderr or '')
    out = '\n'.join(l for l in out.splitlines() if 'downloading' not in l)
    logf = os.path.join(workdir, name.replace('.tex', '.log'))
    problems = []

    if os.path.exists(logf):
        log = open(logf, encoding='utf-8', errors='replace').read()
        for pat, tag in [(r'LaTeX Warning: Reference .* undefined', 'UNDEFINED REF'),
                         (r'LaTeX Warning: Citation .* undefined',  'UNDEFINED CITATION'),
                         (r'LaTeX Warning: Label .* multiply defined', 'MULTIPLY-DEFINED LABEL'),
                         (r'There were undefined references',        'UNDEFINED REFS (summary)'),
                         (r'LaTeX Error',                            'LATEX ERROR'),
                         (r'Emergency stop',                         'EMERGENCY STOP')]:
            for m in re.finditer(pat, log):
                line = log[m.start():log.find('\n', m.start())]
                problems.append((tag, line.strip()))
    else:
        problems.append(('NO LOG', 'log file not produced'))

    pdf = os.path.join(workdir, name.replace('.tex', '.pdf'))
    if r.returncode != 0:
        print(out[-3000:])
    print('exit code :', r.returncode)
    print('pdf       :', 'produced (%.2f MiB)' % (os.path.getsize(pdf)/1048576)
          if os.path.exists(pdf) else 'NOT PRODUCED')
    if problems:
        print('problems  :')
        seen = set()
        for tag, line in problems:
            if (tag, line) in seen:
                continue
            seen.add((tag, line))
            print(f'   [{tag}] {line[:150]}')
    else:
        print('problems  : NONE')
    return r.returncode, problems, os.path.join(workdir, name.replace('.tex', '.aux'))


def main():
    shutil.rmtree(OUT_DIR, ignore_errors=True)
    os.makedirs(OUT_DIR)
    for f in glob.glob(os.path.join(SRC_DIR, '*')):
        if f.endswith(('.bib', '.png', '.eps', '.bst')):
            shutil.copy(f, OUT_DIR)

    results = {}
    for t in TARGETS:
        src = open(os.path.join(SRC_DIR, t), encoding='utf-8').read()
        redirected = redirect_graphics(src, OUT_DIR)
        open(os.path.join(OUT_DIR, t), 'w', encoding='utf-8').write(redirected)
        results[t] = check(t, OUT_DIR)

    # cross-check the two deliverables carry identical text
    print(f'\n{"="*72}\n  IDENTITY CHECK\n{"="*72}')
    a = open(os.path.join(SRC_DIR, 'final_R2.tex'), encoding='utf-8').read()
    b = open(os.path.join(SRC_DIR, 'final_R2_unmarked.tex'), encoding='utf-8').read()

    def strip_revtwo(t):
        out, i, key = [], 0, '\\revtwo{'
        while True:
            j = t.find(key, i)
            if j < 0:
                out.append(t[i:]); break
            out.append(t[i:j]); k = j + len(key); d = 1
            while d:
                c = t[k]
                if c == '{': d += 1
                elif c == '}':
                    d -= 1
                    if d == 0: break
                k += 1
            out.append(t[j+len(key):k]); i = k + 1
        return ''.join(out)

    a_lines = [l for l in a.splitlines(True)
               if 'revtwocolor' not in l and '\\revtwo}[1]' not in l]
    a_norm = strip_revtwo(''.join(a_lines))
    print('text identical after removing \\revtwo markup :',
          'YES' if a_norm == b else 'NO')
    if a_norm != b:
        import difflib
        for l in list(difflib.unified_diff(a_norm.splitlines(), b.splitlines(),
                                           'marked-stripped', 'unmarked', lineterm=''))[:40]:
            print('   ', l)

    ok = all(rc == 0 and not p for rc, p, _ in results.values())
    print('\nOVERALL:', 'CLEAN' if ok else 'SEE PROBLEMS ABOVE')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main())
